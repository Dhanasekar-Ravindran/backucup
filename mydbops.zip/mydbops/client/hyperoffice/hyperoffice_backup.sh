#!/bin/sh
#!/bin/bash

#Version : 2.0
#Purpose : Backup_script
#Author  : Remote MySQL DBA

set -x
###################################################################################################################
                                                #Config Details
###################################################################################################################
echo "start at `date +'%d-%b-%Y %H:%M:%S'`"

#config_file=/path/to/config.txt
source "/etc/xtrabackup.conf"


  bdate=`date +'%d-%b-%Y'`
  type=`date +'%A'`
  bkday=`date +'%a'`
  date=`date +'%d-%b'`
  date1=`date +'%Wth-Week'`
  date2=`date +'%W'`
  year=`date +'%Y'`
  fold_date=`date +'%d-%b-%a'`
  chk_time=`date +'%a-%H:%M'`
  bktime=`date +'%d-%a-%H_%M'`


echo "Started : `date +'%d-%b-%Y %H:%M:%S'`" > $date_list/back_details.txt
echo "Host : $host_ip" >> $date_list/back_details.txt
echo "Client : $client" >> $date_list/back_details.txt
echo "Back_Method : Hot" >> $date_list/back_details.txt


#Remove old files
rm -r $mail/*.txt
rm -r $mail/*.html
rm -r $sub/xtrabackup_slave_info


###################################################################################################################
                                                #Backup of data
###################################################################################################################

#Backup of data

#if [[ "$type" == $back_day ]];
if [[ "$type" == $back_day && $chk_time == $back_time ]];
then
back_type="Full Backup"
echo "Backup_Type : Full" >> $date_list/back_details.txt
echo "Full backup"

/bin/mkdir $backup_path/$date1
/bin/mkdir $backup_path/$date1/incremental


drop=$(ls -lrth $backup_path | grep Week | awk '{print $9}' | wc -l)
if [[ $drop -ge 2 ]] ;
then
ls -lrth $backup_path/ | grep Week | awk '{print $9}' | head -n1 > $date_list/remove.txt
else
echo "No old files"
fi

# Backup database
#$xtra_path --user=$user --password=$password --defaults-file=$cnf --socket=$socket  --no-lock --compress --compress-threads=4  --slave-info --export $backup_path/$date1/full_backup-$fold_date  --no-timestamp 1>$logs/full_xtra.log 2>>$logs/full_xtra.err

#added for xtrabackup_history
$xtra_path --user=$user --password=$password  --compress --compress-threads=4  --history=$date1 --slave-info --export $backup_path/$date1/full_backup-$fold_date  --no-timestamp 1>$logs/full_xtra.log 2>$logs/full_xtra.err

echo "$backup_path/$date1" > $date_list/list.txt
echo "$backup_path/$date1/incremental" > $date_list/week_path.txt
echo "$backup_path/$date1/full_backup-$fold_date" > $date_list/week.txt

#added for xtrabackup_history
echo "$date1" > $date_list/inc_history.txt

#Get the status
back_status=$(cat $logs/full_xtra.err | tail -n1 | awk '{print $3}')
echo "Backup_Status : $back_status" >> $date_list/back_details.txt
#Get the backup size
du -sh $backup_path/$date1/full_backup-$fold_date > $sub/file_size.txt
backupsize=$(cat $sub/file_size.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $date_list/back_details.txt
#Get the backup file
backup_file=$(cat $sub/file_size.txt | awk '{print $2}')
echo "Backup_Path : $backup_file" >> $date_list/back_details.txt

#Get the binary log details
#Decompress slave info file
#/usr/bin/qpress -dT8 $backup_path/$date1/full_backup-$fold_date/xtrabackup_slave_info.qp $sub/xtrabackup_slave_info

tail $logs/full_xtra.err | grep 'MySQL slave binlog position' > $sub/xtrabackup_slave_info

log_file=$(cat $sub/xtrabackup_slave_info | awk '{print $9}' | sed  "s/'//g" | sed 's/,//g')
log_pos=$(cat $sub/xtrabackup_slave_info | awk '{print $11}' | sed "s/'//g")


#drop=$(cat $sub/detail.txt | head -n1)

if [[ "$back_status" == completed ]];
then
echo "completed"
else
echo "remove the uncompleted backup"
#rm -rf $backup_path/$date1
fi

#For incremental take lsn number
cat $logs/full_xtra.err | tail -n15 | grep -w 'Transaction log' | awk '{print $6}' | sed 's/(//' | sed 's/)//' > $sub/lsn_no.txt

#To get archived backups

        if [[ $drop -ge 2 ]] ;
        then
        remove_file=$(cat $date_list/remove.txt)
                du -sh $backup_path/$remove_file > $sub/old_file.txt
        arch_file=$(cat $sub/old_file.txt | awk '{print $2}')
        arch_size=$(cat $sub/old_file.txt | awk '{print $1}')
                                        if [[ "$back_status" == completed ]];
                                        then
                                        rm -rf $backup_path/$remove_file
                                        else
                                        echo "Backup not completed"
                                        fi
        else
        echo "No files to be archived"
        fi

else

back_type="Incremental Backup"
echo "Backup_Type : Incremental" >> $date_list/back_details.txt
echo "Incremental backup"


lsn_number=$(cat $sub/lsn_no.txt)
bk_path=$(cat $date_list/week_path.txt)
inc_hist_date=$(cat $date_list/inc_history.txt)

#Get the binary log details

# Backup database
#$xtra_path --user=$user --password=$password --defaults-file=$cnf --socket=$socket   --incremental --incremental-lsn=$lsn_number  $bk_path/inc_backup-$fold_date_$bktime --no-lock --compress --compress-threads=4 --slave-info --no-timestamp 1> $logs/inc_xtra.log 2>>$logs/inc_xtra.err

$xtra_path --user=$user --password=$password --slave-info --history=inc_backup-$fold_date_$bktime --incremental-history-name=$inc_hist_date --incremental --incremental-lsn=$lsn_number  $bk_path/inc_backup-$fold_date_$bktime  --compress --compress-threads=4 --no-timestamp 1> $logs/inc_xtra.log 2>$logs/inc_xtra.err


#Get the status
back_status=$(cat $logs/inc_xtra.err | tail -n1 | awk '{print $3}')
echo "Backup_Status : $back_status" >> $date_list/back_details.txt
#Get the backup size
du -sh $bk_path/inc_backup-$fold_date_$bktime > $sub/file_size.txt
backupsize=$(cat $sub/file_size.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $date_list/back_details.txt
#Get the backup file
backup_file=$(cat $sub/file_size.txt | awk '{print $2}')
echo "Backup_Path : $backup_file" >> $date_list/back_details.txt

#Get the binary log details
#Decompress slave info file
#/usr/bin/qpress -dT8 $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_slave_info.qp $sub/xtrabackup_slave_info

tail $logs/inc_xtra.err | grep 'MySQL slave binlog position' > $sub/xtrabackup_slave_info

log_file=$(cat $sub/xtrabackup_slave_info | awk '{print $9}' | sed  "s/'//g" | sed 's/,//g')
log_pos=$(cat $sub/xtrabackup_slave_info | awk '{print $11}' | sed "s/'//g")


if [[ "$back_status" == completed ]];
then
cat $logs/inc_xtra.err | tail -n15 | grep -w 'Transaction log' | awk '{print $6}' | sed 's/(//' | sed 's/)//' > $sub/lsn_no.txt
else
rm -rf $bk_path/inc_backup-$fold_date_$bktime
fi

#To get available backups

#Available backups

du -sh $backup_path/*/full* > $mail/full_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Full Backup</center></b></td></tr> " > $mail/avb_back.txt
cat $mail/full_back.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail/avb_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Incremental Backup</center></b></td></tr>" >> $mail/avb_back.txt

for  i in `ls -lth $bk_path/ | grep inc | sort -Mr | awk '{print $9}'`
do
du -sh $bk_path/$i >> $mail/back_order.txt
done

cat $mail/back_order.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail/avb_back.txt
avb_inc_backup=$(cat $mail/avb_back.txt)

fi


###################################################################################################################

if [[ "$back_status" == completed ]];
then
status="Success"
color="green"
else
status="Failure"
color="red"
fi

###################################################################################################################
                                        #Sending mails
###################################################################################################################


if [[ "$back_status" == completed ]];
then
echo  "FROM: '$client Backup' <backup@$server>" >> $mail/table.html
echo  "TO: $receiver" >> $mail/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL Backup on $server ($host_ip) is <b><font color='$color'>$status.</font></b><br>" >> $mail/table.html
echo  "<br><center><b>Binary log details</b></center><br>" >> $mail/table.html
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Binlog File</th><th><font color='blue'>Binlog Position</th></tr><tr><td>$log_file</td><td>$log_pos</td></tr></table>" >> $mail/table.html
echo  "Backup Type : <b>$back_type</b><br>" >> $mail/table.html
        if [[ $back_type == "Full Backup" ]];
        then
                echo  "<br><center><b>Full Backup size for today</b></center><br>" >> $mail/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail/table.html
                                if [[ $drop -ge 2 ]]; then
                echo  "<br><center><b>Archieved backups</b></center><br>" >> $mail/table.html
                echo  "<table border='1' width='400px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $mail/table.html
                                fi
        else

                echo  "<br><center><b>Incremental backup size for today</b></center><br>" >> $mail/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail/table.html

                echo  "<center><b>Available backups</b></center><br>" >> $mail/table.html
                echo  "<center><table border='1' width='400px'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$avb_inc_backup</table></center>" >> $mail/table.html
        fi

echo  "</body></html>" >> $mail/table.html
        if [[ $rem_mail == yes ]]; then
        cat $mail/table.html | ssh $mail_user@$mail_host "$sendmail -i -t"
        else
        cat $mail/table.html | $sendmail -i -t
        fi

else
echo  "FROM: '$client Backup' <backup@$server>" >> $mail/table.html
echo  "TO: $receiver_new" >> $mail/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL Backup on $server is <b><font color='$color'>$status</font></b><br>" >> $mail/table.html
echo  "Please check the error log $error_log" >> $mail/table.html
echo  "</body></html>" >> $mail/table.html
        if [[ $rem_mail == yes ]]; then
        cat $mail/table.html | ssh $mail_user@$mail_host "$sendmail -i -t"
        else
        cat $mail/table.html | $sendmail -i -t
        fi
fi


echo "Ended : `date +'%d-%b-%Y %H:%M:%S'`" >> $date_list/back_details.txt

###################################################################################################################

echo "end at `date +'%d-%b-%Y %H:%M:%S'`"

###################################################################################################################

