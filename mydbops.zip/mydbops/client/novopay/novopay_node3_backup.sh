#!/bin/sh
#!/bin/bash

#Version : 2.1
#Purpose : Backup_script
#Author  : Mydbops

set -x
###################################################################################################################
                                                #Config Details
###################################################################################################################
echo "start at `date +'%d-%b-%Y %H:%M:%S'`"

source /etc/backup.conf

  bdate=`date +'%d-%b-%Y'`
  type=`date +'%A'`
  bkday=`date +'%a'`
  week=`date +'%Wth-Week'`
  fold_date=`date +'%d-%b-%a'`
  chk_time=`date +'%a-%H:%M'`
  bktime=`date +'%d-%a-%H_%M'`
  
  mysql_path=$(which mysql)
  xtra_path=$(which innobackupex)


echo "Started : `date +'%d-%b-%Y %H:%M:%S'`" > $list_path/back_details.txt
echo "Host : $host_address" >> $list_path/back_details.txt
echo "Client : $client_name" >> $list_path/back_details.txt
echo "Back_Method : Hot" >> $list_path/back_details.txt

#Remove old files
rm -r $mail_path/*.txt
rm -r $mail_path/*.html

###################################################################################################################
                                                #Backup of data
###################################################################################################################

#Backup of data
if [[ "$type" == $back_day ]];
then
back_type="Full Backup"
echo "Backup_Type : Full" >> $list_path/back_details.txt
echo "Full backup"

/bin/mkdir $back_path/$week
/bin/mkdir $back_path/$week/incremental


drop=$(ls -lrth $back_path | grep Week | awk '{print $9}' | wc -l)
if [[ $drop -ge 2 ]] ;
then
ls -lrth $back_path/ | grep Week | awk '{print $9}' | head -n1 > $list_path/remove.txt
else
echo "No old files"
fi

# Backup database
$xtra_path --user=$back_user --password=$back_password --socket=$server_socket --defaults-file=$server_cnf --no-lock --export $back_path/$week/full_backup-$fold_date  --no-timestamp 1>$log_path/full_xtra.log 2>>$log_path/full_xtra.err

echo "$back_path/$week" > $list_path/list.txt
echo "$back_path/$week/incremental" > $list_path/week_path.txt
echo "$back_path/$week/full_backup-$fold_date" > $list_path/week.txt

#Get the status
back_status=$(cat $log_path/full_xtra.err | tail -n1 | cut -c32-40)
echo "Backup_Status : $back_status" >> $list_path/back_details.txt
#Get the backup size
du -sh $back_path/$week/full_backup-$fold_date > $sub_path/file_size.txt
backupsize=$(cat $sub_path/file_size.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $list_path/back_details.txt
#Get the backup file
backup_file=$(cat $sub_path/file_size.txt | awk '{print $2}')
echo "Backup_Path : $backup_file" >> $list_path/back_details.txt

#Get binary log details
$mysql_path --user=$back_user --password=$back_password -e  "show global variables like 'log_bin';" -s -N > $mail/binlog.txt

bin_log=$(cat $mail/binlog.txt | awk '{print $2}')
if [[ $bin_log == 'ON' ]];
then
binlog_avb=1
 log_file=$(cat $back_path/$week/full_backup-$fold_date/xtrabackup_binlog_info | awk '{print $1}')
 log_pos=$(cat $back_path/$week/full_backup-$fold_date/xtrabackup_binlog_info | awk '{print $2}')
else 
binlog_avb=0
fi

if [[ "$back_status" == completed ]];
then
echo "completed"
else
rm -rf $back_path/$week
fi

#For incremental take lsn number
cat $log_path/full_xtra.err | tail -n10 | grep -w 'Transaction log' | awk '{print $6}' | sed 's/(//' | sed 's/)//' > $sub_path/lsn_no.txt

#To get archived backups

        if [[ $drop -ge 2 ]] ;
        then
        remove_file=$(cat $list_path/remove.txt)
                du -sh $back_path/$remove_file > $sub_path/old_file.txt
        arch_file=$(cat $sub_path/old_file.txt | awk '{print $2}')
        arch_size=$(cat $sub_path/old_file.txt | awk '{print $1}')
                                        if [[ "$back_status" == completed ]];
                                        then
                                        rm -rf $back_path/$remove_file
                                        else
                                        echo "Backup not completed"
                                        fi
        else
        echo "No files to be archived"
        fi

else

back_type="Incremental Backup"
echo "Backup_Type : Incremental" >> $list_path/back_details.txt
echo "Incremental backup"


lsn_number=$(cat $sub_path/lsn_no.txt)
bk_path=$(cat $list_path/week_path.txt)


# Backup database
$xtra_path --user=$back_user --password=$back_password --socket=$server_socket --defaults-file=$server_cnf  --incremental --incremental-lsn=$lsn_number  $bk_path/inc_backup-$fold_date_$bktime --galera-info --no-timestamp 1> $log_path/inc_xtra.log 2>>$log_path/inc_xtra.err

#Get the status
back_status=$(cat $log_path/inc_xtra.err | tail -n1 | cut -c32-40)
echo "Backup_Status : $back_status" >> $list_path/back_details.txt
#Get the backup size
du -sh $bk_path/inc_backup-$fold_date_$bktime > $sub_path/file_size.txt
backupsize=$(cat $sub_path/file_size.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $list_path/back_details.txt
#Get the backup file
backup_file=$(cat $sub_path/file_size.txt | awk '{print $2}')
echo "Backup_Path : $backup_file" >> $list_path/back_details.txt

#Get binary log details
$mysql_path --user=$back_user --password=$back_password -e "show global variables like 'log_bin';" -s -N > $mail/binlog.txt

bin_log=$(cat $mail/binlog.txt | awk '{print $2}')
if [[ $bin_log == 'ON' ]];
then
binlog_avb=1
 log_file=$(cat $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_binlog_info | awk '{print $1}')
 log_pos=$(cat $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_binlog_info | awk '{print $2}')
else 
binlog_avb=0
fi


if [[ "$back_status" == completed ]];
then
cat $log_path/inc_xtra.err | tail -n10 | grep -w 'Transaction log' | awk '{print $6}' | sed 's/(//' | sed 's/)//' > $sub_path/lsn_no.txt
else
rm -rf $bk_path/inc_backup-$fold_date_$bktime
fi

#To get available backups

#Available backups

du -sh $back_path/*/full* > $mail_path/full_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Full Backup</center></b></td></tr> " > $mail_path/avb_back.txt
cat $mail_path/full_back.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail_path/avb_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Incremental Backup</center></b></td></tr>" >> $mail_path/avb_back.txt

for  i in `ls -lth $bk_path/ | grep inc | sort -Mr | awk '{print $9}'`
do
du -sh $bk_path/$i >> $mail_path/back_order.txt
done

cat $mail_path/back_order.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail_path/avb_back.txt
avb_inc_backup=$(cat $mail_path/avb_back.txt)

fi

###################################################################################################################
                                        #Sending mails
###################################################################################################################


if [[ "$back_status" == completed ]];
then
status="Success"
color="green"
echo  "FROM: '$client_name Backup' <novopay-backup@mydbops.com>" >> $mail_path/table.html
echo  "TO: $receiver" >> $mail_path/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($host_server) is $status" >> $mail_path/table.html
echo  "Content-type: text/html" >> $mail_path/table.html
echo  "<html><body>" >> $mail_path/table.html
echo  "Hi Team,<br><br>" >> $mail_path/table.html
echo  "MySQL Backup on $host_server ($host_address) is <b><font color='$color'>$status.</font></b><br>" >> $mail_path/table.html
echo  "<br><center><b>Binary log details</b></center><br>" >> $mail_path/table.html
if [[ $binlog_avb == 1 ]];
then
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Binlog File</th><th><font color='blue'>Binlog Position</th></tr><tr><td>$log_file</td><td>$log_pos</td></tr></table>" >> $mail_path/table.html
else
echo   "You are not using binary log.<br>" >> $mail_path/table.html
fi
echo  "Backup Type : <b>$back_type</b><br>" >> $mail_path/table.html
        if [[ $back_type == "Full Backup" ]];
        then
                echo  "<br><center><b>Full Backup size for today</b></center><br>" >> $mail_path/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail_path/table.html
                                if [[ $drop -ge 2 ]]; then
                echo  "<br><center><b>Archieved backups</b></center><br>" >> $mail_path/table.html
                echo  "<table border='1' width='400px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $mail_path/table.html
                                fi
        else

                echo  "<br><center><b>Incremental backup size for today</b></center><br>" >> $mail_path/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail_path/table.html

                echo  "<center><b>Available backups</b></center><br>" >> $mail_path/table.html
                echo  "<center><table border='1' width='400px'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$avb_inc_backup</table></center>" >> $mail_path/table.html
        fi

echo  "</body></html>" >> $mail_path/table.html
        if [[ $rem_mail == yes ]]; then
        cat $mail_path/table.html | ssh $mail_user@$mail_host "$sendmail_path -i -t"
        else
        cat $mail_path/table.html | $sendmail_path -i -t
        fi

else
status="Failure"
color="red"
echo  "FROM: '$client_name Backup' <novopay-backup@mydbops.com>" >> $mail_path/table.html
echo  "TO: $receiver" >> $mail_path/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($host_server) is $status" >> $mail_path/table.html
echo  "Content-type: text/html" >> $mail_path/table.html
echo  "<html><body>" >> $mail_path/table.html
echo  "Hi Team,<br><br>" >> $mail_path/table.html
echo  "MySQL Backup on $host_server is <b><font color='$color'>$status</font></b><br>" >> $mail_path/table.html
echo  "Please check the error log $error_log" >> $mail_path/table.html
echo  "</body></html>" >> $mail_path/table.html
        if [[ $rem_mail == yes ]]; then
        cat $mail_path/table.html | ssh $mail_user@$mail_host "$sendmail_path -i -t"
        else
        cat $mail_path/table.html | $sendmail_path -i -t
        fi
fi


echo "Ended : `date +'%d-%b-%Y %H:%M:%S'`" >> $list_path/back_details.txt

###################################################################################################################

echo "end at `date +'%d-%b-%Y %H:%M:%S'`"

###################################################################################################################


