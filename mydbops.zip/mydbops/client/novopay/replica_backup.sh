#!/bin/sh
#!/bin/bash

#Version : 2.0
#Purpose : Backup_script
#Author  : MyDBOPS

set -x
###################################################################################################################
                                                #Config Details
###################################################################################################################
echo "Script started at `date +'%d-%b-%Y %H:%M:%S'`"

backup_user="root"
backup_passwd="root"
backup_path="/backup/daily_backup/data"
sub_path="/backup/daily_backup/sub"
mail_path="/backup/daily_backup/mail"
db_schema="hibernate jackrabbit quartz dwh olap"
zip="yes"
older_days="7"
client="Novopay"
receiver="dba-group@mydbops.com,itops@novopay.in"

server=`hostname`
server_ip="10.240.175.46"
dump_path=$(which mysqldump)
mysql_path=$(which mysql)
makedir=$(which mkdir)
sendmail="/usr/sbin/sendmail"

date=`date +'%d-%b-%Y'`

#Remove old files
rm -r $mail_path/*.txt
rm -r $mail_path/*.html
rm -r $sub_path/error_status.txt

###################################################################################################################
                                                #Creating backup folder
###################################################################################################################

#Make a directory for backup
$makedir $backup_path/$date

###################################################################################################################
                                                #collection of stats
###################################################################################################################

back_commands=" --triggers --events --routines --databases "

###################################################################################################################
                                                #Backup of data
###################################################################################################################

#If statement for backup based on format
if [ $zip = no ]
then

#############################do normal backup ################################################33

for db in $db_schema

do

# Dump all databases
$dump_path --user=$backup_user --password=$backup_passwd  $back_commands $db > $backup_path/$date/$db.sql

#Get the status
dump_status=$(less $backup_path/$date/$db.sql | tail -n1 | cut -c09-17)
        if [ $dump_status = completed ]
        then
        echo " Backup on $db is Successful"
        else
        echo " Backup on $db is Failed" >> $sub_path/error_status.txt
        fi

done

#Get the backup file & size
du -h $backup_path/$date > $sub_path/back_size.txt
backupsize=$(cat $sub_path/back_size.txt | awk '{print $1}')
format="Normal"
backup_file=$(cat $sub_path/back_size.txt | awk '{print $2}')

else

########################################do compressed backup ################################################

for db in $db_schema

do

#Dump compressed backup
$dump_path --user=$backup_user --password=$backup_passwd  $back_commands $db | gzip > $backup_path/$date/$db.sql.gz

#Get the status
dump_status=$(zcat $backup_path/$date/$db.sql.gz | tail -n1 | cut -c09-17)
        if [ $dump_status = completed ]
        then
        echo " Backup on $db is Successful"
        else
        echo " Backup on $db is Failed" >> $sub_path/error_status.txt
        fi

#Get the backup size
du -h $backup_path/$date > $sub_path/back_size.txt
backupsize=$(cat $sub_path/back_size.txt | awk '{print $1}')
format="Compressed"
backup_file=$(cat $sub_path/back_size.txt | awk '{print $2}')

done

fi


###################################################################################################################

error_tables=$(cat $sub_path/error_status.txt)
back_status=$(ls -lrth $sub_path/error_status.txt | wc -l)
if [ $back_status -ge 1 ]
then
status="Failure"
color="red"
else
status="Success"
color="green"
fi


 ####################################################################################################################
                                    #To get archived backups
###################################################################################################################

#Files to be archived

year=`date +'%Y'`
remove_file=$(ls -lth $backup_path  | grep $year | awk '{print$9}' | awk 'FNR>=8 && FNR<=12')
arch_file=$(du -sh $backup_path/$remove_file | awk '{print $2}')
arch_size=$(du -sh $backup_path/$remove_file | awk '{print $1}')
if [ -z "$remove_file" ]
then
arch_is=0
else
arch_is=$(du -sh $backup_path/$remove_file | wc -l)
fi

###################################################################################################################
                                #Find files older than 7 days and delete them
###################################################################################################################
if [ $arch_is != 0 ]
then
rm -rf $backup_path/$remove_file
else
echo "No backup to be removed"
fi

####################################################################################################################
                                    #To get available backups
###################################################################################################################
#Available backups

for  i in `ls -lth $backup_path | awk '{print $9}'`
do
du -sh $backup_path/$i >> $mail_path/back_order.txt
done

cat $mail_path/back_order.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' > $mail_path/avb_back.txt
avb_backup=$(cat $mail_path/avb_back.txt)

###################################################################################################################
                                #Sending Mail to client about the process
###################################################################################################################

if [ $dump_status = completed ];
then
echo  "FROM: '$client Backup' <backup@$server>" >> $mail_path/table.html
echo  "TO: $receiver" >> $mail_path/table.html
echo  "SUBJECT: MySQL Logical backup on $date ($server) is $status" >> $mail_path/table.html
echo  "Content-type: text/html" >> $mail_path/table.html
echo  "<html><body>" >> $mail_path/table.html
echo  "Hi Team,<br><br>" >> $mail_path/table.html
echo  "MySQL backup on $server [$server_ip] is <b><font color='$color'>$status.</font></b><br><br>" >> $mail_path/table.html
echo  "Backup Format : <b>$format</b><br><br>" >> $mail_path/table.html
echo  "<br><center><b>Backup size for today</b></center><br>" >> $mail_path/table.html
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail_path/table.html
echo  "Backup retention period : <b>$older_days days</b><br><br>" >> $mail_path/table.html
echo  "<center><b>Available backups</b></center><br>" >> $mail_path/table.html
echo  "<center><table border='1' width='400px' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$avb_backup</table></center>" >> $mail_path/table.html
if [ "$arch_is" = 1 ]
then
echo  "<br><center><b>Archived backups</b></center><br>" >> $mail_path/table.html
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $mail_path/table.html
fi
echo  "</body></html>" >> $mail_path/table.html
cat $mail_path/table.html | $sendmail -i -t

else

echo  "FROM: '$client Backup' <backup@$server>" >> $mail_path/table.html
echo  "TO: $receiver" >> $mail_path/table.html
echo  "SUBJECT: MySQL Logical backup on $date ($server) is $status" >> $mail_path/table.html
echo  "Content-type: text/html" >> $mail_path/table.html
echo  "<html><body>" >> $mail_path/table.html
echo  "Hi Team,<br><br>" >> $mail_path/table.html
echo  "MySQL backup on $server [$server_ip] is <b><font color='$color'>$status</font></b><br>" >> $mail_path/table.html
echo  "Please check the error log $error_log" >> $mail_path/table.html
echo  "" >> $mail_path/table.html
echo  "$error_tables" >> $mail_path/table.html
echo  "" >> $mail_path/table.html
echo  "</body></html>" >> $mail_path/table.html
cat $mail_path/table.html | $sendmail -i -t

fi

###################################################################################################################

echo "Script Completed at `date +'%d-%b-%Y %H:%M:%S'`"

###################################################################################################################


