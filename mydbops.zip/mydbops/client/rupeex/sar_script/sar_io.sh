#!/bin/bash
#!/bin/sh
# Version: 0.0.1

path="/home/mydbops/scripts"

> /home/mydbops/scripts/sar-$(hostname)-multiple.txt

#Get list of sub-folders in sar

for fold in `ls -p /var/log/sa/ | grep "/" | sed 's/\///g'`

do

cd /var/log/sa/$fold

DT=$(ls -l sar* | awk '{print $9}' | sort -V | cut -c4-5 | paste -sd ' ')

for i in $DT; do
  LC_ALL=C sar -f /var/log/sa/$fold/sa$i -b >> /home/mydbops/scripts/sar-$(hostname)-multiple.txt
done

done

