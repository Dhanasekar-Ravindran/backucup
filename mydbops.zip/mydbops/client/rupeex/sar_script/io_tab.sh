#!/bin/bash
#!/bin/sh
# Version: 0.0.1

path="/home/mydbops/scripts"

> /home/mydbops/scripts/`hostname`_iops.csv

#Get list of sub-folders in sar

for fold in `ls -p /var/log/sa/ | grep "/" | sed 's/\///g'`

do

cd /var/log/sa/$fold

DT=$(ls -l sar* | awk '{print $9}' | sort -V | cut -c4-5 | paste -sd ' ')

for i in $DT; do

#Get date
 s_date=`sar -f /var/log/sa/$fold/sa$i -b | head -n1 | awk '{print $4}'`

 dated=`date -d $s_date +%d-%m-%Y`

#for min
 min_value=`sar -f /var/log/sa/$fold/sa$i -b | grep -v tps | grep -v Linux | grep -v LINUX | grep -v Average | awk '{print $3}' | sort -V | sed '/^$/d' | head -n2 | tail -n1`

 min_date_val=`sar -f /var/log/sa/$fold/sa$i -b | grep $min_value | head -n1 | awk '{print $3,"("$1,$2,")"}'`

#for max
 max_value=`sar -f /var/log/sa/$fold/sa$i -b | grep -v tps | grep -v Linux | grep -v LINUX | grep -v Average | awk '{print $3}' | sort -V | sed '/^$/d' | tail -n1`

 max_date_val=`sar -f /var/log/sa/$fold/sa$i -b | grep $max_value |  head -n1 | awk '{print $3,"("$1,$2,")"}'`

#for avg
avg_value=`sar -f /var/log/sa/$fold/sa$i -b | grep Average | awk '{print $2}' | sort -V | sed '/^$/d' |tail -n1`

echo "$dated,$min_date_val,$max_date_val,$avg_value" >> $path/`hostname`_iops.csv

done

done

