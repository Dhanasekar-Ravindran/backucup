The scripts contained here all for to collect and provide IO stats for client servers

Script : sar_io.sh 

It generates a text file which can be uploaded in the ksar graph generator and produce I/O graphs.

Script : io_tab.sh

It generates a csv file which contains the date wise max , min and avg values of IO based on timestamp(for min & max values).
