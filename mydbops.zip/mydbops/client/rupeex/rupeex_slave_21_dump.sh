#!/bin/sh
#!/bin/bash

#Version : 2.0
#Purpose : Backup_script
#Author  : Remote MySQL DBA

set -x
###################################################################################################################
                                                #Config Details
###################################################################################################################
echo "Script started at `date +'%d-%b-%Y %H:%M:%S'`"

#config_file=/path/to/config.txt
config_file=/scsi_vol/backups/mysql_dump/config.txt

user=$(cat $config_file | grep -w back_user | awk '{print $3}')
password=$(cat $config_file | grep -w back_passwd | awk '{print $3}')
master_user=$(cat $config_file | grep -w mast_user | awk '{print $3}')
master_passwd=$(cat $config_file | grep -w mast_passwd | awk '{print $3}')
master_host=$(cat $config_file | grep -w mast_host | awk '{print $3}')

backup_path=$( cat $config_file | grep -w back_path | awk '{print $3}')
sub=$( cat $config_file | grep -w sub_path | awk '{print $3}')
mail=$(cat $config_file | grep -w mail_path | awk '{print $3}')
logs=$( cat $config_file | grep -w log_path | awk '{print $3}')

server=$(cat $config_file | grep -w host_server | awk '{print $3}')
dump_path=$(which mysqldump)
mysql_path=$(which mysql)
makedir=$(which mkdir)

db=$(cat $config_file | grep -w backup_database | awk '{print $3}')
table_list=$(cat $config_file | grep -w table_dumps | awk '{$1=$2=""; print $0}')

zip=$(cat $config_file | grep -w enable_compression | awk '{print $3}')
older_days=$( cat $config_file | grep -w retention_period | awk '{print $3}')
slave=$( cat $config_file | grep -w slave | awk '{print $3}')

sendmail=$( cat $config_file | grep -w sendmail_path | awk '{print $3}')
mail_host=$( cat $config_file | grep -w mail_server | awk '{print $3}')
mail_user=$( cat $config_file | grep -w user_mail | awk '{print $3}')
receiver=$( cat $config_file | grep -w mail_receive | awk '{print $3}')

date=`date +'%d-%b-%Y'`


mount=$(df -h | grep /scsi_vol | awk '{print $6}' | sed 's/\///g')

if [[ $mount == "scsi_vol" ]];
then

#Remove old files
rm -r /scsi_vol/backups/mysql_dump/mail/*.txt
rm -r /scsi_vol/backups/mysql_dump/mail/*.html
rm -r /scsi_vol/backups/mysql_dump/sub/error_status.txt

###################################################################################################################
                                                #getting date
###################################################################################################################

#Make a directory for backup
$makedir $backup_path/$date

###################################################################################################################
                                                #Backup of data
###################################################################################################################

# Backup database

#If statement for backup based on format
if [[ "$zip" == no ]];
then
#Copy the cnf file
cp /etc/my.cnf /$backup_path/$date/my.cnf-$date
$dump_path --user=$user --password=$password  --events --master-data=2 --max_allowed_packet=200MB --databases mysql > $backup_path/$date/mysql-$date.sql

# Dump tables
for tab in $table_list
do
$dump_path --user=$user --password=$password --triggers --events --routines --master-data=2 --max_allowed_packet=200MB --databases $db --tables $tab > $backup_path/$date/$db-$tab.sql

#Get the status
dump_status=$(less $backup_path/$date/$db-$tab.sql | tail -n1 | cut -c09-17)
        if [ $dump_status = completed ]
        then
        echo " Backup on $db.$tab is Successful"
        else
        echo " Backup on $db.$tab is Failed" >> $sub/error_status.txt
        fi

done

#Get the backup size
backupsize=$(du -h $backup_path/$date | cut -c1-4)
format="Normal"
backup_file=$(find $backup_path/$date -type d)

else

#Copy the cnf file
cp /etc/my.cnf /$backup_path/$date/my.cnf-$date
$dump_path --user=$user --password=$password --events --master-data=2 --max_allowed_packet=200MB --databases mysql | gzip > $backup_path/$date/mysql-$date.sql.gz

#Dump tables

for tab in $table_list
do
$dump_path --user=$user --password=$password --triggers --events --routines --master-data=2 --max_allowed_packet=200MB --databases $db --tables $tab | gzip > $backup_path/$date/$db-$tab.sql.gz

#Get the status
dump_status=$(zcat $backup_path/$date/$db-$tab.sql.gz | tail -n1 | cut -c09-17)
        if [ $dump_status = completed ]
        then
        echo " Backup on $db.$tab is Successful"
        else
        echo " Backup on $db.$tab is Failed" >> $sub/error_status.txt
        fi

done

#Get the backup size
backupsize=$(du -h $backup_path/$date | cut -c1-4)
format="Compressed"
backup_file=$(find $backup_path/$date -type d)

fi

###################################################################################################################

error_tables=$(cat $sub/dump_status.txt)
back_status=$(ls -lrth $sub/dump_status.txt | wc -l)
if [[ "$back_status" -ge 1 ]];
then
status="Failure"
color="red"
else
status="Success"
color="green"
fi

#Get the binary log details
if [[ "$slave" == no ]]
then
$mysql_path --user=$user --password=$password -e  "show master status;" -s -N > $mail/binlog.txt
 binlog_avb=$(ls -lrth $mail/binlog.txt | cut -c24-25)
 log_file=$(cat $mail/binlog.txt | cut -c1-16)
 log_pos=$(cat $mail/binlog.txt | cut -c18-25)
else
$mysql_path --user=$master_user --password=$master_passwd --host=$master_host -e "show master status;" -s -N > $mail/binlog.txt
 binlog_avb=$(ls -lrth $mail/binlog.txt | cut -c24-25)
 log_file=$(cat $mail/binlog.txt | cut -c1-16)
 log_pos=$(cat $mail/binlog.txt | cut -c18-25)
 fi

 ####################################################################################################################
                                    #To get archived backups
###################################################################################################################

#Files to be archived

year=`date +'%Y'`
remove_file=$(ls -lth $backup_path  | grep $year | awk '{print$9}' | awk 'FNR>=8 && FNR<=12')
arch_file=$(du -sh $backup_path/$remove_file | awk '{print $2}')
arch_size=$(du -sh $backup_path/$remove_file | awk '{print $1}')
if [[ $remove_file == '' ]];
then
arch_is=0
else
arch_is=$(du -sh $backup_path/$remove_file | wc -l)
fi

###################################################################################################################
                                #Find files older than 7 days and delete them
###################################################################################################################
if [[ $arch_is != 0 ]];
then
rm -rf $backup_path/$remove_file
else
echo "No backup to be removed"
fi

####################################################################################################################
                                    #To get available backups
###################################################################################################################
#Available backups

for  i in `ls -lth $backup_path | awk '{print $9}'`
do
du -sh $backup_path/$i >> $mail/back_order.txt
done

cat $mail/back_order.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' > $mail/avb_back.txt
avb_backup=$(cat $mail/avb_back.txt)

###################################################################################################################

                                #Sending Mail to client about the process
###################################################################################################################

if [[ "$back_status" -ge 1 ]];
then
echo  "FROM: 'RupeeX Backup' <backup@laybhari.iifl.in>" >> $mail/table.html
echo  "TO: $receiver" >> $mail/table.html
echo  "SUBJECT: MySQL Logical backup on $date ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL backup on $server is <b><font color='$color'>$status</font></b><br>" >> $mail/table.html
echo  "Please check the error log $error_log" >> $mail/table.html
echo  "" >> $mail/table.html
echo  "$error_tables" >> $mail/table.html
echo  "" >> $mail/table.html
echo  "</body></html>" >> $mail/table.html
cat $mail/table.html | ssh $mail_user@$mail_host "$sendmail -i -t"

else
echo  "FROM: 'RupeeX Backup' <backup@laybhari.iifl.in>" >> $mail/table.html
echo  "TO: $receiver" >> $mail/table.html
echo  "SUBJECT: MySQL Logical backup on $date ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL backup on $server is <b><font color='$color'>$status.</font></b><br>" >> $mail/table.html
echo  "<br><center><b>Binary log details</b></center><br>" >> $mail/table.html
if [[ "$binlog_avb" -ne 0 ]];
then
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Binlog File</th><th><font color='blue'>Binlog Position</th></tr><tr><td>$log_file</td><td>$log_pos</td></tr></table>" >> $mail/table.html
else
echo   "You are not using binary log.<br>" >> $mail/table.html
fi
echo  "<br>" >> $mail/table.html
echo  "Backup Format : <b>$format</b><br><br>" >> $mail/table.html
echo  "<br><center><b>Backup size for today</b></center><br>" >> $mail/table.html
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail/table.html
echo  "Backup retention period : <b>$older_days days</b><br><br>" >> $mail/table.html
echo  "<center><b>Available backups</b></center><br>" >> $mail/table.html
echo  "<center><table border='1' width='400px' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$avb_backup</table></center>" >> $mail/table.html
if [[ "$arch_is" == 1 ]];
then
echo  "<br><center><b>Archieved backups</b></center><br>" >> $mail/table.html
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $mail/table.html
fi
echo  "</body></html>" >> $mail/table.html
cat $mail/table.html | ssh $mail_user@$mail_host "$sendmail -i -t"

fi

else

echo "Device not mounted"

fi

###################################################################################################################

echo "Script Completed at `date +'%d-%b-%Y %H:%M:%S'`"

###################################################################################################################

