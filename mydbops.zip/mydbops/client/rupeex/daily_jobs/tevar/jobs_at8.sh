#!/bin/bash
#!/bin/csh

#set -x
s_time="`date +%d_%m_%y_%HAm`"
source /root/mysql_jobs/config.txt

subject="Jobs At 8:00 AM"

echo "The script started at `date`"
#echo "<p>"
#echo "CALL SP_Common_Holding_For_All_Assets('Portfolio','0',DATE_SUB(CURDATE(), INTERVAL 1 DAY));"
#$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Common_Holding_For_All_Assets('Portfolio','0',DATE_SUB(CURDATE(), INTERVAL 1 DAY));" | sed 's/\t/,/g' > $out_path/HoldingStatementAtPortfoliolevel_Replica.csv
#echo "</p>"
echo "<p>"
echo "source $sql_path/EODcompilationEmail.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/EODcompilationEmail.sql" | sed 's/\t/,/g' > $out_path/EODcompilationEmail_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/client_depository_details.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/client_depository_details.sql" | sed 's/\t/,/g' > $out_path/ClientDepositoryDetails_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/client_bank_details.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/client_bank_details.sql" | sed 's/\t/,/g' > $out_path/ClientBankDetails_$e_time.csv
echo "</p>"
echo "<p>"
echo "CALL SP_Common_Holding_For_All_Assets('Portfolio','0',DATE_SUB(CURDATE(), INTERVAL 1 DAY));"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Common_Holding_For_All_Assets('Portfolio','0',DATE_SUB(CURDATE(), INTERVAL 1 DAY));" | sed 's/\t/,/g' > $out_path/HoldingStatementAtPortfoliolevel_Live_$e_time.csv
echo "</p>"
echo "<p>"
echo "CALL SP_Excel_Export_of_Transaction_Statement('Portfolio',0,0,DATE_SUB(CURDATE(), INTERVAL 7 DAY),DATE_SUB(CURDATE(), INTERVAL 0 DAY),'2,3,4,9,10,44,47,48,55,56,59,60,73,74,75,76','N',0,5,'Y');"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Excel_Export_of_Transaction_Statement('Portfolio',0,0,DATE_SUB(CURDATE(), INTERVAL 7 DAY),DATE_SUB(CURDATE(), INTERVAL 0 DAY),'2,3,4,9,10,44,47,48,55,56,59,60,73,74,75,76','N',0,5,'Y');" | sed 's/\t/,/g'> $out_path/Export_of_Transaction_Statement_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/portfolio_activation.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/portfolio_activation.sql" | sed 's/\t/,/g'> $out_path/Portfolio_Activation_$e_time.csv
echo "</p>"
echo ""

echo "job got completed at `date`"

cat $log_path/jobs_at8.err  >> $log_path/backup/jobs_at8.err
count=$(cat $log_path/jobs_at8.err | egrep "ERROR|Text" | wc -l)
if [[ $count -ge 1 ]]; then
status="ran with errors!"
else
status="ran successfully!"
fi

echo  "FROM: 'Tevarqueries' <$from_address>" > $out_path/table.html
echo  "TO: $to_address" >> $out_path/table.html
echo  "SUBJECT: $subject $status " >> $out_path/table.html
echo  "Content-type: text/html" >> $out_path/table.html
echo  "<html><body>" >> $out_path/table.html
echo  "Hi Team,<br><br>" >> $out_path/table.html
if [[ $count -ge 1 ]]; then
echo "The job ran with some errors, the details is as follows,<br><br>" >> $out_path/table.html
cat $log_path/jobs_at8.err >> $out_path/table.html
echo "" >> $out_path/table.html
else
echo "The jobs ran successfully with no errors.<br><br>" >> $out_path/table.html
fi
echo "</body></html>" >> $out_path/table.html
#Sent the mail
if [[ $count -ge 1 ]]; then
cat $out_path/table.html | ssh -q -o "StrictHostKeyChecking no" rupeexmon@$mail_host "$sendmail -i -t"
else
echo "No mail"
fi
exit 0
