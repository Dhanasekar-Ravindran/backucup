#!/bin/bash
#!/bin/sh

set -x
#Version : 1.0
#Script  : Email alert
#Author  : Mydbops

date=`date +'%d-%m-%y %H:%M:%S'`

echo "Script started at $date "

source /root/email_jobs/config

mysql_path=$(which mysql)
remote_path="/home/rupeexmon/email_jobs/data"

s_time="`date +%d_%m_%y_%HAm`"

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"

#Query1
> $out_path/Portfolio_Activation.txt

echo  "Hi Team," >> $out_path/Portfolio_Activation.txt
echo  "" >> $out_path/Portfolio_Activation.txt
echo  "The csv format output for Portfolio Activation on $date has been attached."  >> $out_path/Portfolio_Activation.txt
echo  "" >> $out_path/Portfolio_Activation.txt
echo  "Please find the attachment."  >> $out_path/Portfolio_Activation.txt
echo  "" >> $out_path/Portfolio_Activation.txt
echo  "With Regards,"  >> $out_path/Portfolio_Activation.txt
echo  "Reports@tevar.iifl.in"  >> $out_path/Portfolio_Activation.txt

#Execute the query
$login_path $mysql_db -e "source $sql_path/portfolio_activation.sql" | sed 's/\t/,/g' > $out_path/Portfolio_Activation.csv


ssh -q -o "StrictHostKeyChecking no"  rupeexmon@$mail_server "rm -r $remote_path/*"
scp -q -o "StrictHostKeyChecking no"  $out_path/Portfolio_Activation.csv rupeexmon@$mail_server:$remote_path/Portfolio_Activation.csv

#Sent the mail

cat $out_path/Portfolio_Activation.txt | ssh -q -o "StrictHostKeyChecking no" rupeexmon@$mail_server  "mail -s '$(echo -e 'Portfolio Activation List - AMC\nFrom: Reports Tevar <reports@tevar.iifl.in> \n')' -a '$remote_path/Portfolio_Activation.csv' -c '$cc_address' $sent_to"

echo "Script ended at $date"
exit
