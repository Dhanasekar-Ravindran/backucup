#!/bin/bash
#!/bin/csh

#set -x
s_time="`date +%d_%m_%y_%HAm`"
source /root/mysql_jobs/config.txt

subject="Jobs At 6:00 AM"

echo "The script started at `date`"
echo "<p>"
echo "CALL SP_BankBalance_AllPortfolio_asondate('2040-04-01');"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_BankBalance_AllPortfolio_asondate('2040-04-01');" | sed 's/\t/,/g'> $out_path/BankBalanceAsonDate_$e_time.xls
echo "</p>"
echo "<p>"
echo "CALL SP_SubBank_AllMemberwithperiod('2000-01-01','2050-04-01');"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_SubBank_AllMemberwithperiod('2000-01-01','2050-04-01');" | sed 's/\t/,/g'> $out_path/Bank_Book_Since_Inception_$e_time.xls
echo "</p>"
echo "<p>"
echo "source $sql_path/folio_portfolio_mfschememapping.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/folio_portfolio_mfschememapping.sql" | sed 's/\t/,/g'> $out_path/folio_portfolio_mfschememapping_$e_time.xls
echo "</p>"
echo "<p>"
echo "source $sql_path/LedgerEntriesT_4Days.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/LedgerEntriesT_4Days.sql" | sed 's/\t/,/g'> $out_path/LedgerEntriesT_4Days_$e_time.xls
echo "</p>"
echo "<p>"
echo "source $sql_path/ControlAccountBalace.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/ControlAccountBalace.sql" | sed 's/\t/,/g'> $out_path/ControlAccountBalace_$e_time.xls
echo "</p>"
echo ""

echo "job got completed at `date`"

cat $log_path/jobs_at6.err  >> $log_path/backup/jobs_at6.err
count=$(cat $log_path/jobs_at6.err | egrep "ERROR|Text" | wc -l)
if [[ $count -ge 1 ]]; then
status="ran with errors!"
else
status="ran successfully!"
fi

echo  "FROM: 'Tevarqueries' <$from_address>" > $out_path/table.html
echo  "TO: $to_address" >> $out_path/table.html
echo  "SUBJECT: $subject $status " >> $out_path/table.html
echo  "Content-type: text/html" >> $out_path/table.html
echo  "<html><body>" >> $out_path/table.html
echo  "Hi Team,<br><br>" >> $out_path/table.html
if [[ $count -ge 1 ]]; then
echo "The job ran with some errors, the details is as follows,<br><br>" >> $out_path/table.html
cat $log_path/jobs_at6.err >> $out_path/table.html
echo "" >> $out_path/table.html
else
echo "The jobs ran successfully with no errors.<br><br>" >> $out_path/table.html
fi
echo "</body></html>" >> $out_path/table.html

#Sent the mail
if [[ $count -ge 1 ]]; then
cat $out_path/table.html | ssh -q -o "StrictHostKeyChecking no" rupeexmon@$mail_host "$sendmail -i -t"
else
echo "No mail"
fi

exit 0

