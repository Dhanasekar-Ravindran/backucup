#!/bin/bash
#!/bin/csh

#set -x
s_time="`date +%d_%m_%y_%HAm`"
source /root/mysql_jobs/config.txt

subject="Jobs At 5:00 AM"

echo "The script started at `date`"
echo "<p>"
echo "source $sql_path/ClientInformationExceptCommunicationDetails.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/ClientInformationExceptCommunicationDetails.sql" | sed 's/\t/,/g'> $out_path/ClientInformationExceptCommunicationDetails_$e_time.csv
echo "</p>"
echo "<p>"
echo "CALL SP_BO_Negative_Stock('2040-01-31');"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_BO_Negative_Stock('2040-01-31');" | sed 's/\t/,/g'> $out_path/NegativeHolding_$e_time.csv
echo "</p>"
echo "<p>"
echo "CALL SP_Negative_Quantity();"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Negative_Quantity();" | sed 's/\t/,/g'> $out_path/NegativeFIFO_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/ControlAccountReco_PreviousDay.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/ControlAccountReco_PreviousDay.sql" | sed 's/\t/,/g'> $out_path/ControlAccountReco_PreviousDay_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/ControlAccountReco_CurrentFinancialYear2014.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/ControlAccountReco_CurrentFinancialYear2014.sql" | sed 's/\t/,/g'> $out_path/ControlAccountReco_CurrentFinancialYear2014_$e_time.csv
echo "</p>"
echo "<p>"
echo "CALL SP_Holding_WO_Priceupdate('2050-02-21');"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Holding_WO_Priceupdate('2050-02-21'); " | sed 's/\t/,/g'> $out_path/Holing_without_closing_price_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/FamilyRMMapping.sql;"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/FamilyRMMapping.sql; " | sed 's/\t/,/g'> $out_path/FamilyRMMapping_$e_time.csv
echo "</p>"
echo "<p>"
echo "CALL SP_Inbalnce_BalanceSheet();"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Inbalnce_BalanceSheet();" | sed 's/\t/,/g'> $out_path/TrialBalance_Not_Tallying_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/MF_schemas.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/MF_schemas.sql" | sed 's/\t/,/g'> $out_path/MF_Schemas_$e_time.csv
echo "</p>"
echo "<p>"
echo "SELECT * FROM bodb.mfrta_txntype_mapping;"
$mysql_path --login-path=$mysql_user bodb -e "SELECT * FROM bodb.mfrta_txntype_mapping;" | sed 's/\t/,/g'> $out_path/MFTxnTypeMapping_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/Equity_schemes.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/Equity_schemes.sql" | sed 's/\t/,/g'> $out_path/Equity_schemes_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/DebtSchmes.sql"
$mysql_path --login-path=$mysql_user bodb -e " source $sql_path/DebtSchmes.sql" | sed 's/\t/,/g'> $out_path/DebtSchme_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/ManagedAccSchmes.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/ManagedAccSchmes.sql" | sed 's/\t/,/g'> $out_path/ManagedAccSchmes_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/DailyDividentMasterDump.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/DailyDividentMasterDump.sql" | sed 's/\t/,/g'> $out_path/DailyDividentMasterDump_$e_time.csv
echo "</p>"
echo "<p>"
echo ""
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/L3Created.sql" | sed 's/\t/,/g'> $out_path/L3Created_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/L3Created.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/RIMSMFRateCard.sql" | sed 's/\t/,/g'> $out_path/RIMSMFRateCard_$e_time.csv
echo "</p>"
echo "<p>"
echo "source $sql_path/EmployeeList.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/EmployeeList.sql" | sed 's/\t/,/g'> $out_path/EmployeeList_$e_time.csv
echo "</p>"

echo "job got completed at `date`"

cat $log_path/jobs_at5.err  >> $log_path/backup/jobs_at5.err
count=$(cat $log_path/jobs_at5.err | egrep "ERROR|Text" | wc -l)
if [[ $count -ge 1 ]]; then
status="ran with errors!"
else
status="ran successfully!"
fi

echo  "FROM: 'Tevarqueries' <$from_address>" > $out_path/table.html
echo  "TO: $to_address" >> $out_path/table.html
echo  "SUBJECT: $subject $status " >> $out_path/table.html
echo  "Content-type: text/html" >> $out_path/table.html
echo  "<html><body>" >> $out_path/table.html
echo  "Hi Team,<br><br>" >> $out_path/table.html
if [[ $count -ge 1 ]]; then
echo "The job ran with some errors, the details is as follows,<br><br>" >> $out_path/table.html
cat $log_path/jobs_at5.err >> $out_path/table.html
echo "" >> $out_path/table.html
else
echo "The jobs ran successfully with no errors.<br><br>" >> $out_path/table.html
fi
echo "</body></html>" >> $out_path/table.html
#Sent the mail
if [[ $count -ge 1 ]]; then
cat $out_path/table.html | ssh -q -o "StrictHostKeyChecking no" rupeexmon@$mail_host "$sendmail -i -t"
else
echo "No mail"
fi

exit 0

