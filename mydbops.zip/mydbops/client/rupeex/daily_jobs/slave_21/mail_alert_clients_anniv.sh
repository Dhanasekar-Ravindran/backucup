#!/bin/bash
#!/bin/sh

#Version : 1.0
#Script  : Email alert
#Author  : Mydbops

date=`date +'%d-%m-%y %H:%M:%S'`

echo "Script started at $date "

#config_file=/root/email_jobs/config.txt

mysql_user="repuser"
mysql_paswd="reppass"
mysql_db="bodb"
mysql_path=$(which mysql)
out_path="/root/email_jobs/data"
sql_path="/root/email_jobs/query"
mail_host="172.16.3.23"
remote_path="/home/rupeexmon/email_jobs/data"

s_time="`date +%d_%m_%y_%HAm`"

to_address="japhia@iiflw.com"
cc_address="dba-group@mydbops.com"

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"

#Query1
> $out_path/cbth_annv.txt

echo  "Hi Team," >> $out_path/cbth_annv.txt
echo  "" >> $out_path/cbth_annv.txt
echo  "The csv  format output for ClientBirthdaysAnniversaries with Primary & Service RM  Job on $date has been attached."  >> $out_path/cbth_annv.txt
echo  "" >> $out_path/cbth_annv.txt
echo  "Please find the attachment."  >> $out_path/cbth_annv.txt
echo  "" >> $out_path/cbth_annv.txt
echo  "Regards,"  >> $out_path/cbth_annv.txt
echo  "MyDBOPS"  >> $out_path/cbth_annv.txt

#Execute the query
$login_path  bodb -e "source $sql_path/clientanniversary.sql" | sed 's/\t/,/g' > $out_path/cbth_annv.csv

ssh rupeexmon@$mail_host "rm -r $remote_path/*"
scp $out_path/cbth_annv.csv rupeexmon@$mail_host:$remote_path/Transaction_Statement.csv

#Sent the mail

cat $out_path/cbth_annv.txt | ssh rupeexmon@$mail_host  "mail -s '$(echo -e 'Client Birthdays Anniversaries\nFrom: Reports Laybhari <reports@mydbops.com> \n')' -a '$remote_path/Transaction_Statement.csv' -c '$cc_address' $to_address"

echo "Script ended at $date"
exit
