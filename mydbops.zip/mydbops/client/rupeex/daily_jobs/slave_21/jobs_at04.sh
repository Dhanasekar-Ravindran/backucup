#!/bin/bash
#!/bin/csh

#set -x
s_time="`date +%d_%m_%y_%HAm`"
source /root/mysql_jobs/config.txt

subject="Jobs At 16:15 PM"

echo "The script started at `date`"
echo "<p>"
echo "source $sql_path/AMC_NAV_data.sql"
$mysql_path --login-path=$mysql_user bodb -e "source $sql_path/AMC_NAV_data.sql" | sed 's/\t/,/g'> $out_path/AMC_NAV_data_$e_time.csv
echo "</p>"
echo ""
cp $out_path/AMC_NAV_data.csv $alt_path/
echo "job got completed at `date`"

cat $log_path/jobs_at16_15.err  >> $log_path/backup/jobs_at16_15.err
count=$(cat $log_path/jobs_at16_15.err | egrep "ERROR|Text" | wc -l)
if [[ $count -ge 1 ]]; then
status="ran with errors!"
else
status="ran successfully!"
fi

echo  "FROM: 'Caliberqueries' <$from_address>" > $out_path/table.html
echo  "TO: $to_address" >> $out_path/table.html
echo  "SUBJECT: $subject $status " >> $out_path/table.html
echo  "Content-type: text/html" >> $out_path/table.html
echo  "<html><body>" >> $out_path/table.html
echo  "Hi Team,<br><br>" >> $out_path/table.html
if [[ $count -ge 1 ]]; then
echo "The job ran with some errors, the details is as follows,<br><br>" >> $out_path/table.html
cat $log_path/jobs_at16_15.err >> $out_path/table.html
echo "" >> $out_path/table.html
else
echo "The jobs ran successfully with no errors.<br><br>" >> $out_path/table.html
fi
echo "</body></html>" >> $out_path/table.html
#Sent the mail
cat $out_path/table.html | ssh -q -o "StrictHostKeyChecking no" rupeexmon@$mail_host "$sendmail -i -t"

exit 0
