#!/bin/bash
#!/bin/sh

#Version : 1.0
#Script  : Email alert
#Author  : Mydbops

date=`date +'%d-%m-%y %H:%M:%S'`

echo "Script started at $date "

config_file=/root/email_jobs/config.txt

mysql_user=$(cat $config_file | grep -w mysql_user | awk '{print $3}')
mysql_paswd=$(cat $config_file | grep -w mysql_password | awk '{print $3}')
mysql_db=$(cat $config_file | grep -w mysql_database | awk '{print $3}')
mysql_path=$(which mysql)
out_path=$(cat $config_file | grep -w sub_path | awk '{print $3}')
mail_host=$(cat $config_file | grep -w mail_server | awk '{print $3}')
remote_path="/home/rupeexmon/email_jobs/data"

s_time="`date +%d_%m_%y_%HAm`"

to_address=$(cat $config_file | grep -w trans_sent | awk '{print $3}')
cc_address=$(cat /etc/mail | grep dbops_mail | awk '{print $3}')

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"

#Query1
> $out_path/trans_statmt.txt

echo  "Hi Team," >> $out_path/trans_statmt.txt
echo  "" >> $out_path/trans_statmt.txt
echo  "The excel format output for stored procedure "SP_Excel_Export_of_Transaction_Statement" on $date has been attached."  >> $out_path/trans_statmt.txt
echo  "" >> $out_path/trans_statmt.txt
echo  "Please find the attachment."  >> $out_path/trans_statmt.txt
echo  "" >> $out_path/trans_statmt.txt
echo  "With Regards,"  >> $out_path/trans_statmt.txt
echo  "Reports@laybhari.iifl.in"  >> $out_path/trans_statmt.txt

#Execute the query
$login_path $mysql_db -e "CALL SP_Excel_Export_of_Transaction_Statement('Portfolio',0,0,CURDATE()-3,CURDATE(),'2,3,4,9,10,44,47,48,55,56,59,60,73,74,75,76','N',0,5)"  | sed 's/\t/,/g' > $out_path/trans_statmt.csv

ssh rupeexmon@$mail_host "rm -r $remote_path/*"
scp $out_path/trans_statmt.csv rupeexmon@$mail_host:$remote_path/Transaction_Statement.csv

#Sent the mail

cat $out_path/trans_statmt.txt | ssh rupeexmon@$mail_host  "mail -s '$(echo -e 'Transaction Statements\nFrom: Reports Laybhari <chetan@iiflw.com> \n')' -a '$remote_path/Transaction_Statement.csv' -c '$cc_address' chetan@iiflw.com"

echo "Script ended at $date"
exit
