#!/bin/bash
#!/bin/csh

#set -x
s_time="`date +%d_%m_%y_%HAm`"
source /root/mysql_jobs/config.txt
j_date=`date +'%H:%M %p'`

subject="Jobs(Twice) At $j_date"

echo "The script started at `date`"
echo "<p>"
echo "CALL SP_Cams_UnmatchedTxns();"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Cams_UnmatchedTxns();" | sed 's/\t/,/g'> $out_path/PendingTxnfromMFOrderMatchingWindow_CAMS_$e_time.xls
echo "</p>"
echo "<p>"
echo "CALL SP_Karvy_UnmatchedTxns();"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Karvy_UnmatchedTxns();" | sed 's/\t/,/g'> $out_path/PendingTxnfromMFOrderMatchingWindow_KARVY_$e_time.xls
echo "</p>"
echo "<p>"
echo "CALL SP_Sundaram_UnmatchedTxns();"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Sundaram_UnmatchedTxns();" | sed 's/\t/,/g'> $out_path/PendingTxnfromMFOrderMatchingWindow_Sundaram_$e_time.xls
echo "</p>"
echo "<p>"
echo "CALL SP_Templeton_UnmatchedTxns();"
$mysql_path --login-path=$mysql_user bodb -e "CALL SP_Templeton_UnmatchedTxns();" | sed 's/\t/,/g'> $out_path/PendingTxnfromMFOrderMatchingWindow_Temp_$e_time.xls
echo "</p>"
echo ""
cp $out_path/*.xls $alt_path/
echo "job got completed at `date`"

d_type=`date +'%p'`
if [[ $d_type == AM ]]; then
cat $log_path/jobs_at_twice_8.err  >> $log_path/backup/jobs_at_twice_8.err
count=$(cat $log_path/jobs_at_twice_8.err | egrep "ERROR|Text" | wc -l)
else
cat $log_path/jobs_at_twice_20.err  >> $log_path/backup/jobs_at_twice_20.err
count=$(cat $log_path/jobs_at_twice_20.err | egrep "ERROR|Text" | wc -l)
fi

if [[ $count -ge 1 ]]; then
status="ran with errors!"
else
status="ran successfully!"
fi

echo  "FROM: 'Caliberqueries' <$from_address>" > $out_path/table.html
echo  "TO: $to_address" >> $out_path/table.html
echo  "SUBJECT: $subject $status " >> $out_path/table.html
echo  "Content-type: text/html" >> $out_path/table.html
echo  "<html><body>" >> $out_path/table.html
echo  "Hi Team,<br><br>" >> $out_path/table.html
if [[ $count -ge 1 ]]; then
echo "The job ran with some errors, the details is as follows,<br><br>" >> $out_path/table.html
cat $log_path/jobs_at_twice_20.err >> $out_path/table.html
echo "" >> $out_path/table.html
else
echo "The jobs ran successfully with no errors.<br><br>" >> $out_path/table.html
fi
echo "</body></html>" >> $out_path/table.html
#Sent the mail
cat $out_path/table.html | ssh -q -o "StrictHostKeyChecking no" rupeexmon@$mail_host "$sendmail -i -t"

exit 0


