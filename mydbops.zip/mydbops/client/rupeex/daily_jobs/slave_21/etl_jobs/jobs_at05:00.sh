#!/bin/bash
#!/bin/csh

source /root/etl/config

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"

$login_path $mysql_db -e "source /root/etl_jobs/family.sql " | sed 's/\t/,/g' > $sub_path/family.csv

sed 's/NULL//g' $sub_path/family.csv > $out_path/Family/family.csv

exit 0
