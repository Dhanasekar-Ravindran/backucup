#!/bin/bash
#!/bin/csh

source /root/etl/config

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"


$login_path $mysql_db -e "source /root/etl_jobs/revenue.sql" | sed 's/\t/,/g'> $sub_path/revenue.csv

sed 's/NULL//g' $sub_path/revenue.csv > $out_path/Revenue/revenue.csv

exit 0
