#!/bin/bash
#!/bin/csh

source /root/etl/config

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"


$login_path $mysql_db -e "source /root/etl_jobs/portfolio.sql" | sed 's/\t/,/g'> $sub_path/portfolio.csv

sed 's/NULL//g' $sub_path/portfolio.csv > $out_path/Portfolio/portfolio.csv

exit 0
