#!/bin/bash
#!/bin/csh

source /root/etl/config

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"


$login_path $mysql_db -e "source /root/etl_jobs/bank.sql" | sed 's/\t/,/g' > $sub_path/bank.csv

sed 's/NULL//g' $sub_path/bank.csv > $out_path/Bank/bank.csv

exit 0
