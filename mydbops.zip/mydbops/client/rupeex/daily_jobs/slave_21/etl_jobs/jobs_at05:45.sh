#!/bin/bash
#!/bin/csh

source /root/etl/config

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"


$login_path $mysql_db -e "source /root/etl_jobs/transaction.sql" | sed 's/\t/,/g'> $sub_path/transaction.csv

sed 's/NULL//g' $sub_path/transaction.csv > $out_path/Transaction/transaction.csv

exit 0
