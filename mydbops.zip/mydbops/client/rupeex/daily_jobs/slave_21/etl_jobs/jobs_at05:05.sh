#!/bin/bash
#!/bin/csh

source /root/etl/config

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"

$login_path $mysql_db -e "source /root/etl_jobs/client.sql" | sed 's/\t/,/g'> $sub_path/client.csv

sed 's/NULL@NULL.com/null@null.com/g' $sub_path/client.csv > $sub_path/client_1.csv

sed 's/NULL//g' $sub_path/client_1.csv > $out_path/Client/client.csv

exit 0
