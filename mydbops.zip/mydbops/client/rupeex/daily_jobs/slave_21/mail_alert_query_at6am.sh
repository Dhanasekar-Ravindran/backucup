#!/bin/bash
#!/bin/sh

set -x

#Version : 1.0
#Script  : Email alert
#Author  : Remotemysql DBA

date=`date +'%d-%m-%y %H:%M:%S'`

echo "Script started at $date "

config_file=/root/email_jobs/config.txt

mysql_user=$(cat $config_file | grep -w mysql_user | awk '{print $3}')
mysql_paswd=$(cat $config_file | grep -w mysql_password | awk '{print $3}')
mysql_db=$(cat $config_file | grep -w mysql_database | awk '{print $3}')
mysql_path=$(which mysql)
out_path=$(cat $config_file | grep -w sub_path | awk '{print $3}')
sendmail=/usr/sbin/sendmail
mail_host=$(cat $config_file | grep -w mail_server | awk '{print $3}')
cc_address=$(cat /etc/mail | grep dbops_mail | awk '{print $3}')

s_time="`date +%d_%m_%y_%HAm`"

subject=$(cat $config_file | grep -w email_subj | awk '{print $3}')
from_address=$(cat $config_file | grep -w sent_from | awk '{print $3}')
to_address=$(cat $config_file | grep -w sent_to | awk '{print $3}')

#For Query_2
mail_subject=$(cat $config_file | grep -w email_subject | awk '{print $3}')
to_addrs=$(cat $config_file | grep -w sent_mail_to | awk '{print $3}')

login_path="$mysql_path --user=$mysql_user --password=$mysql_paswd"

#Query1
> $out_path/table.html

echo  "FROM: 'Caliberqueries' <$from_address>" >> $out_path/table.html
echo  "TO: $to_address" >> $out_path/table.html
echo  "CC: $cc_address" >> $out_path/table.html
echo  "SUBJECT: $subject-$s_time" >> $out_path/table.html
echo  "Content-type: text/html" >> $out_path/table.html
echo  "<html><body>" >> $out_path/table.html
echo  "Hi Team,<br><br>" >> $out_path/table.html
echo "The output for <b>$subject</b> report is as follows,<br><br>" >> $out_path/table.html
#Execute the query
$login_path $mysql_db -e "SELECT a.id,a.processid,b.processname,a.eoddate,a.startdate,a.enddate,a.status FROM eodprocess_log a, eodprocess b WHERE a.EODdate >= DATE(NOW())-4 AND a.processid IN (SELECT id FROM eodprocess WHERE TYPE <> 'Y') AND b.id = a.processid AND a.processid = 17 ORDER BY eoddate DESC;"  --html | sed 's/<TABLE BORDER=1>/<TABLE BORDER='1' WIDTH='AUTO' ALIGN='CENTER' CELLPADDING='8' CELLSPACING='0'>/g' >> $out_path/table.html
echo "</body></html>" >> $out_path/table.html
#Sent the mail
cat $out_path/table.html | ssh rupeexmon@$mail_host "$sendmail -i -t"

#Query2
> $out_path/table_2.html

echo  "FROM: 'Caliberqueries' <$from_address>" >> $out_path/table_2.html
echo  "TO: $to_addrs" >> $out_path/table_2.html
echo  "CC: $cc_address" >> $out_path/table_2.html
echo  "SUBJECT: $mail_subject-$s_time" >> $out_path/table_2.html
echo  "Content-type: text/html" >> $out_path/table_2.html
echo  "<html><body>" >> $out_path/table_2.html
echo  "Hi Team,<br><br>" >> $out_path/table_2.html
#Execute the query
tot_rec=`$login_path $mysql_db -e "SELECT count(*) FROM eodprocess_log a, eodprocess b  WHERE a.EODdate = DATE_SUB(CURDATE(), INTERVAL 1 DAY)  AND a.processid IN (SELECT id FROM eodprocess WHERE TYPE <> 'Y')  AND b.id = a.processid;" -s -N`
if [[ $tot_rec == 0 ]]; then
echo "No report fetched for the given query!" >> $out_path/table_2.html
else
echo "The output for <b>$mail_subject</b> report is as follows,<br><br>" >> $out_path/table_2.html
$login_path $mysql_db -e "SELECT a.id,a.processid,b.processname,a.eoddate,a.startdate,a.enddate,a.status  FROM eodprocess_log a, eodprocess b  WHERE a.EODdate = DATE_SUB(CURDATE(), INTERVAL 1 DAY)  AND a.processid IN (SELECT id FROM eodprocess WHERE TYPE <> 'Y')  AND b.id = a.processid;"  --html | sed 's/<TABLE BORDER=1>/<TABLE BORDER='1' WIDTH='AUTO' ALIGN='CENTER' CELLPADDING='8' CELLSPACING='0'>/g' >> $out_path/table_2.html
echo "</body></html>" >> $out_pathi/table_2.html
fi
#Sent the mail
cat $out_path/table_2.html | ssh rupeexmon@$mail_host "$sendmail -i -t"

echo "Script ended at $date"
exit
