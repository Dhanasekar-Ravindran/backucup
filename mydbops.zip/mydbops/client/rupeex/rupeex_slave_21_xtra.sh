#!/bin/sh
#!/bin/bash

#Version : 2.0
#Purpose : Backup_script
#Author  : Remote MySQL DBA

set -x
###################################################################################################################
                                                #Config Details
###################################################################################################################
echo "start at `date +'%d-%b-%Y %H:%M:%S'`"

#config_file=/path/to/config.txt
config_file=/scsi_vol/backups/xtrabackup/config.txt

user=$(cat $config_file | grep -w back_user | awk '{print $3}')
password=$(cat $config_file | grep -w back_passwd | awk '{print $3}')
master_user=$(cat $config_file | grep -w mast_user | awk '{print $3}')
master_passwd=$(cat $config_file | grep -w mast_passwd | awk '{print $3}')
master_host=$(cat $config_file | grep -w mast_host | awk '{print $3}')

backup_path=$( cat $config_file | grep -w back_path | awk '{print $3}')
sub=$( cat $config_file | grep -w sub_path | awk '{print $3}')
mail=$(cat $config_file | grep -w mail_path | awk '{print $3}')
logs=$( cat $config_file | grep -w log_path | awk '{print $3}')
date_list=$( cat $config_file | grep -w list_path | awk '{print $3}')

server=$(cat $config_file | grep -w host_server | awk '{print $3}')
xtra_path=$(which innobackupex)
mysql_path=$(which mysql)
makedir=$(which mkdir)
cnf=$(cat $config_file | grep -w server_cnf | awk '{print $3}')
socket=$(cat $config_file | grep -w server_socket | awk '{print $3}')


#zip=$(cat $config_file | grep -w enable_compression | awk '{print $3}')
older_days=$( cat $config_file | grep -w retention_period | awk '{print $3}')
slave=$( cat $config_file | grep -w slave | awk '{print $3}')

sendmail=$( cat $config_file | grep -w sendmail_path | awk '{print $3}')
mail_host=$( cat $config_file | grep -w mail_server | awk '{print $3}')
mail_user=$( cat $config_file | grep -w user_mail | awk '{print $3}')
receiver=$( cat $config_file | grep -w mail_receive | awk '{print $3}')

  bdate=`date +'%d-%b-%Y'`
  type=`date +'%A'`
  date=`date +'%d-%b'`
  date1=`date +'%Wth-Week'`
  date2=`date +'%W'`
  year=`date +'%Y'`


mount=$(df -h | grep /scsi_vol | awk '{print $6}' | sed 's/\///g')

if [[ $mount == "scsi_vol" ]];
then
#Remove old files
rm -r /scsi_vol/backups/xtrabackup/mail/*.txt
rm -r /scsi_vol/backups/xtrabackup/mail/*.html


###################################################################################################################
                                                #Backup of data
###################################################################################################################

#Get the binary log details
if [[ "$slave" == no ]]
then
$mysql_path --user=$user --password=$password -e  "show master status;" -s -N > $mail/binlog.txt
 binlog_avb=$(ls -lrth $mail/binlog.txt | cut -c24-25)
 log_file=$(cat $mail/binlog.txt | cut -c1-16)
 log_pos=$(cat $mail/binlog.txt | cut -c18-25)
else
$mysql_path --user=$master_user --password=$master_passwd --host=$master_host -e "show master status;" -s -N > $mail/binlog.txt
 binlog_avb=$(ls -lrth $mail/binlog.txt | cut -c24-25)
 log_file=$(cat $mail/binlog.txt | cut -c1-16)
 log_pos=$(cat $mail/binlog.txt | cut -c18-25)
 fi


if [[ "$type" == Sunday ]];
then
back_type="Full Backup"
echo "Full backup"


/bin/mkdir $backup_path/$date1
/bin/mkdir $backup_path/$date1/FULL

drop=$(du -sh $backup_path/* | wc -l)
if [[ $drop -ge 2 ]] ;
then
du -sh $backup_path/* | awk '{print $2}' | head -n1 > $date_list/remove.txt
else
echo "No old files"
fi

du -sh $backup_path/$date1 | awk '{print $2}' | head -n1 > $date_list/week.txt

# Backup database
$xtra_path --user=$user --password=$password --socket=$socket --defaults-file=$cnf --slave-info --export $backup_path/$date1/FULL 1> $logs/full_xtra.log 2>>$logs/full_xtra.err
du -sh $backup_path/$date1/FULL/* | awk '{print $2}' | head -n1 > $date_list/list.txt

#Get the status
back_status=$(cat $logs/full_xtra.err | tail -n1 | cut -c32-40)
#Get the backup size
backupsize=$(du -sh $backup_path/$date1/FULL | awk '{print $1}')
#Get the backup file
backup_file=$(du -sh $backup_path/$date1/FULL | awk '{print $2}')


#To get archived backups

        if [[ $drop -ge 2 ]] ;
        then
        remove_file=$(less $date_list/remove.txt | cut -c35-43)
        arch_file=$(du -sh $backup_path/$remove_file | awk '{print $2}')
        arch_size=$(du -sh $backup_path/$remove_file | awk '{print $1}')
                                        if [[ "$back_status" == completed ]];
                                        then
                                        rm -rf $backup_path/$remove_file
                                        else
                                        echo "Backup not completed"
                                        fi
        else
        echo "No files to be archived"
        fi

else

back_type="Incremental Backup"
echo "Incremental backup"
#inc_path=$(du -sh /backup/xtraback/mysql/14-Dec-2014/* | head -n1 | awk '{print $2}')
inc_base=$(cat $date_list/list.txt)
inc_path=$(cat $date_list/week.txt)

/bin/mkdir $inc_path/INC
/bin/mkdir $inc_path/INC/$date-incr


# Backup database
$xtra_path --incremental  $inc_path/INC/$date-incr --incremental-basedir=$inc_base --user=$user --password=$password --socket=$socket --slave-info --defaults-file=$cnf 1> $logs/inc_xtra.log 2>>$logs/inc_xtra.err
du -sh $inc_path/INC/$date-incr/* | awk '{print $2}' | head -n1 > $date_list/list.txt

#Get the status
back_status=$(cat $logs/inc_xtra.err | tail -n1 | cut -c32-40)
#Get the backup size
backupsize=$(du -sh $inc_path/INC/$date-incr | awk '{print $1}')
#Get the backup file
backup_file=$(du -sh $inc_path/INC/$date-incr | awk '{print $2}')


#To get available backups

#Available backups

du -sh $backup_path/*/FULL > $mail/full_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Full Backup</center></b></td></tr> " > $mail/avb_back.txt
cat $mail/full_back.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail/avb_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Incremental Backup</center></b></td></tr>" >> $mail/avb_back.txt

for  i in `ls -lth $inc_path/INC/ | awk '{print $9}'`
do
du -sh $inc_path/INC/$i >> $mail/back_order.txt
done

cat $mail/back_order.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail/avb_back.txt
avb_inc_backup=$(cat $mail/avb_back.txt)

fi

###################################################################################################################

if [[ "$back_status" == completed ]];
then
status="Success"
color="green"
else
status="Failure"
color="red"
fi

###################################################################################################################
                                        #Sending mails
###################################################################################################################


if [[ "$back_status" == completed ]];
then
echo  "FROM: 'RupeeX Backup' <backup@laybhari.iifl.in>" >> $mail/table.html
echo  "TO: $receiver" >> $mail/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL Backup on $server is <b><font color='$color'>$status.</font></b><br>" >> $mail/table.html
echo  "<br><center><b>Binary log details</b></center><br>" >> $mail/table.html
if [[ "$binlog_avb" -ne 0 ]];
then
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Binlog File</th><th><font color='blue'>Binlog Position</th></tr><tr><td>$log_file</td><td>$log_pos</td></tr></table>" >> $mail/table.html
else
echo   "You are not using binary log.<br>" >> $mail/table.html
fi
echo  "Backup Type : <b>$back_type</b><br>" >> $mail/table.html
        if [[ $back_type == "Full Backup" ]];
        then
                echo  "<br><center><b>Full Backup size for today</b></center><br>" >> $mail/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail/table.html
                echo  "<br><center><b>Archieved backups</b></center><br>" >> $mail/table.html
                echo  "<table border='1' width='400px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $mail/table.html
        else

                echo  "<br><center><b>Incremental backup size for today</b></center><br>" >> $mail/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail/table.html

                echo  "<center><b>Available backups</b></center><br>" >> $mail/table.html
                echo  "<center><table border='1' width='400px'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$avb_inc_backup</table></center>" >> $mail/table.html
        fi

echo  "</body></html>" >> $mail/table.html
cat $mail/table.html | ssh $mail_user@$mail_host "$sendmail -i -t"

else
echo  "FROM: 'RupeeX Backup' <backup@laybhari.iifl.in>" >> $mail/table.html
echo  "TO: $receiver" >> $mail/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL Backup on $server is <b><font color='$color'>$status</font></b><br>" >> $mail/table.html
echo  "Please check the error log $error_log" >> $mail/table.html
echo  "</body></html>" >> $mail/table.html
cat $mail/table.html | ssh $mail_user@$mail_host "$sendmail -i -t"
fi

else

echo "Device not mounted"

fi

###################################################################################################################

echo "end at `date +'%d-%b-%Y %H:%M:%S'`"

###################################################################################################################

