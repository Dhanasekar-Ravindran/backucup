#!/bin/bash

#Version  : 2.0
#Purpose  : Checksum Script (To check differences between master and slave server)
#Author   : Bharath
#Company  : MyDBOPS

set -x

#Check to execute or not
run_day=`date +%d`

if [[ $run_day == 20 || $run_day == 29 ]];then

echo "execute the script"

############################################################################################################################################

###################################################################

#Edit the needed changes

check_user="pt_check"
check_paswd="pt@check"
port="3339"
slave_host="172.16.3.21"
sub_path="/home/mydbops/checksum/sub"
checksum=$(which pt-table-checksum)
mysql_path=$(which mysql)
date=`date +%d_%m_%y_%HAm`

###################################################################

db_list=`$mysql_path --user=$check_user --password=$check_paswd --port=$port -e "select SCHEMA_NAME from information_schema.schemata where schema_name not in ('mysql','test','performance_schema','information_schema','percona') order by SCHEMA_NAME desc;" -s -N  | awk 'ORS=NR?" ":"\n"'`


> $sub_path/final_result.txt
> $sub_path/diff_result.txt
> $sub_path/diff_mail.txt

 for db_name in $db_list

 do
 echo "Database : $db_name " >> $sub_path/final_result.txt
 echo "" >> $sub_path/final_result.txt
 echo "            TS ERRORS  DIFFS     ROWS  CHUNKS SKIPPED    TIME TABLE " >> $sub_path/final_result.txt
 echo "" >> $sub_path/final_result.txt

 echo "Database : $db_name " >> $sub_path/diff_result.txt
 echo "" >> $sub_path/diff_result.txt
 echo "            TS ERRORS  DIFFS     ROWS  CHUNKS SKIPPED    TIME TABLE " >> $sub_path/diff_result.txt
 echo "" >> $sub_path/diff_result.txt

 table_list=`$mysql_path --user=$check_user --password=$check_paswd --port=$port -e "select table_name from information_schema.tables where table_schema='$db_name' order by ((data_length+index_length)/(1024*1024));" -s -N  | awk 'ORS=NR?" ":"\n"'`

 for tbl_name in $table_list

 do
 #Example of a checksum command
 #pt-table-checksum  u=pt_check,p=pt@check,P=3339 --set-vars innodb_lock_wait_timeout=200 --no-check-binlog-format --recursion-method=dsn="h=172.16.3.21,P=3339,D=percona,t=dsns" --databases=bodb --tables=masterorgn_aud,mastertds_aud

 $checksum u=$check_user,p=$check_paswd,P=$port --set-vars innodb_lock_wait_timeout=200 --no-check-binlog-format --recursion-method=dsn="h=$slave_host,P=$port,D=percona,t=dsns" --databases=$db_name --tables=$tbl_name | tail -n1 > $sub_path/first_check.txt

 cat $sub_path/first_check.txt | awk '{print $3}' > $sub_path/diff_check.txt

 diff=$(cat $sub_path/diff_check.txt)

 cat $sub_path/first_check.txt  > $sub_path/diff_mail_raw.txt

 if [[ $diff -ge 1 ]]; then
 echo "differences found on table $db_name.$tbl_name"
 cat $sub_path/first_check.txt >> $sub_path/diff_result.txt
 cat $sub_path/diff_mail_raw.txt >> $sub_path/diff_mail.txt
  else
 echo "No differences on table $db_name.$tbl_name"
 cat $sub_path/first_check.txt >> $sub_path/final_result.txt

 fi

 done

 echo "" >> $sub_path/final_result.txt
 done

table_error=$(cat $sub_path/diff_mail_raw.txt | wc -l)

> $sub_path/mail_file.txt

echo  "Hi Team," >> $sub_path/mail_file.txt
echo  "" >> $sub_path/mail_file.txt
echo  "The checksum report between servers Rupeex master (172.16.3.22) and slave (172.16.3.21) at $date has been attached."  >> $sub_path/mail_file.txt
echo  "" >> $sub_path/mail_file.txt
if [[ $table_error -ge 2 ]]; then
echo  "Difference found on tables!. The details are as follows"  >> $sub_path/mail_file.txt
echo  "" >> $sub_path/mail_file.txt
echo  "" >> $sub_path/mail_file.txt
cat   $sub_path/diff_mail.txt >> $sub_path/mail_file.txt
fi
echo  "" >> $sub_path/mail_file.txt
echo  "Please find the table checksum report."  >> $sub_path/mail_file.txt
echo  "" >> $sub_path/mail_file.txt
echo  "Regards,"  >> $sub_path/mail_file.txt
echo  "MyDBOPS ALERTS" >> $sub_path/mail_file.txt
echo  "(Alerts)"  >> $sub_path/mail_file.txt

ssh mydbops@172.16.3.23 "rm -r /home/mydbops/final_result.txt"
scp $sub_path/final_result.txt mydbops@172.16.3.23:/home/mydbops/final_result.txt

#Sent the mail
cat $sub_path/mail_file.txt | ssh mydbops@172.16.3.23  "mail -s '$(echo -e 'Checksum Report\nFrom: RupeeX Checksum Report <alert@mydbops.com> \n')' -a '/home/mydbops/final_result.txt' dba-group@mydbops.com"

exit


############################################################################################################################################

else

echo "script wont run today"
echo "Today is `date`"
fi

