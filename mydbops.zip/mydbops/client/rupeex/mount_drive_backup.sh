#!/bin/sh
#!/bin/bash
#Version : 1.3
#Purpose : Backup_copy_script
set -x
##################################################################
                              #paths
##################################################################
slve_21=/scsi_vol/backups/xtrabackup/data/*Week
slve_36=/scsi_vol/backups/Backup_Intranet_DB/xtrabackup/data/*Week
tvar=/scsi_vol/backups/Backup_AMC_DB/xtrabackup/data/*Week
c_slave_21=/CaliberBKP/slave_21/
c_slave_36=/CaliberBKP/slave_36/
c_tevar=/CaliberBKP/tevar/
##################################################################
ST=$(date +'%d-%b-%Y %H:%M:%S')
ip=$(ip a | head -n8 | tail -n1 | awk '{print $2}' | cut -c1-11)
total1=$(df -h | tail -n1 | awk '{printf $1}' | sed -e 's/G/ /g')
total=$(df -h | tail -n1 | awk '{printf $1}')
avail1=$(df -h | tail -n1 | awk '{print $3}' | sed -e 's/G/ /g')
avail=$(df -h | tail -n1 | awk '{print $3}' )
receiver="dba-group@mydbops.com"
echo  "FROM: 'Caliber Backup Copy ' <backup-copy@mydbops.com>" > /tmp/caliber.html
echo  "TO: $receiver" >> /tmp/caliber.html
echo  "SUBJECT: Backup Status Of Rupeex Server" >> /tmp/caliber.html
echo  "Content-type: text/html" >> /tmp/caliber.html
echo  "<html><body>" >> /tmp/caliber.html
echo  "Hi Team, <br><br>Caliber Backup from Rupeex_Slave_21($ip)<br><br>Backup Started at $ST" >> /tmp/caliber.html
echo  "<br>Total Available Disk Space is $avail" >> /tmp/caliber.html
val=`expr "$total1 - $avail1" `
if [[ $val -ge 240 ]];    #Checks disk space is available or not
then #Start copying if available
cp -r $slve_36 $c_slave_36
CT=$(date +'%d-%b-%Y %H:%M:%S')
echo  "<br>The Slave_36 backup is Copied Successfully at $CT<br>" >> /tmp/caliber.html
slave_36=$(du -sh $c_slave_36* | awk '{print $2}')
cp -r $tvar $c_tevar
CT1=$(date +'%d-%b-%Y %H:%M:%S')
echo  "<br>The Tevar backup is Copied Successfully at $CT1<br>" >> /tmp/caliber.html
tevar=$(du -sh $c_tevar* | head -n1 | awk '{print $2}' )
cp -r $slve_21 $c_slave_21
CT2=$(date +'%d-%b-%Y %H:%M:%S')
echo  "<br>The Slave_21 backup is Copied Successfully at $CT2<br>">> /tmp/caliber.html
Slave_21=$(du -sh $c_slave_21* | tail -n1 | awk '{print $2}' )
echo  "<br><br>Backup Path : <br>" >> /tmp/caliber.html
echo "<br>Slave_36      -   $c_slave_36<br>Tevar           -   $c_tevar<br>Slave_21      -   $c_slave_21" >> /tmp/caliber.html
ET=$(date +'%d-%b-%Y %H:%M:%S')
echo "<br><br>BackCompleted at $ET<br><br><br>Regards,<br>Mydbops Monitoring<br>(Alerts)" >> /tmp/caliber.html
scp -r /tmp/caliber.html mydbops@172.16.3.23:/tmp/
sleep 2;
ssh mydbops@172.16.3.23 "cat /tmp/caliber.html | sendmail $receiver"
else #Trigger mail about no available disk space to our group .
echo "Hi Team,<br><br>Caliber Backup from Rupeex_Slave_21($ip)<br><br>No disk space Available in the /CaliberBKP drive.<br><br>Please Check it.<br><br>Regards,<br>Mydbops Monitoring<br>(Alerts)" > /tmp/mailerr.html
scp -r /tmp/mailerr.html mydbops@172.16.3.23:/tmp/
sleep 2;
ssh mydbops@172.16.3.23  "cat /tmp/mailerr.html | sendmail $receiver"
fi
