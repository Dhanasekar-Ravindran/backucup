#!/bin/bash
#!/bin/sh

#Version : 1.1.0
#Author  : mydbops.com
#Purpose : purge binary logs

set -x
source "/home/rupeexmon/monitor/binlog_purge/config"

date=`date '+%d-%m-%y %H:%M:%S'`

#Checking older logs in master and slave server

ssh $host1 "find  $datadir/mysql-bin.0* -mtime +$days -exec ls -lrt {} \;"  > $sub_path/master_list.txt
ssh $host2 "find $datadir/mysql-bin.0* -mtime +$days -exec ls -lrt {} \;"  > $sub_path/slave_list.txt

mast_yes=$(cat $sub_path/master_list.txt | wc -l)
slave_yes=$(cat $sub_path/slave_list.txt | wc -l)

#Collect the status
ssh $host1 "mysql --login-path=mydbops -e 'show master status;'" -s -N > $sub_path/master_status.txt
ssh $host2 "mysql --login-path=mydbops -e  'show slave status\G'" > $sub_path/slave_status.txt

    slave_io=$(cat $sub_path/slave_status.txt | grep -w Slave_IO_Running | awk '{print $2}')
	slave_sql=$(cat $sub_path/slave_status.txt | grep -w Slave_SQL_Running | awk '{print $2}')
    sec_behind=$(cat $sub_path/slave_status.txt | grep -w Seconds_Behind_Master | awk '{print $2}')
	
#Area to collect status and proceed
#####################################################################################################################
if [[ $mast_yes -ge 1 ]]; then

cat $sub_path/master_list.txt | awk '{print $9}' | xargs -n1 basename >  $sub_path/master_log_list.txt
last_mast_log=$(cat $sub_path/master_log_list.txt | tail -n1)
mast_size=$(cat $sub_path/master_list.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')

	if [[ $slave_io == Yes  && $slave_sql == Yes ]]; then
	#Purge on master server
		ssh $host1 "mysql --login-path=mydbops -e 'purge binary logs to \"$last_mast_log\";'"
		echo "purge logs to $last_mast_log"
			master_purge="yes"
			master_stats="Binary logs purged"
			master_cmd=$(echo "PURGE BINARY LOGS TO '$last_mast_log'")
			mast_log_size=$(cat $sub_path/master_list.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
			ssh $host1 "ls -lrt $datadir/mysql-bin.0*" > $sub_path/master_no_purge.txt
			mast_avlb_log_size=$(cat $sub_path/master_no_purge.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
			mast_total=$(cat $sub_path/master_no_purge.txt | wc -l)
			
	else
		master_purge="not"
		echo "replication is not running/in lag"
	fi	

else
            master_purge="no"
            master_stats="No retention logs to purge"
			ssh $host1 "ls -lrt $datadir/mysql-bin.0*" > $sub_path/master_no_purge.txt
			mast_log_size=$(cat $sub_path/master_no_purge.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
			mast_total=$(cat $sub_path/master_no_purge.txt | wc -l)

fi

if [[ $master_purge == not ]] ;then

	echo "no purge on slave"

else
	if [[ $slave_yes -ge 1 ]]; then

	cat $sub_path/slave_list.txt | awk '{print $9}' | xargs -n1 basename >  $sub_path/slave_log_list.txt
	last_slave_log=$(cat $sub_path/slave_log_list.txt | tail -n1)
	slave_size=$(cat $sub_path/slave_list.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')

	#Purge on slave server
			ssh $host2 "mysql --login-path=mydbops -e 'purge binary logs to \"$last_slave_log\";'"
			echo "purge logs to $last_slave_log"
				slave_purge=yes
				slave_stats=$(echo "Binary logs purged")
				slave_cmd=$(echo "PURGE BINARY LOGS TO '$last_slave_log'")
				slave_tot=$(echo "$slave_cnt" )
				slav_log_size=$(cat $sub_path/slave_list.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
				ssh $host2 "ls -lrt $datadir/mysql-bin.0*" > $sub_path/slave_no_purge.txt
				slav_avlb_log_size=$(cat $sub_path/slave_no_purge.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
				slave_total=$(cat $sub_path/slave_no_purge.txt | wc -l)
				
	else
				slave_purge=no
				master_stats=$(echo "No retention logs to purge")
				ssh $host2 "ls -lrt $datadir/mysql-bin.0*" > $sub_path/slave_no_purge.txt
				slav_log_size=$(cat $sub_path/slave_no_purge.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
				slave_total=$(cat $sub_path/slave_no_purge.txt | wc -l)
	fi
fi

#####################################################################################################################

echo  "FROM:'Binlog_purge_$client'<binlog_purge@mydbops.com>" > $sub_path/mail.html
echo  "TO: $receiver" >> $sub_path/mail.html
echo  "SUBJECT: Binary Logs Purged status report - $client_name  at $date ">> $sub_path/mail.html
echo  "Content-type: text/html" >> $sub_path/mail.html
echo  "<html><body>" >> $sub_path/mail.html
echo  "Hi Team,<br><br>" >> $sub_path/mail.html

if [[ $master_purge == not ]] ;then
echo "<br>" >> $sub_path/mail.html
echo "Binary logs not purged on master server"  >> $sub_path/mail.html
echo "$slave_io" >> $sub_path/mail.html
echo "$slave_sql" >> $sub_path/mail.html
echo "$sec_behind" >> $sub_path/mail.html

else
	echo "Binary logs were purged on $client servers!<br><br>" >> $sub_path/mail.html
	echo "The details are as follows :-<br><br>" >> $sub_path/mail.html
	if [[ $master_purge == yes ]];then
	echo "<br>"  >> $sub_path/mail.html
	echo "<b>Details for Master Server </b><br><br>" >> $sub_path/mail.html
	echo "<table border="1" width="550" cellpadding="4" cellspacing="0">" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Status</font></b></td><td>$master_stats</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Command Used</font></b></td><td>$master_cmd</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Purged </font></b></td><td>$mast_yes</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Purged Binlog Size</font></b></td><td>$mast_size GB</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Last Purged Binlog</font></b></td><td> $last_mast_log </td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Retention Method</font></b></td><td> 8 Days older </td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Available </font></b></td><td>$mast_total</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Available Binlogs Size</font></b></td><td>$mast_avlb_log_size GB</td></tr>" >> $sub_path/mail.html
	echo "</table>" >> $sub_path/mail.html
	echo "<br><br>" >> $sub_path/mail.html
	else
	echo "<b>Details for Master Server </b><br><br>" >> $sub_path/mail.html
	echo "<table border="1" width="450" cellpadding="4" cellspacing="0">" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Status</font></b></td><td>$master_stats</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Retention Method</font></b></td><td> 8 Days older</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Available </font></b></td><td>$mast_total</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Available Binlog Size</font></b></td><td>$mast_log_size GB</td></tr>" >> $sub_path/mail.html
	echo "</table>" >> $sub_path/mail.html
	echo "<br><br>" >> $sub_path/mail.html
	fi

	if [[ $slave_purge == yes ]];then
	echo "<b>Details for Slave Server </b><br><br>" >> $sub_path/mail.html
	echo "<table border="1" width="550" cellpadding="4" cellspacing="0">" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Status</font></b></td> <td>$slave_stats</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Command Used</font></b></td> <td>$slave_cmd</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Purged </font></b></td>  <td>$slave_yes</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Purged Binlog Size</font></b></td> <td>$slave_size GB</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Last Purged Binlog</font></b></td> <td> $last_slave_log </td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Retention Method</font></b></td> <td> 8 Days older </td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Available </font></b></td>  <td>$slave_total</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Available Binlogs Size</font></b></td><td>$slav_avlb_log_size GB</td></tr>" >> $sub_path/mail.html
	echo "</table>" >> $sub_path/mail.html
	echo "<br><br>" >> $sub_path/mail.html
	else
	echo "<b>Details for Slave Server </b><br><br>" >> $sub_path/mail.html
	echo "<table border="1" width="450" cellpadding="4" cellspacing="0">" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Status</font></b></td><td>$slave_stats</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Retention Method</font></b></td><td> 8 Days older</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Available </font></b></td><td>$slave_total</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Available Binlog Size</font></b></td><td>$slave_log_size GB</td></tr>" >> $sub_path/mail.html
	echo "</table>" >> $sub_path/mail.html
	echo "<br><br>" >> $sub_path/mail.html
	fi

fi

echo "<br>" >> $sub_path/mail.html						
echo "<br />Regards,<br>Mydbops Monitoring<br>(Alerts)</body></html> " >> $sub_path/mail.html
cat $sub_path/mail.html | $sendmail -i -t
