#!/bin/sh
#!/bin/bash
#Version : 1.2
set -x
c="ssh claymx"
cp=$($c "date +%d:%m:%Y:%H:%M:%S")
tz="TZ=Asia/Kolkata"
pri="awk '{print \$6,\$7}'"
$c "cp -r /tmp/config.txt /tmp/config/config@$cp.txt"
last1=$(ls --full-time /tmp/table.html | awk '{print $6,$7}' | cut -c1-19)
$c "pt-config-diff /etc/my.cnf localhost,u=root,p=Claymotion@123 > /tmp/config.txt"
$c "less /tmp/config.txt | sed -e '3d' > /tmp/config_.txt"
last=$($c "$tz ls --full-time /tmp/config.txt | awk '{print \$6,\$7}' | cut -c1-19 ")
line=$($c "cat /tmp/config_.txt | wc -l")
l=$($c "cat /tmp/config_.txt | head -n1 | awk '{print \$1}'")
file1=$($c "cat /tmp/config_.txt | head -n2 | tail -n1 | awk '{print \$2}'" )
host1=$($c "cat /tmp/config_.txt | head -n2 | tail -n1 | awk '{print \$3}' ")
echo  "FROM: 'Config Diff Alert ' <config-diff-alert@mydbops.com>" > /tmp/table.html
echo  "TO: dba-group@mydbops.com" >> /tmp/table.html
echo  "SUBJECT: Config File Modification Detected in Claymx server at $last" >> /tmp/table.html
echo  "Content-type: text/html" >> /tmp/table.html
echo  "<html><body>" >> /tmp/table.html
echo  "Hi Team,<br><br>Configuration File has a Difference.<br><br>Kindly verify it.<br>Number of Differences Found : $l<br><br>">>  /tmp/table.html
echo  "<table border='1' width='750px' align='center' cellpadding='1' cellspacing='1'><tr align='center'><th><font color='black'>Variables</th><th><font color='violet'>$file1</th><th><font color='violet'>$host1</th></tr>" >> /tmp/table.html
a=3
while [[ "$a" -le "$line" ]];
do
  val1=$($c "cat /tmp/config_.txt | head -n$a | tail -n1 | awk '{print \$1}' ")
  val2=$($c "cat /tmp/config_.txt | head -n$a | tail -n1 | awk '{print \$2}'")
  val3=$($c "cat /tmp/config_.txt | head -n$a | tail -n1 | awk '{print \$3}'")
  echo "<tr><td>$val1</td><td>$val2</td><td>$val3</td></tr>" >> /tmp/table.html
  a=`expr $a + 1`
done
echo  "</table></body></html>" >> /tmp/table.html
echo Last modified at $last1 >> /tmp/table.html
echo "<br><br><br>Regards,<br>Mydbops Monitoring<br>(Alerts)<br>" >> /tmp/table.html
cat /tmp/table.html | /usr/sbin/sendmail dba-group@mydbops.com
