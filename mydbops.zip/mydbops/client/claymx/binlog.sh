#!/bin/bash
#!/bin/sh

#Version : 1.1.0
#Author  : mydbops.com
#Purpose : purge binary logs

set -x
source "/home/mymon/monitor/binlog_purge/claymx/config"

date=`date '+%d-%m-%y %H:%M:%S'`

#Checking older logs in master and slave server

ssh $host1 "find  $datadir/mysql-bin.0* -mtime +$days -exec ls -lrt {} \;"  > $sub_path/master_list.txt

mast_yes=$(cat $sub_path/master_list.txt | wc -l)

	
#Area to collect status and proceed
#####################################################################################################################
if [[ $mast_yes -ge 1 ]]; then

cat $sub_path/master_list.txt | awk '{print $9}' | xargs -n1 basename >  $sub_path/master_log_list.txt
last_mast_log=$(cat $sub_path/master_log_list.txt | tail -n1)
mast_size=$(cat $sub_path/master_list.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')

		ssh $host1 "mysql --login-path=mydbops -e 'purge binary logs to \"$last_mast_log\";'"
		echo "purge logs to $last_mast_log"
			master_purge="yes"
			master_stats="Binary logs purged"
			master_cmd=$(echo "PURGE BINARY LOGS TO '$last_mast_log'")
			mast_log_size=$(cat $sub_path/master_list.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
			ssh $host1 "ls -lrt $datadir/mysql-bin.0*" > $sub_path/master_no_purge.txt
			mast_avlb_log_size=$(cat $sub_path/master_no_purge.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
			mast_total=$(cat $sub_path/master_no_purge.txt | wc -l)
			
else
            master_purge="no"
            master_stats="No retention logs to purge"
			ssh $host1 "ls -lrt $datadir/mysql-bin.0*" > $sub_path/master_no_purge.txt
			mast_log_size=$(cat $sub_path/master_no_purge.txt | awk '{ total += $5 / (1024*1024*1024) }; END { print total }')
			mast_total=$(cat $sub_path/master_no_purge.txt | wc -l)

fi

#####################################################################################################################

echo  "FROM:'Binlog_purge_$client'<binlog_purge@mydbops.com>" > $sub_path/mail.html
echo  "TO: $receiver" >> $sub_path/mail.html
echo  "SUBJECT: Binary Logs Purged status report - $client_name  at $date ">> $sub_path/mail.html
echo  "Content-type: text/html" >> $sub_path/mail.html
echo  "<html><body>" >> $sub_path/mail.html
echo  "Hi Team,<br><br>" >> $sub_path/mail.html
	echo "Binary logs were purged on $client servers!<br><br>" >> $sub_path/mail.html
	echo "The details are as follows :-<br><br>" >> $sub_path/mail.html
	if [[ $master_purge == yes ]];then
	echo "<br>"  >> $sub_path/mail.html
	echo "<b>Details for Master Server </b><br><br>" >> $sub_path/mail.html
	echo "<table border="1" width="550" cellpadding="4" cellspacing="0">" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Status</font></b></td><td>$master_stats</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Command Used</font></b></td><td>$master_cmd</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Purged </font></b></td><td>$mast_yes</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Purged Binlog Size</font></b></td><td>$mast_size GB</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Last Purged Binlog</font></b></td><td> $last_mast_log </td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Retention Method</font></b></td><td> 8 Days older </td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Available </font></b></td><td>$mast_total</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Available Binlogs Size</font></b></td><td>$mast_avlb_log_size GB</td></tr>" >> $sub_path/mail.html
	echo "</table>" >> $sub_path/mail.html
	echo "<br><br>" >> $sub_path/mail.html
	else
	echo "<b>Details for Master Server </b><br><br>" >> $sub_path/mail.html
	echo "<table border="1" width="450" cellpadding="4" cellspacing="0">" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Status</font></b></td><td>$master_stats</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Retention Method</font></b></td><td> 8 Days older</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Binlogs Available </font></b></td><td>$mast_total</td></tr>" >> $sub_path/mail.html
	echo "<tr><td><b><font color='blue'>Available Binlog Size</font></b></td><td>$mast_log_size GB</td></tr>" >> $sub_path/mail.html
	echo "</table>" >> $sub_path/mail.html
	echo "<br><br>" >> $sub_path/mail.html
	fi
echo "<br>" >> $sub_path/mail.html						
echo "<br />Regards,<br>Mydbops Monitoring<br>(Alerts)</body></html> " >> $sub_path/mail.html
cat $sub_path/mail.html | $sendmail -i -t
