#!/bin/bash

set -x

path=/home/mydbops/purge

/usr/bin/mysql --login-path=mydbops -e "select table_name from information_schema.tables where table_schema='playgps_trial' and table_name like 'gs_tracker_data_%';" -s -N > $path/tables.txt

tabl=$(awk 'ORS=NR%10?" ":"\n"' $path/tables.txt)

for tb in $tabl

do

mysql --login-path=mydbops -e "select count(*) from playgps_trial.$tb where dt_server < DATE_SUB(NOW(), INTERVAL 90 DAY);" -s -N  > $path/count.txt

tot_cnt=$(cat $path/count.txt)

echo " Total count of records for table playgps_trial.$tb : $tot_cnt" >> $path/status.txt

for (( i=0; i<=$tot_cnt; i=i+1000 ))

do

/usr/bin/mysql --login-path=mydbops -e "delete from playgps_trial.$tb where dt_server < DATE_SUB(NOW(), INTERVAL 90 DAY) limit 1000;SELECT ROW_COUNT();select sleep(2);"
echo $i

done

#Optimize the table now
/usr/bin/mysql --login-path=mydbops -vvv -e "optimize table playgps_trial.$tb;" 1>>$path/opt.log 2>>$path/opt.err

done

