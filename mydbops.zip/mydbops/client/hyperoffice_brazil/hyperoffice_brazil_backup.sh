#!/bin/sh
#!/bin/bash

#Version : 2.1
#Purpose : Backup_script
#Author  : Mydbops

set -x
###################################################################################################################
                                                #Config Details
###################################################################################################################
echo "start at `date +'%d-%b-%Y %H:%M:%S'`"

#source /export/backup/xtraback/config

source /etc/xtrabackup.conf

check_time=`date +'%a-%H:%M'`

  bdate=`date +'%d-%b-%Y'`
  type=`date +'%A'`
  week=`date +'%Wth-Week'`
  chk_time=`date +'%d-%a-%H_%M'`

  mysql_path=$(which mysql)
  xtra_path=$(which innobackupex)

##Initial check of backup mount point

avb_mnt=$(df -h | grep export | awk '{print $5}')
 
 if [[ $mount_point == $avb_mnt ]] ; then
 
 echo "Do the backup"
  
echo "Started : `date +'%d-%b-%Y %H:%M:%S'`" > $list_path/back_details.txt
echo "Host : $host_address" >> $list_path/back_details.txt
echo "Client : $client_name" >> $list_path/back_details.txt
echo "Back_Method : Hot" >> $list_path/back_details.txt

#Remove old files
rm -r /backup/mail/*.txt
rm -r /backup/mail/*.html

###################################################################################################################
                                                #Backup of data
###################################################################################################################

#Backup of data

#if [[ "$type" == $back_day ]];
if [[ "$type" == $back_day && $check_time == $back_time ]];
then
echo "Backup_Type : Full Backup" >> $list_path/back_details.txt
echo "Full Backup"
back_type="Full Backup"

#***************************Full backup part*******************************#

/bin/mkdir $back_path/$week
/bin/mkdir $log_path/$week

/bin/mkdir $log_path/$week/fullback
/bin/mkdir $log_path/$week/incback

echo "$back_path/$week" > $sub_path/inc_bck_path.txt
echo "$log_path/$week/incback" >> $sub_path/inc_bck_path.txt

host_list=`mysql -e "select host_name from percona.backup;"  -s -N | awk '{print $1}' ORS=' ' `

for host_ip in $host_list
do
echo "$host_ip"
/bin/mkdir $back_path/$week/$host_ip
db_name=`mysql -e "select shard_db from percona.backup where host_name='$host_ip';" -s -N`
mas_name=`mysql -e "select host from percona.backup where host_name='$host_ip';" -s -N`
echo "$db_name"
/bin/mkdir $back_path/$week/$host_ip/fullback
/bin/mkdir $back_path/$week/$host_ip/incback

$mysql_path --user=$back_user --password=$back_password --host=$mas_name -e "show master status;" -s -N > $sub_path/$host_ip-binlog.txt

bin_file=$(cat $sub_path/$host_ip-binlog.txt | awk '{print $1}')
bin_pos=$(cat $sub_path/$host_ip-binlog.txt | awk '{print $2}')

# Backup database
$xtra_path --user=$back_user --password=$back_password --socket=$server_socket --defaults-file=$server_cnf --no-lock --databases="$db_name" $back_path/$week/$host_ip/fullback/$host_ip-$chk_time  --no-timestamp 1>$log_path/$week/fullback/$host_ip.log 2>$log_path/$week/fullback/$host_ip.err

#Get the status
back_status=$(cat $log_path/$week/fullback/$host_ip.err | tail -n1 | cut -c32-40)
if [[ "$back_status" == completed ]];
then
echo "Backup_Status on $host_ip : $back_status" >> $list_path/back_details.txt
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set status='Completed' where host_name='$host_ip';"
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set inc_path='$back_path/$week/$host_ip/fullback/$host_ip-$chk_time',full_path='$back_path/$week/$host_ip/fullback/$host_ip-$chk_time' where host_name='$host_ip';"
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set binlog_file='$bin_file',binlog_pos='$bin_pos' where host_name='$host_ip';"
#Get the backup size & file
du -sh $back_path/$week/$host_ip/fullback/$host_ip-$chk_time > $list_path/full_back_det.txt
#Get the backup size
backupsize=$(cat $list_path/full_back_det.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $date_list/back_details.txt
#Get the backup file
backupfile=$(cat $list_path/full_back_det.txt | awk '{print $2}')
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set backup_file='$backupfile',backup_size='$backupsize' where host_name='$host_ip';"
else
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set status='Not Completed' where host_name='$host_ip';"
#need to send mail
fi
done
###############################################################
#To get archived backup folder(added on 06-11-2015)
$mysql_path --user=$back_user --password=$back_password -e "select count(*) from percona.backup where status='Completed';" -s -N > $list_path/succs_count.txt
suc_cnt=$(cat $list_path/succs_count.txt)
if [[ $suc_cnt == 5 ]]; then
back_status="completed"
echo "can purge one week old folder"
purge_file=$(ls -lrth $back_path/ | grep Week | grep -v $week | awk '{print $9}')
du -sh $back_path/$purge_file > $sub_path/old_file.txt
arch_file=$(cat $sub_path/old_file.txt | awk '{print $2}')
arch_size=$(cat $sub_path/old_file.txt | awk '{print $1}')
if [[ $purge_file == $week ]];then
echo "don't purge"
else
rm -rf $back_path/$purge_file
fi
else
back_status="not completed"
echo "don't purge old folder"
fi
###############################################################

#*************************Full backup part*******************************#

else
#Go for incremental backup
back_type="Incremental Backup"
echo "Backup_Type : Incremental" >> $list_path/back_details.txt
echo "Incremental backup"

#*************************Inc backup part*******************************#

bk_path_today=$(cat $sub_path/inc_bck_path.txt | head -n1)
logfile_path=$(cat $sub_path/inc_bck_path.txt | tail -n1)

host_list=`mysql -e "select host_name from percona.backup;"  -s -N | awk '{print $1}' ORS=' ' `

for host_ip in $host_list
do
echo "$host_ip"
db_name=`mysql -e "select shard_db from percona.backup where host_name='$host_ip';" -s -N`
mas_name=`mysql -e "select host from percona.backup where host_name='$host_ip';" -s -N`
echo "$db_name"
inc_base=`mysql -e "select inc_path from percona.backup where host_name='$host_ip';" -s -N`

$mysql_path --user=$back_user --password=$back_password --host=$mas_name -e "show master status;" -s -N > $sub_path/$host_ip-binlog.txt

bin_file=$(cat $sub_path/$host_ip-binlog.txt | awk '{print $1}')
bin_pos=$(cat $sub_path/$host_ip-binlog.txt | awk '{print $2}')

# Backup database
$xtra_path --user=$back_user --password=$back_password --socket=$server_socket --defaults-file=$server_cnf --no-lock --databases="$db_name" --incremental $bk_path_today/$host_ip/incback/$host_ip-$chk_time --incremental-basedir=$inc_base --no-timestamp 1>$logfile_path/$host_ip.log 2>$logfile_path/$host_ip.err

#Get the status
back_status=$(cat $logfile_path/$host_ip.err | tail -n1 | cut -c32-40)
if [[ "$back_status" == completed ]];
then
echo "Backup_Status on $host_ip : $back_status" >> $list_path/back_details.txt
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set status='Completed' where host_name='$host_ip';"
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set binlog_file='$bin_file',binlog_pos='$bin_pos' where host_name='$host_ip';"
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set inc_path='$bk_path_today/$host_ip/incback/$host_ip-$chk_time' where host_name='$host_ip';"
#Get the backup size & file
du -sh $bk_path_today/$host_ip/incback/$host_ip-$chk_time > $list_path/inc_back_det.txt
#Get the backup size
backupsize=$(cat $list_path/inc_back_det.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $date_list/back_details.txt
#Get the backup file
backupfile=$(cat $list_path/inc_back_det.txt | awk '{print $2}')
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set backup_file='$backupfile',backup_size='$backupsize' where host_name='$host_ip';"

###############################################################
#To get available backups(added on 06-11-2015)
shards="shard_1-2 shard_3-4 shard_5-6 shard_7-8 shard_9-10"
rm -r $sub_path/avlb_back.txt
echo "<table border="1" cellpadding="0" align='center' cellspacing="0">" >> $sub_path/avlb_back.txt
echo "<tr><td align='center'><span style='font-weight:bold'>Shard Host</span></td><td align='center'><span style='font-weight:bold'>Backup_Type</span></td><td align='center'><span style='font-weight:bold'>Backup File-Full Path</span></td><td align='center'><span style='font-weight:bold'>Backup_Size</span></td></tr>" >> $sub_path/avlb_back.txt
for shard in $shards
do
du -sh $bk_path_today/$shard/fullback/*  > $sub_path/full_list.txt
du -sh $bk_path_today/$shard/incback/* | sed -n '1{h;T;};G;h;$p;' > $sub_path/inc_list.txt
inc_cnt=$(cat $sub_path/inc_list.txt | wc -l)
full_cnt=$(( $inc_cnt + 1 ))
echo "<tr><td></td><td></td><td></td><td></td></tr>" >> $sub_path/avlb_back.txt
cat $sub_path/full_list.txt | awk '{print "<tr><td rowspan='$full_cnt' align='center' style='color:red'><span style='font-weight:bold'>'$shard'</span></td><td align='center' style='color:blue'><span style='font-weight:bold'>Full Backup</span></td><td style='color:blue'>",$2,"</td><td align='center' style='color:blue' >",$1,"</td></tr>"}' >> $sub_path/avlb_back.txt
cat $sub_path/inc_list.txt | head -n1 | awk '{print "<tr><td rowspan='$inc_cnt' align='center'><span style='font-weight:bold'>Incremental Backup</span></td><td>",$2,"</td><td align='center'>",$1,"</td></tr>"}' >> $sub_path/avlb_back.txt
cat $sub_path/inc_list.txt | tail -n +2 | awk '{print "<tr><td>",$2,"</td><td align='center'>",$1,"</td></tr>"}' >> $sub_path/avlb_back.txt
done
echo "<tr><td></td><td></td><td></td><td></td></tr>" >> $sub_path/avlb_back.txt
echo "</table>" >> $sub_path/avlb_back.txt
avlb_bcks=$(cat $sub_path/avlb_back.txt)
###############################################################

else
$mysql_path --user=$back_user --password=$back_password -e "update percona.backup set status='Not Completed' where host_name='$host_ip';"
#need to send mail
fi
done
fi

#*************************Inc backup part*******************************#

echo "Ended : `date +'%d-%b-%Y %H:%M:%S'`" >> $list_path/back_details.txt

$mysql_path --user=$back_user --password=$back_password -e "select count(*) from percona.backup where status='Completed';" -s -N > $list_path/succs_count.txt
$mysql_path --user=$back_user --password=$back_password -e "select host_name as 'Shard Host',binlog_file as 'Binlog File',binlog_pos as 'Binlog Position' from percona.backup order by host_name;" --html > $list_path/binlog_detail.txt
$mysql_path --user=$back_user --password=$back_password -e "select host_name as 'Shard Host',backup_file as 'Backup File-Full Path',backup_size as 'File Size' from percona.backup order by host_name;" --html > $list_path/today_backup_detail.txt

sed 's/<TABLE BORDER=1>/<table border='1' width='600px' align='center' cellpadding='0' cellspacing='0'>/g'  $list_path/today_backup_detail.txt > $list_path/today_backup_details.txt

sed 's/<TABLE BORDER=1>/<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'>/g'  $list_path/binlog_detail.txt >  $list_path/binlog_details.txt

backup_details=$(cat $list_path/today_backup_details.txt)
bin_log_details=$(cat $list_path/binlog_details.txt)

sucs_cnt=$(cat $list_path/succs_count.txt)

if [[ $sucs_cnt == 5 ]]; then
back_status="completed"
status="Success"
color="green"
else
back_status="not completed"
status="Failure"
color="red"
fi

#Part to send mail
if [[ "$back_status" == completed ]];
then
echo  "FROM: 'Hyperoffice_Brazil_Backup' <backup@mydbops.com>" > $mail/table.html
echo  "TO: $receiver" >> $mail/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL Backup on $server ($host_address) is <b><font color='$color'>$status.</font></b><br>" >> $mail/table.html
echo  "<br><center><b>Binary log details</b></center><br>" >> $mail/table.html
echo  "$bin_log_details <br><br>"  >> $mail/table.html
echo  "Backup Type : <b>$back_type</b><br>" >> $mail/table.html
        if [[ $back_type == "Full Backup" ]];
        then
                echo  "<br><center><b>Full Backup size for today</b></center><br>" >> $mail/table.html
                echo  "<center>$backup_details</center>" >> $mail/table.html

                echo  "<br><center><b>Archieved backups</b></center><br>" >> $mail/table.html
                echo  "<table border='1' width='400px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $mail/table.html
        else

                echo  "<br><center><b>Incremental backup size for today</b></center><br>" >> $mail/table.html
                echo  "<center>$backup_details</center><br><br>" >> $mail/table.html

                echo  "<center><b>Available backups</b></center><br>" >> $mail/table.html
                echo  "$avlb_bcks <br>" >> $mail/table.html
        fi

echo  "</body></html>" >> $mail/table.html
cat $mail/table.html | $sendmail -i -t

else
echo  "FROM: 'Hyperoffice_Brazil_Backup' <backup@mydbops.com>" > $mail/table.html
echo  "TO: bharath@mydbops.com" >> $mail/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($server) is $status" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL Backup on $server ($host_address) is <b><font color='$color'>$status</font></b><br>" >> $mail/table.html
echo  "Please check the error log $error_log" >> $mail/table.html
echo  "</body></html>" >> $mail/table.html
cat $mail/table.html | $sendmail -i -t

fi


else

#Send an mail alert

echo "backup not done mount point not available"

echo  "FROM: 'Hyperoffice_Brazil_Backup' <backup@mydbops.com>" > $mail/table.html
echo  "TO: bharath@mydbops.com" >> $mail/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($server) is not initiated!" >> $mail/table.html
echo  "Content-type: text/html" >> $mail/table.html
echo  "<html><body>" >> $mail/table.html
echo  "Hi Team,<br><br>" >> $mail/table.html
echo  "MySQL Backup on $server ($host_address) is <b><font color='$color'>not initiated!</font></b><br><br>" >> $mail/table.html
echo  "Reason :  backup mount-point ($mount_point) not found!<br><br>" >> $mail/table.html
echo  "Please check or report to the client and fix it as soon as possible." >> $mail/table.html
echo  "</body></html>" >> $mail/table.html
cat $mail/table.html | $sendmail -i -t

fi

###################################################################################################################

echo "end at `date +'%d-%b-%Y %H:%M:%S'`"

###################################################################################################################

