#!/bin/bash
#!/bin/sh

#Version : 1.0.0
#Author  : mydbops.com
#Purpose : purge binary logs

set -x

#Details

mysql_path="/usr/bin/mysql"
mysql_user="bin_user"
mysql_passwd="bin@user"
loc_user="bin_purge"
loc_paswd="bin@purge"
mast="10.210.1.11 10.210.1.12 10.210.1.14 10.210.1.15 10.210.1.16"
slave_db="10.210.1.13"
log_cnt="50"
sub_path="/home/mydbops/monitor/binlog/sub"
receiver="dba-group@mydbops.com"

sendmail="/usr/sbin/sendmail"
date=`date '+%d-%m-%y %H:%M:%S'`

rm -rf /home/mydbops/monitor/binlog/sub/*

for host_db in $mast

do
echo $host_db
connection_name=`$mysql_path --user=$loc_user --password=$loc_paswd -e "select host_name from hyper_brazil_monitor.servers where host='$host_db';" -s -N`

#collect stats
$mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host_db -e "show binary logs;" -s -N > $sub_path/master_binlog.txt
$mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host_db -e "show master status;" -s -N > $sub_path/master_status.txt
$mysql_path --user=$mysql_user --password=$mysql_passwd --host=$slave_db -e "SHOW SLAVE '$connection_name' STATUS\G" > $sub_path/slave_status.txt


        mast_total=$(cat $sub_path/master_binlog.txt | wc -l)
        mast_first_file=$(head -1 $sub_path/master_binlog.txt | awk '{print $1}')
        slave_last_read=$(cat $sub_path/slave_status.txt | grep -w Master_Log_File | awk '{print $2}')
        sec_behind=$(cat $sub_path/slave_status.txt | grep -w Seconds_Behind_Master | awk '{print $2}')
        slave_io=$(cat $sub_path/slave_status.txt | grep -w Slave_IO_Running | awk '{print $2}')
        mast_status=$(cat $sub_path/master_status.txt | awk '{print $1}')

#Purging for master server
if [[ $mast_total -gt $log_cnt ]]; then
till_cnt=$(( $mast_total - $log_cnt ))
act_cnt=$(( $mast_total - $log_cnt + 1 ))
#Last log file to be purged
log_file=$(cat -n $sub_path/master_binlog.txt | grep -w $act_cnt | awk '{print $2}')

        if [[ $slave_io == Yes  && $sec_behind -le 10  &&  $mast_status == $slave_last_read ]]; then
                $mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host_db -e "purge binary logs to '$log_file';"

                                master_purge=yes
                                $mysql_path --user=$loc_user --password=$loc_paswd -e "update hyper_brazil_monitor.servers set purge_stats="$master_purge" where host='$host_db';"
                                echo "<p>" >> $sub_path/purge_status.txt
                                echo "<b>Details for $connection_name </b><br>" >> $sub_path/purge_status.txt
                                echo "<table>" >> $sub_path/purge_status.txt
                                echo "<tr><td><b><font color='blue'>Status</font></b></td> <td>Binary logs purged! </td></tr>" >> $sub_path/purge_status.txt
                                echo "<tr><td><b><font color='blue'>Command Used</font></b></td> <td>PURGE BINARY LOGS TO '$log_file'</td></tr>" >> $sub_path/purge_status.txt
                                echo "<tr><td><b><font color='blue'>Binarylogs Purged</font></b></td> <td>Binary logs purged from '$mast_first_file' to '$log_file'</td></tr>" >> $sub_path/purge_status.txt
                                echo "<tr><td><b><font color='blue'>Total Logs</font></b></td> <td> $till_cnt</td></tr>" >> $sub_path/purge_status.txt
								echo "<tr><td><b><font color='blue'>Sync Status</font></b></td> <td> $sec_behind seconds behind master!</td></tr>" >> $sub_path/purge_status.txt
								echo "<tr><td><b><font color='blue'>Current Binlog</font></b></td> <td> $slave_last_read </td></tr>" >> $sub_path/purge_status.txt
								echo "<tr><td><b><font color='blue'>Retention Method</font></b></td> <td> Log counts ($log_cnt logs) </td></tr>" >> $sub_path/purge_status.txt
                                echo "</table>" >> $sub_path/purge_status.txt
                                echo "<br>" >> $sub_path/purge_status.txt
                                echo "</p>" >> $sub_path/purge_status.txt

        else
                master_purge=error
                                $mysql_path --user=$loc_user --password=$loc_paswd -e "update hyper_brazil_monitor.servers set purge_stats='$master_purge' where host='$host_db';"
                                echo "Not Purged" > $sub_path/mast_details.txt
                echo "Check for replication status" >> $sub_path/mast_details.txt
        fi

else
                master_purge=no
                                $mysql_path --user=$loc_user --password=$loc_paswd -e "update hyper_brazil_monitor.servers set purge_stats='$master_purge' where host='$host_db';"
                                echo "<p>" >> $sub_path/purge_status.txt
			  	echo "<b>Details for $connection_name </b><br>" >> $sub_path/purge_status.txt
                                echo "<tr><td><b><font color='blue'>Status</font></b></td>  <td>Binary Logs Not Purged!</td></tr>" >> $sub_path/purge_status.txt
				echo "<tr><td><b><font color='blue'> Reason</font></b></td>  <td>No logs to purge</td></tr>" >> $sub_path/purge_status.txt
				echo "<tr><td><b><font color='blue'>Sync Status</font></b></td> <td> $sec_behind seconds behind master!</td></tr>" >> $sub_path/purge_status.txt
				echo "<tr><td><b><font color='blue'>Current Binlog</font></b></td> <td> $slave_last_read </td></tr>" >> $sub_path/purge_status.txt
				echo "<tr><td><b><font color='blue'>Retention Method</font></b></td> <td> Log counts ($log_cnt logs) </td></tr>" >> $sub_path/purge_status.txt
				echo "<tr><td><b><font color='blue'> Logs Available </font></b></td>  <td>$mast_total</td></tr>" >> $sub_path/purge_status.txt
				echo "</table>" >> $sub_path/purge_status.txt
                                echo "<br>" >> $sub_path/purge_status.txt
                                echo "</p>" >> $sub_path/purge_status.txt
fi


done

purge_cnt=`$mysql_path --user=$loc_user --password=$loc_paswd -e "select count(*) from hyper_brazil_monitor.servers where purge_stats='yes';" -s -N`

if [[ $purge_cnt -ge 1 ]]; then
log_purge='yes'
fi

final_stats=$(cat $sub_path/purge_status.txt)

if [[ $log_purge == no ]]; then
echo "no mail"
elif [[ $log_purge == error ]]; then
echo "send error mail"
else

echo  "FROM:'Binlog_purge_hyperoffice_brazil'<binlog_purge_hyperoffice@mydbops.com>" > $sub_path/mail.html
echo  "TO: $receiver" >> $sub_path/mail.html
echo  "SUBJECT: Binary Logs Purged on Hyperoffice_Brazil Servers at $date ">> $sub_path/mail.html
echo  "Content-type: text/html" >> $sub_path/mail.html
echo  "<html><body>" >> $sub_path/mail.html
echo  "Hi Team,<br><br>" >> $sub_path/mail.html
echo "Binary logs were purged on Hyperoffice_Brazil servers!<br>"  >> $sub_path/mail.html
echo "<br>The details are as follows :-<br><br>" >> $sub_path/mail.html
echo "$final_stats<br>" >> $sub_path/mail.html
echo "<br />Regards,<br>MyDBOPS Monitoring<br>(Alerts)</body></html> " >> $sub_path/mail.html
cat $sub_path/mail.html | $sendmail -i -t
fi

