#!/bin/bash


######variable declaration


elast=$(date +'%d-%b-%Y %H:%M:%S')
receiver="dba-group@mydbops.com"
login_path="mysql"
USER="db_metadata"
PASSWORD="xIj2MN77"
sub_path="/home/mydbops/scripts"



###### server details

rm -r $sub_path/*

$login_path -u $USER -p$PASSWORD -e "select host from hyper_brazil_monitor.MONTAB;" -s -N | paste -s> $sub_path/client.txt

cat $sub_path/client.txt | awk '{print $1, $2, $4, $5, $6}' > $sub_path/clien.txt

client_list=$(cat $sub_path/clien.txt)

for client in $client_list

do

echo "<br><b>Client name</b> : $client<br>" >> $sub_path/output.txt
echo "<br>" >> $sub_path/output.txt

ssh $client "mysql --login-path=mydbops -e 'SELECT table_schema, COUNT(table_name) FROM information_schema.tables WHERE (table_catalog, table_schema, table_name) NOT IN (SELECT table_catalog, table_schema, table_name FROM information_schema.table_constraints WHERE constraint_type in (\"PRIMARY KEY\", \"UNIQUE\")) AND table_schema NOT IN (\"information_schema\", \"mysql\", \"performance_schema\", \"test\")'" > $sub_path/co.txt

cat $sub_path/co.txt | awk '{print $2}' | sed -e '1d' > $sub_path/u.txt

ssh $client "mysql --login-path=mydbops -e 'SELECT table_schema, table_name FROM information_schema.tables WHERE (table_catalog, table_schema, table_name) NOT IN (SELECT table_catalog, table_schema, table_name FROM information_schema.table_constraints WHERE constraint_type in (\"PRIMARY KEY\", \"UNIQUE\")) AND table_schema NOT IN (\"information_schema\", \"mysql\", \"performance_schema\", \"test\")'" --html > $sub_path/file.txt
 

echo "<b>Count</b> : $(cat $sub_path/u.txt)<br>" >> $sub_path/output.txt
echo "<br>" >> $sub_path/output.txt

count=$(ls -lrth  $sub_path/file.txt | awk '{print $5}')
if [[ $count == 0 ]]; then
echo "There are no tables found without using primary/unique key <br>" >> $sub_path/output.txt 
else
cat $sub_path/file.txt >> $sub_path/output.txt
fi
echo "<br>" >> $sub_path/output.txt 

done

##part to sendmail

 echo  "FROM: 'Alert_mydbops' <primary-unique@mydbops.com>" > $sub_path/table.html

 echo  "TO: $receiver" >> $sub_path/table.html

 echo  "SUBJECT: Collection of tables without using primary/unique keys" >> $sub_path/table.html

 echo  "Content-type: text/html" >> $sub_path/table.html

 echo  "<html><body>" >> $sub_path/table.html

 echo "Hi Team,<br>" >> $sub_path/table.html

 echo "<br>" >> $sub_path/table.html

 echo "These are the tables and databases without using Primary/Unique keys. Please take and verify this.<br>" >> $sub_path/table.html
 
 cat $sub_path/output.txt  >> $sub_path/table.html

 echo  "</body></html>" >> $sub_path/table.html


 cat $sub_path/table.html | /usr/sbin/sendmail -i -t