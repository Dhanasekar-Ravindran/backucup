#!/bin/bash

export BACKUPDIR=/backup/db2.astoriacompany.com/xtrabackup
export COMPRESSEDDIR=/backup/db2.astoriacompany.com/compressed_daily
export SUBDIR=`date +%Y-%m-%d`
export SUBDIRMINUS1=`date +%Y-%m-%d -d yesterday`
export SUBPATH=/backup/db2.astoriacompany.com/sub
host_ip="23.246.247.162"
receiver="dba@astoriacompany.com"
bdate=`date +%d-%m-%Y`
date

rm -rf /backup/db2.astoriacompany.com/sub/*

###tar the previous days backup
cd $BACKUPDIR
time tar zcvf /backup/db2.astoriacompany.com/compressed_daily/xtrabackup.$SUBDIRMINUS1.tgz $SUBDIRMINUS1*

###rm the previous backup dir
OUT=$?
if [ $OUT -eq 0 ];then
   echo "Backup OK!"
   du -sh /backup/db2.astoriacompany.com/xtrabackup/$SUBDIRMINUS1* > $SUBPATH/arch_file_size.txt
   arch_file=$(cat $SUBPATH/arch_file_size.txt | awk '{print $2}')
   arch_size=$(cat $SUBPATH/arch_file_size.txt | awk '{print $1}')
   rm -rf /backup/db2.astoriacompany.com/xtrabackup/$SUBDIRMINUS1*
   
else
   echo "Backup not OK!"
fi

###do the backup
innobackupex -slave-info -parallel 2 /backup/db2.astoriacompany.com/xtrabackup 1>$SUBPATH/xtra_back.log 2>$SUBPATH/xtra_back.err

#Get the status
back_status=$(cat $SUBPATH/xtra_back.err | tail -n1 | cut -c32-40)
#Get the backup size
du -sh /backup/db2.astoriacompany.com/xtrabackup/20* > $SUBPATH/file_size.txt
backupsize=$(cat $SUBPATH/file_size.txt | awk '{print $1}')
#Get the backup file
backup_file=$(cat $SUBPATH/file_size.txt | awk '{print $2}')

#To get binlog details
cat /backup/db2.astoriacompany.com/xtrabackup/20*/xtrabackup_slave_info > $SUBPATH/binlog.txt
 
log_file=$(cat $SUBPATH/binlog.txt | cut -c35-50)
log_pos=$(cat $SUBPATH/binlog.txt | cut -c69-90)
 
###prepare the backup
innobackupex  --apply-log /backup/db2.astoriacompany.com/xtrabackup/$SUBDIR*

###chown it so it can be restored to mysql user
chown -R mysql:mysql /backup/db2.astoriacompany.com/xtrabackup/$SUBDIR*

##backup the my.cnf
cp /etc/my.cnf /backup/db2.astoriacompany.com/xtrabackup/$SUBDIR*
##backup the binary logs
cp /backup/db2.astoriacompany.com/mysqlbinlog/* /backup/db2.astoriacompany.com/xtrabackup/$SUBDIR*
##remove older binary logs
find /backup/db2.astoriacompany.com/mysqlbinlog/ -mtime +3 -exec rm {} \;

date

#Enter all details to text file
if [[ "$back_status" == completed ]];
then
status="Success"
color="green"
echo  "FROM: 'Astoria_Backup' <backup@mydbops.com>" > $SUBPATH/table.html
echo  "TO: $receiver" >> $SUBPATH/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate (db2.astoriacompany.com) is $status" >> $SUBPATH/table.html
echo  "Content-type: text/html" >> $SUBPATH/table.html
echo  "<html><body>" >> $SUBPATH/table.html
echo  "Hi Team,<br><br>" >> $SUBPATH/table.html
echo  "MySQL Hot Backup on db2.astoriacompany.com ($host_ip) is <b><font color='green'> Success!</font></b><br>" >> $SUBPATH/table.html
echo  "<br><center><b>Binary log details</b></center><br>" >> $SUBPATH/table.html
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Binlog File</th><th><font color='blue'>Binlog Position</th></tr><tr><td>$log_file</td><td>$log_pos</td></tr></table><br>" >> $SUBPATH/table.html

echo  "Backup Type : <b>Full Backup</b><br>" >> $SUBPATH/table.html
echo  "<br><center><b>Full Backup size for today</b></center><br>" >> $SUBPATH/table.html
echo  "<table border='1' width='550px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $SUBPATH/table.html

echo  "<br><center><b>Archived Full Backup From db2.astoriacompany.com</b></center><br>" >> $SUBPATH/table.html
echo  "<table border='1' width='550px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $SUBPATH/table.html


else
status="Failure"
color="red"
echo  "FROM: 'Astoria_Backup' <backup@mydbops.com>" > $SUBPATH/table.html
echo  "TO: $receiver" >> $SUBPATH/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate (db2.astoriacompany.com) is Failure" >> $SUBPATH/table.html
echo  "Content-type: text/html" >> $SUBPATH/table.html
echo  "<html><body>" >> $SUBPATH/table.html
echo  "Hi Team,<br><br>" >> $SUBPATH/table.html
echo  "MySQL Hot Backup on db2.astoriacompany.com is <b><font color='red'> Failure!</font></b><br>" >> $SUBPATH/table.html
echo  "Please check the error log!" >> $SUBPATH/table.html
echo  "</body></html>" >> $SUBPATH/table.html
cat $SUBPATH/table.html | ssh root@10.90.75.209 "/usr/sbin/sendmail -i -t"
fi

