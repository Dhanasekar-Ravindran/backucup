#!/bin/bash
#!/bin/sh

#Version : 1.1.0
#Author  : mydbops.com
#Purpose : purge binary logs

set -x

source "/etc/astoria_binlog.conf"

date=`date '+%d-%m-%y %H:%M:%S'`

rm -r $sub_path/*

#Collect the status
$mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host1 -e "show binary logs;" -s -N > $sub_path/master_binlog.txt
$mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host2 -e "show binary logs;" -s -N > $sub_path/slave_binlog.txt
$mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host1 -e "show master status;" -s -N > $sub_path/master_status.txt
$mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host2 -e "show slave status\G" > $sub_path/slave_status.txt

        mast_total=$(cat $sub_path/master_binlog.txt | wc -l)
        mast_first_file=$(head -1 $sub_path/master_binlog.txt | awk '{print $1}')
        slave_total=$(cat $sub_path/slave_binlog.txt | wc -l)
        slave_first_file=$(head -1 $sub_path/slave_binlog.txt | awk '{print $1}')
        slave_last_read=$(cat $sub_path/slave_status.txt | grep -w Master_Log_File | awk '{print $2}')
        sec_behind=$(cat $sub_path/slave_status.txt | grep -w Seconds_Behind_Master | awk '{print $2}')
        slave_io=$(cat $sub_path/slave_status.txt | grep -w Slave_IO_Running | awk '{print $2}')
        mast_status=$(cat $sub_path/master_status.txt | awk '{print $1}')


#Purging for master server
if [[ $mast_total -gt $log_cnt ]]; then
till_cnt=$(( $mast_total - $log_cnt ))
act_cnt=$(( $mast_total - $log_cnt + 1 ))
#Last log file to be purged
log_file=$(cat -n $sub_path/master_binlog.txt | grep -w $act_cnt | awk '{print $2}')

        if [[ $slave_io == Yes  && $sec_behind -le 10  &&  $mast_status == $slave_last_read ]]; then
              $mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host1 -e "purge binary logs to '$log_file';"
                master_purge=yes
                master_stats=$(echo "Binary logs purged")
                master_cmd=$(echo "PURGE BINARY LOGS TO '$log_file'")
                master_files=$(echo "Binary logs purged from '$mast_first_file' to '$log_file'")
                master_tot=$(echo "$till_cnt" )

        else
                master_purge=no
                master_stats=$(echo "Not Purged")
                master_cmd=$(echo "-")
                master_files=$(echo "-")
                master_tot=$(echo "-")
                echo "Check for replication status" > $sub_path/mast_details.txt
        fi

else
                master_purge=no
                master_stats=$(echo "Not Purged")
                master_cmd=$(echo "-")
                master_files=$(echo "-")
                master_tot=$(echo "-")
                echo "no logs to purge"
fi


#Purging for slave server
if [[ $slave_total -gt $log_cnt ]]; then
till_cnt1=$(( $slave_total - $log_cnt ))
act_cnt1=$(( $slave_total - $log_cnt + 1 ))
#Last log file to be purged
slave_log_file=$(cat -n $sub_path/slave_binlog.txt | grep -w $act_cnt1 | awk '{print $2}')
        $mysql_path --user=$mysql_user --password=$mysql_passwd --host=$host2 -e "purge binary logs to '$slave_log_file';"
                slave_purge="yes"
                slave_stats=$(echo "Binary logs purged")
                slave_cmd=$(echo "PURGE BINARY LOGS TO '$slave_log_file'")
                slave_files=$(echo "Binary logs purged from '$slave_first_file' to '$slave_log_file'")
                slave_tot=$(echo "$till_cnt1")
else
                slave_purge=no
                slave_stats=$(echo "Not Purged")
                slave_cmd=$(echo "-")
                slave_files=$(echo "-")
                slave_tot=$(echo "-")
                echo "no logs to purge"
fi


if [[ $slave_purge == no && $master_purge == no ]]; then

echo "no mail"
echo  "FROM:'Binlog_purge_Astoria'<Binlog_purge_Astoria@mydbops.com>" > $sub_path/mail.html
echo  "TO: $receiver" >> $sub_path/mail.html
echo  "SUBJECT: Binary Logs Purged on Astoria servers at $date ">> $sub_path/mail.html
echo  "Content-type: text/html" >> $sub_path/mail.html
echo  "<html><body>" >> $sub_path/mail.html
echo  "Hi Team,<br><br>" >> $sub_path/mail.html
echo  "There are no binary logs to purge!<br><br>" >> $sub_path/mail.html
echo "<br />Regards,<br>Mydbops Monitoring<br>(Alerts)</body></html> " >> $sub_path/mail.html
cat $sub_path/mail.html | $sendmail -i -t

else

echo  "FROM:'Binlog_purge_Astoria'<Binlog_purge_Astoria@mydbops.com>" > $sub_path/mail.html
echo  "TO: $receiver" >> $sub_path/mail.html
echo  "SUBJECT: Binary Logs Purged on Astoria servers at $date ">> $sub_path/mail.html
echo  "Content-type: text/html" >> $sub_path/mail.html
echo  "<html><body>" >> $sub_path/mail.html
echo  "Hi Team,<br><br>" >> $sub_path/mail.html

if [[ $slave_purge == yes && $master_purge == yes ]];
then
echo "Binary logs were purged on master($host1) and slave($host2) servers respectively!<br>"  >> $sub_path/mail.html
echo "<br>The details are as follows :-<br><br>" >> $sub_path/mail.html
echo "<table border='1' width='650px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Subject</th><th><font color='blue'>Master Server</th><th><font color='blue'>Slave server</th></tr><tr><td><font color='green'><b>Status</b></font></td><td>$master_stats</td><td>$slave_stats</td></tr><tr><td><font color='green'><b>Command Used</b></font></td><td>$master_cmd</td><td>$slave_cmd</td></tr><tr><td><font color='green'><b>Files Purged</b></font></td><td>$master_files</td><td>$slave_files</td></tr><tr><td><font color='green'><b>Total Files</b></font></td><td>$master_tot</td><td>$slave_tot</td></tr></table><br>" >> $sub_path/mail.html

elif [[ $slave_purge == yes && $master_purge == no ]];
then
echo "<br>Binary logs was purged only on slave($host2) server!<br>"  >> $sub_path/mail.html
echo "<br>The details are as follows :-<br><br>" >> $sub_path/mail.html
echo "<table border='1' width='650px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Subject</th><th><font color='blue'>Slave server</th></tr><tr><td><font color='green'><b>Status</b></font></td><td>$slave_stats</td></tr><tr><td><font color='green'><b>Command Used</b></font></td><td>$slave_cmd</td></tr><tr><td><font color='green'><b>Files Purged</b></font></td><td>$slave_files</td></tr><tr><td><font color='green'><b>Total Files</b></font></td><td>$slave_tot</td></tr></table><br>" >> $sub_path/mail.html

else
echo "<br>Binary logs was purged only on master($host1) server!<br>"  >> $sub_path/mail.html
echo "<br>The details are as follows :-<br><br>" >> $sub_path/mail.html
echo "<table border='1' width='650px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Subject</th><th><font color='blue'>Master Server</th></tr><tr><td><font color='green'><b>Status</b></font></td><td>$master_stats</td></tr><tr><td><font color='green'><b>Command Used</b></font></td><td>$master_cmd</td></tr><tr><td><font color='green'><b>Files Purged</b></font></td><td>$master_files</td></tr><tr><td><font color='green'><b>Total Files</b></font></td><td>$master_tot</td></tr></table><br>" >> $sub_path/mail.html
fi
echo "<br />Regards,<br>Mydbops Monitoring<br>(Alerts)</body></html> " >> $sub_path/mail.html

cat $sub_path/mail.html | $sendmail -i -t
fi

