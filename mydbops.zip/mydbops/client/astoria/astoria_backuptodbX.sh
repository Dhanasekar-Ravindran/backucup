set -x

export LOCALRETENTION=7
export REMOTERETENTION=14
export SUBPATH=/backup/db2.astoriacompany.com/sub
host_ip="23.246.247.162"

if [[ `hostname` == db1.astoriacompany.com ]]; then
SV_HOST="10.90.75.226"
SV_HOSTNAME="db2"
else
SV_HOST="10.90.75.209"
SV_HOSTNAME="db1"
fi

cd /backup/`hostname`/compressed_daily

#Find the latest backup file that to be copied to $SV_HOSTNAME.astoriacompany.com
LATEST=$(ls -t | grep xtra | head -1)

#Copying  backups from `hostname` to $SV_HOSTNAME.astoriacompany.com
/usr/bin/rsync -avz --progress /backup/`hostname`/compressed_daily/$LATEST root@$SV_HOST:/backup/$SV_HOSTNAME.astoriacompany.com/compressed_daily/

#Purging files older than $LOCALRETENTION days
purge_date=`date +'%Y-%m-%d' -d '8 days ago'`
ls /backup/`hostname`/compressed_daily/* | grep $purge_date > /tmp/purge.txt

#Files to purge in local server
#Find if files are there to purge
PURGE_AVLB=$(cat /tmp/purge.txt | wc -l)

if [[ $PURGE_AVLB -ge 1 ]]; then
arch_file=$(cat /tmp/purge.txt | grep xtra)
arch_size=$(du -sh $arch_file | awk '{print $1}')
PURGE_FILE=$(cat /tmp/purge.txt | grep xtra | awk '{print}' ORS=' ')
for RET_FILE in $PURGE_FILE
do
echo "Deleting $RET_FILE as its older than $LOCALRETENTION days" > $SUBPATH/deleted_file.txt
rm -rf $RET_FILE
done
else
echo "No files to be purged"
fi

#Get available local compressed backups 
du -sh /backup/db2.astoriacompany.com/compressed_daily/* | sort -k2 -r | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' > $SUBPATH/avb_back.txt
avlb_backups=$(cat $SUBPATH/avb_back.txt)

#Files to purge in remote server
#Purging files older than $REMOTERETENTION days
rem_purge_date=`date +'%Y-%m-%d' -d '15 days ago'`
ssh root@10.90.75.209 "ls /backup/db1.astoriacompany.com/compressed_daily/* | grep $rem_purge_date" > /tmp/purge_rem.txt

#Find if files are there to purge
PURG_AVLB=$(cat /tmp/purge_rem.txt | wc -l)

if [[ $PURG_AVLB -ge 1 ]]; then
rem_arch_file=$(cat /tmp/purge_rem.txt | grep xtra)
#oldrem_arch_size=$(du -sh $rem_arch_file | awk '{print $1}')
ssh root@$SV_HOST "du -sh $rem_arch_file" > $SUBPATH/rem_purge_size.txt
rem_arch_size=$(cat $SUBPATH/rem_purge_size.txt | awk '{print $1}')
PURG_FILE=$(cat /tmp/purge_rem.txt | grep xtra | awk '{print}' ORS=' ')
for RETN_FILE in $PURG_FILE
do
echo "Deleting $RETN_FILE as its older than $LOCALRETENTION days" >> $SUBPATH/deleted_file.txt
ssh root@$SV_HOST "rm -rf $RETN_FILE"
done
else
echo "No files to be purged"
fi


#Get available remote compressed backups 
ssh root@10.90.75.209 "du -sh /backup/db1.astoriacompany.com/compressed_daily/*" | sort -k2 -r | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' > $SUBPATH/rem_back_order.txt

rem_avlb_backups=$(cat $SUBPATH/rem_back_order.txt)


echo  "<br><center><b>Archived Compressed Backups From db2.astoriacompany.com</b></center><br>" >> $SUBPATH/table.html
echo  "<br><center><b>Backup Retention : 7 days </b></center><br>" >> $SUBPATH/table.html
echo  "<table border='1' width='550px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $SUBPATH/table.html

echo  "<center><b>Available Compressed Backups From db2.astoriacompany.com</b></center><br>" >> $SUBPATH/table.html
echo  "<center><table border='1' width='550px'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$avlb_backups</table></center>" >> $SUBPATH/table.html

echo  "<br><center><b>Archived Compressed Backups From db1.astoriacompany.com</b></center><br>" >> $SUBPATH/table.html
echo  "<br><center><b>Backup Retention : 14 days </b></center><br>" >> $SUBPATH/table.html
echo  "<table border='1' width='550px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$rem_arch_file</td><td>$rem_arch_size</td></tr></table><br>" >> $SUBPATH/table.html

echo  "<center><b>Available Compressed Backups From db1.astoriacompany.com</b></center><br>" >> $SUBPATH/table.html
echo  "<center><table border='1' width='550px'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$rem_avlb_backups</table></center>" >> $SUBPATH/table.html

echo  "</body></html>" >> $SUBPATH/table.html
cat $SUBPATH/table.html | ssh root@10.90.75.209 "/usr/sbin/sendmail -i -t"

