import getopt, sys, config, mysql.connector, commands
o=sys.argv[0:]
def verbose(message):
    print "%s" % message
cnx = mysql.connector.connect(user=config.slave_user, host=config.slave_host ,password=config.slave_password ,port=config.slave_port, database='') #Slave credentials
cursor = cnx.cursor()
try:
    #!bin/python
    print
    print "Dependencies check"
    print "##################"
    print
    try:
        import mysql.connector
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import getopt
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import subprocess
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import getopt
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import commands
    except Importerror:
        print('\nThere is no such module installed')
    print
    print "All modules are installed"
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hvd", ["help"])
    except getopt.GetoptError as err:
        print
        print str(err) # will print something like "option -a not recognized"
        print "Try '-h' for more information"
        print
        sys.exit()
    if len(sys.argv) > 1:
        for o, a in opts:
            if o=='-v':
                try:
                    print
                    print "#################################### REPLICATION HEALTH ########################################"
                    print
                    print "####################################### VERBOSE MODE ###########################################"
                    print
                    cursor.execute("SHOW SLAVE STATUS")
                    result_set=cursor.fetchall()
                    status = [(row[1],row[2],row[3],row[10], row[11],row[32], row[44]) for row in result_set]
                    print('\033[4m''\033[31m' + 'Simple output\033[1;37;40m\033[0m')
                    verbose("Master Host\t\t:%s\nMaster User\t\t:%s\nMaster Port\t\t:%s" %(row[1], row[2],row[3]))
                    verbose("Slave IO Running\t:%s\nSlave SQL Running\t:%s\nSeconds Behind Master\t:%s\nState\t\t\t:%s" %(row[10], row[11],row[32], row[44]))
                    print
                    print
                    cursor.execute("SHOW SLAVE STATUS")
                    result_set=cursor.fetchall()
                    status = [(row[5],row[1],row[2],row[3],row[6],row[7],row[8],row[9],row[20],row[21],row[12],row[13],row[35],row[37]) for row in result_set]
                    print('\033[4m''\033[31m' + 'Log File Details\033[1;37;40m\033[0m') #Log_files in slave
                    verbose("Master Host\t\t:%s\nMaster User\t\t:%s\nMaster Port\t\t:%s" %(row[1], row[2],row[3]))
                    verbose("Master Log File\t\t:%s\nRead Master Log Pos\t:%s\nRelay Log File\t\t:%s\nRelay Log Pos\t\t:%s\nRelay Master Log File\t:%s\nExec Master Log Pos\t:%s" %(row[5], row[6],row[7], row[8], row[9], row[21]))
                    a=int(row[6])
                    b=int(row[21])
                    c=b-a
                    verbose("Relay log Difference is :%s" %c)
                    print
                    print('\033[4m''\033[31m' + 'Database Details\033[1;37;40m\033[0m') #Replicate DB Details
                    verbose("Replicate Ignore DB\t:%s\nReplicate Do DB\t\t:%s" %(row[12],row[13]))
                    verbose("Binlog Ignore DB\t:%s\nBinlog Do DB\t\t:%s" %(commands.getoutput("cat /usr/local/mysql/my.cnf | grep binlog_ignore_db | awk '{print $3}'"),commands.getoutput("cat /usr/local/mysql/my.cnf | grep binlog_do_db | awk '{print $3}'")))
                    print
                    print('\033[4m''\033[31m' + 'Errors\033[1;37;40m\033[0m') #Replication Errors
                    verbose("Last IO Error\t\t:%s\nLast SQL Error\t\t:%s" %(row[35],row[37]))
                    print
                    print('\033[4m''\033[31m' + 'Slave skip\033[1;37;40m\033[0m') #Replication Skip Counter
                    #print("\033[1;37;40m\033[0m")
                    verbose("Slave skip error\t:%s" %(row[20]))
                    print
                    cursor.execute("SHOW GLOBAL VARIABLES LIKE 'slave_skip_errors';")
                    result_set=cursor.fetchall()
                    status=[(column[1]) for column in result_set]
                    print('\033[4m''\033[31m' + 'Parallel_threads\033[1;37;40m\033[0m')
                    #print("\033[1;37;40m\033[0m")
                    verbose("Parallel threads\t:%s" %(column[1]))
                    print
                    cursor.execute("SHOW GLOBAL VARIABLES LIKE 'gtid_mode';")
                    result_set=cursor.fetchall()
                    status=[(column[1]) for column in result_set]
                    print('\033[4m''\033[31m' + 'GTID Check\033[1;37;40m\033[0m')
                    #print("\033[1;37;40m\033[0m")
                    verbose("Mode\t\t\t:%s" %(column[1]))
                    print
                    cursor.execute("SHOW GLOBAL VARIABLES LIKE 'binlog_checksum';")
                    result_set=cursor.fetchall()
                    status=[column [1] for column in result_set]
                    print('\033[4m''\033[31m' + 'Binlog Details\033[1;37;40m\033[0m')
                    verbose("Bin Log Checksum\t:%s" %(column[1]))
                    print
                    cursor.execute("SHOW GLOBAL VARIABLES LIKE 'binlog_format';")
                    result_set=cursor.fetchall()
                    status=[column[1] for column in result_set]
                    print('\033[4m''\033[31m' + 'Binlog format\033[1;37;40m\033[0m')
                    verbose("Binlog Format\t\t:%s" %(column[1]))
                    print

                except IndexError:
                    pass
                except TypeError:
                    passconnector
                finally:
                    if cursor:
                        cursor.close()
                        sys.exit(2)
            elif o=='-h':
                print
                print "#################################### REPLICATION HEALTH ########################################"
                print
                print('\033[94m''\033[1m' + 'Replication Health Status :')
                print '\033[0m'
                print "usage: python [file.py] ... [arg] ..."
                print "Arguments are :"
                #print "-s [Simple Mode]"
                print "-v [Verbose Mode] \n-d [Replication Topology] \n-h [help]"
                sys.exit()
                print
            elif o=='-d':
                try:
                    print
                    print "#################################### REPLICATION HEALTH ########################################"
                    print
                    print "#################################### REPLICATION TOPOLOGY ######################################"
                    print
                    print('\033[31m''\033[1m' + 'Replication Topology\033[1;37;40m\033[0m')
                    print '\033[0m'
                    master = mysql.connector.connect(user=config.master_user, host=config.master_host ,password=config.master_password ,port=config.master_port, database='') #Master credentials
                    master_cursor = master.cursor(mysql.connector.cursor)
                    master_cursor.execute("SELECT @@port")
                    status=master_cursor.fetchall()
                    result_set=[row[0] for row in status]
                    mp=row[0]
                    master_cursor.execute("select @@hostname")
                    result_set=master_cursor.fetchall()
                    status=[(row[0]) for row in result_set]
                    mh=row[0]
                    verbose("Master Port-%d--%s" %(mp,mh))
                    cursor.execute("SELECT @@port")
                    status=cursor.fetchall()
                    result_set=[row[0] for row in status]
                    sp1=row[0]
                    cursor.execute("select @@hostname")
                    status=cursor.fetchall()
                    result_set=[(row[0]) for row in status]
                    #print ("\033[1m \t|--Slave--\033[0m") ,(sp1,sh1)
                    verbose("\t|--Slave--%s--%s" %(sp1,row[0]))
                    master_cursor.execute("SHOW SLAVE HOSTS")
                    status=master_cursor.fetchall()
                    result_set=[(column[1],column [2]) for column in status]
                    verbose("\t|--Slave--%s--%s" %(column[2],column[1]))
                    print
                except IndexError:
                    pass
                finally:
                    if cursor:
                        cursor.close()
                        sys.exit()
            else:
                print
                sys.exit(2)
    else:
        try:
            print
            print "#################################### REPLICATION HEALTH ########################################"
            print
            cursor.execute("SHOW SLAVE STATUS")
            result_set=cursor.fetchall()
            status = [(row[1],row[2],row[3],row[10], row[11],row[32], row[44]) for row in result_set]
        finally:
            if cursor:
                cursor.close()
                verbose("Master Host\t\t:%s\nMaster User\t\t:%s\nMaster Port\t\t:%s" %(row[1], row[2],row[3]))
                verbose("Slave IO Running\t:%s\nSlave SQL Running\t:%s\nSeconds Behind Master\t:%s\nState\t\t\t:%s" %(row[10], row[11],row[32], row[44]))
                print
except getopt.GetoptError as err:
    print "There is now such modeules"
    # ...