#!bin/python
master_user='repl_check'
master_host='10.6.1.11'
master_port='3306'
master_password='Repl_check@123'
slave_user='repl_check'
slave_host='10.6.1.12'
slave_port='3306'
slave_password='Repl_check@123'


