#!/bin/python
import os, getopt, sys, config, mysql.connector, commands
def verbose(message):
    print "%s" % message
cnx = mysql.connector.connect(user=config.master_user, host=config.master_host ,password=config.master_password ,port=config.master_port) 
cursor = cnx.cursor()
try:
    try:
        import mysql.connector
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import getopt
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import subprocess
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import getopt
    except ImportError:
        print('\nThere is no such module installed')
    try:
        import commands
    except ImportError:
        print('\nThere is no such module installed')
    try:
	cursor.execute("show global variables like 'innodb_version'")
	result_set=cursor.fetchall()
	status = [row[1] for row in result_set]
	print
	print '# InnoDB ####################################################################'
	verbose("Innodb Version\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_buffer_pool_size'")
	result_set=cursor.fetchall()
	status = [row[1] for row in result_set]
	a=1024
	b=int(row[1])
	c=float(b/a/a/a)
	verbose("Buffer Pool Size\t:\t%s GB" %c)
	cursor.execute("SELECT CONCAT(FORMAT(DataPages*100.0/TotalPages,2),' %') BufferPoolDataPercentage FROM (SELECT variable_value DataPages FROM information_schema.global_status WHERE variable_name = 'Innodb_buffer_pool_pages_data') A, (SELECT variable_value TotalPages FROM information_schema.global_status WHERE variable_name = 'Innodb_buffer_pool_pages_total') B; ")
	result_set=cursor.fetchall()
        status = [column[0] for column in result_set]
	verbose("Buffer Pool Fill\t:\t%s" %(column[0]))
	cursor.execute("SELECT CONCAT(FORMAT(DirtyPages*100.0/TotalPages,2),' %') BufferPoolDirtyPercentage FROM (SELECT variable_value DirtyPages FROM information_schema.global_status WHERE variable_name = 'Innodb_buffer_pool_pages_dirty') A, (SELECT variable_value TotalPages FROM information_schema.global_status WHERE variable_name = 'Innodb_buffer_pool_pages_total') B;")
	result_set=cursor.fetchall()
        status = [column[0] for column in result_set]
        verbose("Buffer Pool Dirty\t:\t%s" %(column[0]))
	cursor.execute("show global variables like 'innodb_log_buffer_size'")
	result_set=cursor.fetchall()
	status = [row[1] for row in result_set]
	a=1024
        b=int(row[1])
        c=float(b/a/a)
	verbose("Log Buffer Pool Size\t:\t%s MB" %c)
	cursor.execute("show global status like 'Innodb_buffer_pool_load_status'")
	result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
	verbose("Log Buffer Status\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_file_per_table'")
	result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Files Per Table\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_page_size'")
	result_set=cursor.fetchall()
	status = [row[1] for row in result_set]
	a=1024
        b=int(row[1])
        c=float(b/a)
        verbose("Page Size\t\t:\t%sk" %c)
	cursor.execute("show global variables like 'innodb_log_file_size'")
	result_set=cursor.fetchall()
	status = [row[1] for row in result_set]
	a=1024
        b=int(row[1])
        c=float(b/a/a)
	d=float(2*c)
        verbose("Log File Size\t\t:\t2*%s MB = %s MB" %(c,d))
    	cursor.execute("show global variables like 'innodb_flush_method'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Flush Method\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_flush_log_at_trx_commit'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Flush Log At Commit\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_support_xa'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("XA Support\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_checksums'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Checksums\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_doublewrite'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Doublewrite\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_read_io_threads'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
	cursor.execute("show global variables like 'innodb_write_io_threads'")
        result_set=cursor.fetchall()
	w=(row[1])
        verbose("R/W I/O Threads\t\t:\t%s %s" %(row[1],w))
	cursor.execute("show global variables like 'innodb_io_capacity'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("I/O Capacity\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_io_capacity_max'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("I/O Capacity Max\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_thread_concurrency'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Thread Concurrency\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_concurrency_tickets'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Concurrency Tickets\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_commit_concurrency'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Commit Concurrency\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'tx_isolation'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Isolation Level\t\t:\t%s" %(row[1]))
	cursor.execute("show global variables like 'innodb_adaptive_flushing'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("Adaptive Flushing\t:\t%s" %(row[1]))
	cursor.execute("show global status like 'Innodb_history_list_length'")
	result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("History List Length\t:\t%s" %(row[1]))
	print
	print 'Deadlock Info:'
	cursor.execute("show global status like 'Innodb_deadlocks'")
 	result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        verbose("No. of Deadlocks happen\t:\t%s" %(row[1]))
	user=config.master_user
	pwd=config.master_password
	host=config.master_host
	commands.getoutput("mysql -u %s -p%s -h %s -e 'show engine innodb status\G' > status.txt" %(user,pwd,host))
	commands.getoutput("mysql -u %s -p%s -h %s -e 'show engine innodb status\G' | awk /DEADLOCK/,/TRANSACTIONS/ > out.txt" %(user,pwd,host))
	verbose("Last deadlock Time\t:\t%s" %(commands.getoutput("cat out.txt | head -n3  | tail -n1 | awk '{print $1,$2}'")))
	verbose("Transaction Info\t:\n")
	verbose("Trx 1:")
	verbose("Trx id\t\t\t:\t%s" %(commands.getoutput("cat out.txt | grep ' bits ' | head -n1 | awk '{print $19}'")))
	verbose("Time taken\t\t:\t%s" %(commands.getoutput("cat out.txt  | grep 'TRANSACTION ' | head -n1 | awk '{print $4,$5,$6,$7,$8}'")))
	verbose("Locked index\t\t:\t%s" %(commands.getoutput("cat out.txt  | grep ' bits '  | head -n1 | awk '{print $13}'")))
	verbose("Locked Table\t\t:\t%s" %(commands.getoutput("cat out.txt  | grep ' bits '  | head -n1 | awk '{print $16}'")))
	print
	verbose("Trx 2:")
        verbose("Trx id\t\t\t:\t%s" %(commands.getoutput("cat out.txt | grep ' bits ' | head -n2 | tail -n1 | awk '{print $19}'")))
        verbose("Time taken\t\t:\t%s" %(commands.getoutput("cat out.txt  | grep 'TRANSACTION ' | head -n2 | tail -n1 | awk '{print $4,$5,$6,$7,$8}'")))
        verbose("Locked index\t\t:\t%s" %(commands.getoutput("cat out.txt  | grep ' bits '  | head -n3 | tail -n1 | awk '{print $13}'")))
        verbose("Locked Table\t\t:\t%s" %(commands.getoutput("cat out.txt  | grep ' bits '  | head -n3 | tail -n1 | awk '{print $16}'")))
	verbose("Roll back Transaction\t:\t%s" %(commands.getoutput("cat out.txt | tail -n3 | head -n1 | awk '{print $5,$6,$7}'")))
	cursor.execute("show global status like 'Innodb_pages_created'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
	pc1=int(row[1])
	cursor.execute("show global status like 'Innodb_pages_read'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        pr1=int(row[1])
	cursor.execute("show global status like 'Innodb_pages_written'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        pwn1=int(row[1])
	cursor.execute("show global status like 'Innodb_buffer_pool_read_requests'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        rr1=int(row[1])
	cursor.execute("show global status like 'Innodb_buffer_pool_write_requests'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        wr1=int(row[1])
	cursor.execute("show global status like 'Innodb_data_reads'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        dr1=int(row[1])
	cursor.execute("show global status like 'Innodb_data_writes'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        dw1=int(row[1])
	cursor.execute("show global status like 'Innodb_data_fsyncs'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        df1=int(row[1])
	cursor.execute("show global status like 'Innodb_log_writes'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        lw1=int(row[1])
	cursor.execute("show global status like 'Innodb_data_written'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        dwn1=int(row[1])
	cursor.execute("show global status like 'Innodb_rows_deleted'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        rd1=int(row[1])
	cursor.execute("show global status like 'Innodb_rows_inserted'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        ri1=int(row[1])
	cursor.execute("show global status like 'Innodb_rows_read'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        rowread1=int(row[1])
	cursor.execute("show global status like 'Innodb_rows_updated'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
  	ru1=int(row[1])
	cursor.execute("select sleep(5)")
	result_set=cursor.fetchall()
	cursor.execute("show global status like 'Innodb_pages_created'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        pc2=int(row[1])
        cursor.execute("show global status like 'Innodb_pages_read'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        pr2=int(row[1])
        cursor.execute("show global status like 'Innodb_pages_written'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        pwn2=int(row[1])
        cursor.execute("show global status like 'Innodb_buffer_pool_read_requests'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        rr2=int(row[1])
        cursor.execute("show global status like 'Innodb_buffer_pool_write_requests'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        wr2=int(row[1])
        cursor.execute("show global status like 'Innodb_data_reads'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        dr2=int(row[1])
        cursor.execute("show global status like 'Innodb_data_writes'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        dw2=int(row[1])
        cursor.execute("show global status like 'Innodb_data_fsyncs'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        df2=int(row[1])
        cursor.execute("show global status like 'Innodb_log_writes'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        lw2=int(row[1])
        cursor.execute("show global status like 'Innodb_data_written'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        dwn2=int(row[1])
        cursor.execute("show global status like 'Innodb_rows_deleted'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        rd2=int(row[1])
        cursor.execute("show global status like 'Innodb_rows_inserted'")
        result_set=cursor.fetchall()
	status = [row[1] for row in result_set]
        ri2=int(row[1])
        cursor.execute("show global status like 'Innodb_rows_read'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        rowread2=int(row[1])
        cursor.execute("show global status like 'Innodb_rows_updated'")
        result_set=cursor.fetchall()
        status = [row[1] for row in result_set]
        ru2=int(row[1])
	print
	print 'All Records Taken for 5 seconds interval'
	print
	print 'Buffer Pool I/O :'
	print
	pc=pc2-pc1
	pr=pr2-pr1
	pwn=pwn2-pwn1
	verbose("Pages Created \t\t:\t%s" %(pc))
	verbose("Pages Read \t\t:\t%s" %(pr))
	verbose("Pages Written \t\t:\t%s" %(pwn))
	print
	print 'Buffer Pool Requests :'
	print
	rr=rr2-rr1
	wr=wr2-wr1
	verbose("Read Requests \t\t:\t%s" %(rr))
	verbose("Write Requests \t\t:\t%s" %(wr))
	print
	print 'Innodb I/O : '
	print
	dr=dr2-dr1
	dw=dw2-dw1
	df=df2-df1
	lw=lw2-lw1
	dwn=dwn2-dwn1
	verbose("Data Reads \t\t:\t%s" %(dr))
	verbose("Data Writes \t\t:\t%s" %(dw))
	verbose("Data Fsyncs \t\t:\t%s" %(df))
	verbose("Log Writes \t\t:\t%s" %(lw))
	verbose("Data Written \t\t:\t%s" %(dwn))
	print
	print 'Innodb Row Operations :'
	print
	rd=rd2-rd1
	ri=ri2-ri1
	rowread=rowread2-rowread1
	ru=ru2-ru1
	verbose("Row Deleted \t\t:\t%s" %(rd))
        verbose("Row Inserted \t\t:\t%s" %(ri))
        verbose("Row Read \t\t:\t%s" %(rowread))
        verbose("Row Updated \t\t:\t%s" %(ru))



    except ImportError: 
	pass
	if cursor:
            cursor.close()
            sys.exit(2)


except getopt.GetoptError as err:
    print "There is now such modules"
    # ...

