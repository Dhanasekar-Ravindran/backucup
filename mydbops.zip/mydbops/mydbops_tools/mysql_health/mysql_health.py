import getopt, sys
import config
import mysql.connector
import os
import subprocess
options=sys.argv[0:]
def verbose(message):
    print "%s" % message
cnx=mysql.connector.connect(user=config.user,host=config.host,password=config.password,database=config.database)
cursor = cnx.cursor()
try:
    opts, args = getopt.getopt(sys.argv[1:], "v", ["help"])
except getopt.GetoptError as err:
    print
    print str(err) # will print something like "option -a not recognized"
    #print "Try '-h' for more information"
    sys.exit()
if len(sys.argv) > 1:
    for options, a in opts:
        if options=='-v':
            cursor.execute("select table_schema ,engine, count(*) tables from information_schema.tables where table_schema not in ('information_schema','mysql','performance_schema','test') group by engine;")
            result_set=cursor.fetchall()
            result=[(column[0],column[1],column[2]) for column in result_set]
            print '\033[1;32mENGINES IN TABLES\033[1;m'
            print "\n"
            verbose("Table schema\t\t\t\t:%s\nEngine\t\t\t\t\t:%s\nNumber of tables\t\t\t:%s" %(column[0],column[1],column[2]))
            print
            cursor.execute("show global variables like 'performance_schema';")
            result_set=cursor.fetchall()
            result=[(column[1]) for column in result_set]
            verbose("Performance_Schema_Status\t\t:%s" %(column[1]))
            print
            os.system("top -n 2 | grep mysql > test.txt")
            val=os.system("cat test.txt | head -1 | awk '{print $11}'")
            verbose("Mysql memory is " %(val))
            sys.exit()

        else:
            print
            sys.exit(2)
else:
    cursor.execute("SHOW GLOBAL STATUS LIKE 'Uptime';")
    result_set=cursor.fetchall()
    result=[(column[1]) for column in result_set]
    print '\033[1;32mMYSQL-UPTIME\033[1;m'
    print "\n"
    verbose("MySQL Uptime is\t\t\t\t:%s" %(column[1]))
    print
    cursor.execute("show global status like 'threads_running';")
    result_set=cursor.fetchall()
    result=[(column[1]) for column in result_set]
    verbose("Number of Threads Running\t\t:%s" %(column[1]))
    print
    cursor.execute("show global status like 'Max_used_connections';")
    result_set=cursor.fetchall()
    result=[(column[1]) for column in result_set]
    verbose("Maximum number of connections\t\t:%s" %(column[1]))
    print
    cursor.execute("show engines")
    result_set=cursor.fetchall()
    result=[(column[0],column[1],column[3],column[4],column[5]) for column in result_set]
    print '\033[1;32mENGINE\033[1;m'
    print "\n"
    verbose("Engine\t\t\t\t\t:%s\nSupport\t\t\t\t\t:%s\nTransactions\t\t\t\t:%s\nXA\t\t\t\t\t:%s\nSavepoints\t\t\t\t:%s" %(column[0],column[1],column[3],column[4],column[5]))
    print
    cursor.execute("show global variables like 'log_error';")
    result_set=cursor.fetchall()
    result=[(column[1]) for column in result_set]
    print '\033[1;32mERROR\033[1;m'
    print "\n"
    verbose("Error_Log\t\t\t\t:%s" %(column[1]))
    #os.system("cat (%column[1])" )
    res=column[1]
    print
    print "Last Errors are :"
    os.system("cat %s | grep 2015 | tail -3" %(res))
    print
    cursor.execute("select trx.trx_id,trx.trx_started,trx.trx_mysql_thread_id from information_schema.innodb_trx trx join information_schema.processlist ps on trx.trx_mysql_thread_id = ps.id where trx.trx_started < current_timestamp - interval 1 second and ps.user !='system_user';")
    result_set=cursor.fetchall()
    result=[(column[0],column[1],column[2]) for column in result_set]
    verbose("Transaction_ID\t\t:%s\nTransaction_started\t\t:%s\nMysql_Thread_ID\t\t:%s" %(column[0],column[1],column[2]))
    print

    # ...
