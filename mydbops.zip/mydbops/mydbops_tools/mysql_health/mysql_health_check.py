import getopt, sys
import config
import mysql.connector
import os
import subprocess
from decimal import *
getcontext().prec=2
o=sys.argv[0:]
def verbose(message):
   print "%s" % message
cnx = mysql.connector.connect(user=config.user,host=config.host,password=config.password,database=config.database)
cursor = cnx.cursor()
try:
    opts, args = getopt.getopt(sys.argv[1:], "hv", ["verbose"])
except getopt.GetoptError as err:
    print ""
    print str(err) # will print something like "option -a not recognized"
    sys.exit()
if len(sys.argv) > 1:
    for o, a in opts:
        if o=='-v': 
            print '\033[1;32m--------------------------------------- MYSQL-HEALTH --------------------------------------------\033[1;m'
            print '\033[1;32mSERVER UP TIME\033[1;m'
            time=os.system("mysqladmin  version | grep -i uptime")#Uptime
            cursor.execute("select @@version;")#mysql Version
            result_set=cursor.fetchall()
            result=[(column[0]) for column in result_set]
            print '\033[1;32mMYSQL-VERSION\033[1;m'
            verbose("Version\t\t\t\t:%s" %(column[0]))
            cursor.execute("select @@innodb_version;;")#innodb Version
            result_set=cursor.fetchall()
            result=[(column[0]) for column in result_set]
            print '\033[1;32mINNODB-VERSION\033[1;m'
            verbose("Storage Engine Version\t\t:%s" %(column[0]))
            cursor.execute("show engines")#Engine_status
            result_set=cursor.fetchall()
            result=[(column[0],column[1],column[3],column[4],column[5]) for column in result_set]
            print '\033[1;32mENGINE\033[1;m'
            verbose("Engine\t\t\t\t:%s\nSupport\t\t\t\t:%s\nTransactions\t\t\t:%s\nXA\t\t\t\t:%s\nSavepoints\t\t\t:%s" %(column[0],column[1],column[3],column[4],column[5]))
            cursor.execute("select count(*) as Views from information_schema.views;")#View
            result_set=cursor.fetchall()
            result=[(column[0]) for column in result_set]
            print '\033[1;32mVIEWS\033[1;m'
            verbose("Total Number of Views\t\t:%s" %(column[0]))
            cursor.execute("select count(*) as Functions from information_schema.routines where routine_type='function';")#Function
            result_set=cursor.fetchall()
            result=[(column[0]) for column in result_set]
            print '\033[1;32mFUNCTIONS\033[1;m'
            verbose("Total Number of Function\t:%s" %(column[0]))
            cursor.execute("select count(*) as Procedures from information_schema.routines where routine_type = 'procedure';")#Procedures
	    result_set=cursor.fetchall()
            result=[(column[0]) for column in result_set]
            print '\033[1;32mPROCEDURES\033[1;m'
            verbose("Total Number of PROCEDURES\t:%s" %(column[0]))
            print '\033[1;32mMYSQL PROCESS ID\033[1;m'
            os.system("pidof ,^ mysql")
            #-------------------------------------------------------------------------------------------------
            print '\033[1;32mMYSQL CPU & MEMORY USAGE\033[1;m'
            os.system("ps -p $(pidof mysql | sed 's/\s/,/g') -o %cpu,%mem")#Cpu & Memory Usage
            cursor.execute("show global variables like 'slow_query_log';")#slow_log
            result_set=cursor.fetchall()
            result=[(column[1]) for column in result_set]
            print '\033[1;32mLOGS\033[1;m'
            verbose("SLow Query Log\t:%s" %(column[1]))
            cursor.execute("show global variables like 'general_log';")
            result_set=cursor.fetchall()
            result=[(column[1]) for column in result_set]
            verbose("General Log\t:%s" %(column[1]))
            cursor.execute("show global variables like 'log_error';")#Error_Log
            result_set=cursor.fetchall()
            result=[(column[1]) for column in result_set]
            print '\033[1;32mERROR\033[1;m'
            #print "\n"
            verbose("Error_Log\t\t\t:%s" %(column[1]))
            res=column[1]
            print
            print "Last Errors are :"
            os.system("cat %s | grep ERROR | tail -n1" %(res))
            cursor.execute("show global variables like 'performance_schema';")#performance
            result_set=cursor.fetchall()
            result=[(column[1]) for column in result_set]
            print '\033[1;32mPERFORMANCE_SCHEMA STATUS\033[1;m'
	    verbose("Performance_Schema_Status\t\t:%s" %(column[1]))
            cursor.execute("show global status like 'threads_running';")#threads
            result_set=cursor.fetchall()
            result=[(column[1]) for column in result_set]
            print '\033[1;32mRUNNING THREADS\033[1;m'
            verbose("Number of Threads Running\t\t:%s" %(column[1]))
            cursor.execute("show global status like 'Max_used_connections';")#max_connection
            result_set=cursor.fetchall()
            result=[(column[1]) for column in result_set]
            print '\033[1;32mMAX NUMBER OF CONNECTIONS\033[1;m'
            verbose("Maximum number of connections\t\t:%s" %(column[1]))
            cursor.execute("select table_schema,engine, count(*) tables from information_schema.tables where table_schema not in ('information_schema','mysql','performance_schema','test') group by table_schema;")
            result_set=cursor.fetchall()
            print '\033[1;32mENGINES & TABLES\033[1;m'#Engines & Tables
            widths = []
            columns = []
            tavnit = '|'
            separator = '+'

            for cd in cursor.description:
                widths.append(max(cd[2], len(cd[0])))
                columns.append(cd[0])

            for w in widths:
                tavnit += " %-"+"%ss |" % (w,)
                separator += '-'*w + '--+'

            print(separator)
            print(tavnit % tuple(columns))
            print(separator)
            for row in result_set:
                print(tavnit % row)
            print(separator)
	    cursor.execute(" select table_schema as DB_Name,table_name as Table_Name,concat(round(((data_length+index_length)/(1024*1024*1024)),2),' GB') as 'Total_Size',engine as Table_Engine from information_schema.tables where table_schema not in ('mysql','test','performance_schema','information_schema','eximstats') order by ((data_length+index_length)/(1024*1024)) desc limit 10;")
            result_set=cursor.fetchall()
            print '\033[1;32mTOP 10 TABLES\033[1;m'#Top 10 Tables
            widths = []
            columns = []
            tavnit = '|'
            separator = '+'

            for cd in cursor.description:
                widths.append(max(cd[2], len(cd[0])))
                columns.append(cd[0])

            for w in widths:
                tavnit += " %-"+"%ss |" % (w,)
                separator += '-'*w + '--+'
            print(separator)
            print(tavnit % tuple(columns))
            print(separator)
            for row in result_set:
                print(tavnit % row)
            print(separator)
            cursor.execute("select trx.trx_id,trx.trx_started,trx.trx_mysql_thread_id from information_schema.innodb_trx trx join information_schema.processlist ps on trx.trx_mysql_thread_id = ps.id where trx.trx_started < current_timestamp - interval 1 second and ps.user !='system_user';")
            result_set=cursor.fetchall()
            print '\033[1;32mLONG RUNNING TRANSACTIONS\033[1;m'#Long Running Transaction
            #print "\n"
            widths = []
            columns = []
            tavnit = '|'
            separator = '+'

            for cd in cursor.description:
                widths.append(max(cd[2], len(cd[0])))
                columns.append(cd[0])

            for w in widths:
                tavnit += " %-"+"%ss |" % (w,)
                separator += '-'*w + '--+'
	    print(separator)
            print(tavnit % tuple(columns))
            print(separator)
            for row in result_set:
                print(tavnit % row)
            print(separator)  
	if o=='-h':
	    print " Help Arguments "
	    print " -v [Verbose] \n -h [help] " 
else:
    print '\033[1;32m--------------------------------------- MYSQL-HEALTH --------------------------------------------\033[1;m'
    print '\033[1;32mSERVER UP TIME\033[1;m'
    time=os.system("mysqladmin  version | grep -i uptime")#Uptime
    cursor.execute("select @@version;")#mysql Version
    result_set=cursor.fetchall()
    result=[(column[0]) for column in result_set]
    print '\033[1;32mMYSQL-VERSION\033[1;m'
    verbose("Version\t\t\t\t:%s" %(column[0]))
    cursor.execute("select @@innodb_version;;")#innodb Version
    result_set=cursor.fetchall()
    result=[(column[0]) for column in result_set]
    print '\033[1;32mINNODB-VERSION\033[1;m'
    verbose("Storage Engine Version\t\t:%s" %(column[0]))
    cursor.execute("show engines")#Engine_status
    result_set=cursor.fetchall()
    result=[(column[0],column[1],column[3],column[4],column[5]) for column in result_set]
    print '\033[1;32mENGINE\033[1;m'
    verbose("Engine\t\t\t\t:%s\nSupport\t\t\t\t:%s\nTransactions\t\t\t:%s\nXA\t\t\t\t:%s\nSavepoints\t\t\t:%s" %(column[0],column[1],column[3],column[4],column[5]))
    cursor.execute("select count(*) as Views from information_schema.views;")#View
    result_set=cursor.fetchall()
    result=[(column[0]) for column in result_set]
    print '\033[1;32mVIEWS\033[1;m'
    verbose("Total Number of Views\t\t:%s" %(column[0]))
    cursor.execute("select count(*) as Functions from information_schema.routines where routine_type='function';")#Function
    result_set=cursor.fetchall()
    result=[(column[0]) for column in result_set]
    print '\033[1;32mFUNCTIONS\033[1;m'
    verbose("Total Number of Function\t:%s" %(column[0]))
    cursor.execute("select count(*) as Procedures from information_schema.routines where routine_type = 'procedure';")#Procedures
    result_set=cursor.fetchall()
    result=[(column[0]) for column in result_set]
    print '\033[1;32mPROCEDURES\033[1;m'
    verbose("Total Number of PROCEDURES\t:%s" %(column[0]))
    print '\033[1;32mMYSQL PROCESS ID\033[1;m'
    os.system("pidof ,^ mysql")
    print '\033[1;32mQUREY PER SECOND\033[1;m'#QPS
    cursor.execute("show global status like 'queries'")
    result_set=cursor.fetchall()
    a=[column[1] for column in result_set]
    a=int(column[1])
    cursor.execute("select sleep(5)")
    result_set=cursor.fetchall()
    cursor.execute("show global status like 'queries'")
    result_set=cursor.fetchall()
    b=[column[1] for column in result_set]
    b=int(column[1])
    c =b - a
    c=float(c)
    d=c/5
    d=float(d)
    print "Queries Per Five Second :", format(Decimal.from_float(d),'.5')
sys.exit()

