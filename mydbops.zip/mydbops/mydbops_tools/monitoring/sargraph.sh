#!/bin/bash


set -x


source /home/suresh/source_file.txt


#mysql --user $user --password $pwd --host $host --port $port 


sadf -p -P 1 > $team

sed 's/%/ / g' $team > $team1

awk '{ print $1","$2","$3","$4","$5","$6","$7","$8 }' $team1 > $team2


chown -R mysql.mysql $team2



mysql -e "CREATE TABLE $database.$table (user varchar(100) NOT NULL,psid varchar(100) NOT NULL,date varchar(100) NOT NULL,time_Stamp varchar(100) NOT NULL,zone varchar(100) NOT NULL,cpu varchar(100) NOT NULL,command varchar(100) NOT NULL,cpu_usage varchar(100) NOT NULL );"


mysql -e "load data local infile '/tmp/operation2.txt' into table $database.$table FIELDS TERMINATED BY ',';" 



