import mysql.connector,os,sys
cnx = mysql.connector.connect(user='root', host='localhost' ,password='' ,port=3306, database='')
cursor = cnx.cursor()
orig_stdout = sys.stdout
f = file('/tmp/mysql.cnf.txt', 'w')
sys.stdout = f
cursor.execute("show global variables")
result_set=cursor.fetchall()
widths = []
columns = []
tavnit = '|'
separator = '+'
for cd in cursor.description:
    widths.append(max(cd[2], len(cd[0])))
    columns.append(cd[0])
for w in widths:
    tavnit += " %--"+"%ss |" % (w,)
    separator += '-'*w + '--+'
print(separator)
print(tavnit % tuple(columns))
print(separator)
for row in result_set:
    print(tavnit % row)
print(separator)
print
sys.stdout = orig_stdout
f.close()
os.system("less /usr/local/mysql/my.cnf > /tmp/my.cnf.txt")
os.system("grep -E /tmp/mysql.cnf.txt /tmp/my.cnf.txt > /tmp/result.txt")
os.system("cat /tmp/result.txt")
