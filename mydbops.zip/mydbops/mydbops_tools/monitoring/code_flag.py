import getopt, sys
import mysql.connector
import os
import subprocess
import smtplib
def verbose(message):
   print "%s" % message
cnx=mysql.connector.connect(user='test',host='localhost',password='test123')
cursor = cnx.cursor()
print '\033[1;32m--------------------------------------- Read_Only_Flag --------------------------------------------\033[1;m'
print '\033[1;32mREAD_FLAG\033[1;m'
print "\n"
cursor.execute("show global variables like 'read_only';")
result_set=cursor.fetchall()
result=[(column[1]) for column in result_set]
verbose("Read_Flag_Status\t\t:%s" %(column[1]))
if len(column[1]) == 3:
 sender = 'readonly_check@labs1.mydbops.com'
 receivers = ['ponsuresh@mydbops.com']

 message = """From: Readonly_check <readonly_check@labs1.mydbops.com>
To: To Person <ponsuresh@mydbops.com>
Subject: Read flag Status

The Read_Flag Status is OFF.
"""
try:
   smtpObj = smtplib.SMTP('localhost')
   smtpObj.sendmail(sender, receivers, message)
   print "Successfully sent email"
except:
   print "Error: unable to send email"
sys.exit(2)

