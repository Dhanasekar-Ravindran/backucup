if [[ $1 == "claymx" ]];
then
host="Claymx"
ssh="ssh claymx"
user="root"
pass="Claymotion@123"
fi