#!/bin/sh
#!/bin/bash
#Version : 1.0
#Purpose : MySQL Security Audit
set -x
time=$(date +'%d-%b-%Y %H:%M:%S')
email="/home/mydbops/mysql_security"
receiver="dba-group@mydbops.com"
echo  "FROM: 'Mysql Security Audit' <mysql_security@mydbops.com>" > $email/table1.html
echo  "TO: $receiver" >> $email/table1.html
echo  "SUBJECT: Mysql Secuirty Audit on $time" >> $email/table1.html
echo  "Content-type: text/html" >> $email/table1.html
echo  "<html><body>" >> $email/table1.html
echo  "Hi Team,<br><br>Here are the following mysql user security<br><br>Kindly verify it.<br><br>">>  $email/table1.html
echo  "<center><b><h1><blink>MySQL User Security</blink><h1></b></center>" >> $email/table1.html
cat ~/.ssh/config | grep -w '^Host' | awk '{print $2}' > $email/hosts.txt
hostfile="$email/hosts.txt"
cline=$(less $hostfile | wc -l )
cl=1
while [[ "$cl" -le "$cline" ]];
do
shard=$(cat $hostfile | head -n$cl | tail -n1)
if [[ "$shard" -eq "mariadb" ]];
then
spuser="$email/$shard:spuser.txt"
nopwduser="$email/$shard:nopwduser.txt"
unknwnhost="$email/$shard:unknwnhost.txt"
ssh $shard "mysql -e 'select user,host from mysql.user where super_priv=\"Y\" and host not in (\"122.166.212.214\") and user not in (\"root\",\"mydbops\",\"backup\",\"pt_check\",\"bin_user\");'" > $spuser
ssh $shard "mysql -e 'select user,host from mysql.user where password=\"\"'" > $nopwduser
ssh $shard "mysql -e 'select user,host from mysql.user where host=\"%\" and user not in (\"pt_check\",\"mydbops\",\"bin_user\",\"backup\");'" > $unknwnhost
line=$(cat $spuser | wc -l)
echo  "<br><center><h2><b>$shard</b></h2></center>" >> $email/table1.html
echo  "<br><center>The user and Host with Super Privilges</center><br>" >> $email/table1.html
if [[ -s $spuser ]];
then
echo  "<table border='1' cellpadding='0' cellspacing='0' width='200px' align='center'><th><font color='black'>User</th><th><font color='black'>Host</th>" >> $email/table1.html
s=1
while [[ "$s" -le "$line" ]];
do
  val1=$(cat $spuser | head -n$s | tail -n1 | awk '{print $1}' )
  val2=$(cat $spuser | head -n$s | tail -n1 | awk '{print $2}')
  echo "<tr><td>$val1</td><td>$val2</td><tr>" >> $email/table1.html
s=`expr $s + 1`
done
echo  "</table>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
line1=$(cat $nopwduser | wc -l)
echo  "<br><center>The user and Host which has no password</center><br>" >> $email/table1.html
if [[ -s $nopwduser ]];
then
echo  "<table border="1" width='200px' cellpadding='0' cellspacing='0' align='center'><th><font color='RED'>User</th><th><font color='RED'>Host</th>" >> $email/table1.html
n=1
while [[ "$n" -le "$line1" ]];
do
  val1=$(cat $nopwduser | head -n$n | tail -n1 | awk '{print $1}' )
  val2=$(cat $nopwduser | head -n$n | tail -n1 | awk '{print $2}')
  echo "<tr><td><font color='RED'>$val1</td><td><font color='RED'>$val2</td><tr>" >> $email/table1.html
n=`expr $n + 1`
done
echo  "</table>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
line2=$(cat $unknwnhost | wc -l )
echo  "<br><center>The user and Host which has unknown host</center><br>" >> $email/table1.html
if [[ -s $unknwnhost ]];
then
echo  "<table border='1' cellpadding='0' cellspacing='0' width='200px' align='center'><th><font color='black'>User</th><th><font color='black'>Host</th>" >> $email/table1.html
u=1
while [[ "$u" -le "$line2" ]];
do
  val1=$(cat $unknwnhost | head -n$u | tail -n1 | awk '{print $1}' )
  val2=$(cat $unknwnhost | head -n$u | tail -n1 | awk '{print $2}')
  echo "<tr><td>$val1</td><td>$val2</td><tr>" >> $email/table1.html
u=`expr $u + 1`
done
echo  "</table>" >> $email/table1.html
echo  "<br>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
elif [[ "$shard" -ne "mariadb"  ]];
then
spuser="$email/$shard:spuser.txt"
nopwduser="$email/$shard:nopwduser.txt"
unknwnhost="$email/$shard:unknwnhost.txt"
ssh $shard "mysql --login-path=mydbops -e 'select user,host from mysql.user where super_priv=\"Y\" and host not in (\"122.166.212.214\") and user not in (\"root\",\"mydbops\",\"backup\",\"pt_check\",\"bin_user\");'" > $spuser
ssh $shard "mysql --login-path=mydbops -e 'select user,host from mysql.user where password=\"\"'" > $nopwduser
ssh $shard "mysql --login-path=mydbops -e 'select user,host from mysql.user where host=\"%\" and user not in (\"pt_check\",\"mydbops\",\"bin_user\",\"backup\");'" > $unknwnhost
line=$(cat $spuser | wc -l)
echo  "<br><center><h2><b>$shard</b></h2></center></br>" >> $email/table1.html
echo  "<br><center>The user and Host with Super Privilges</center><br>" >> $email/table1.html
if [[ -s $spuser ]];
then
echo  "<table border='1' cellpadding='0' cellspacing='0' width='200px' align='center'><th><font color='black'>User</th><th><font color='black'>Host</th>" >> $email/table1.html
s=1
while [[ "$s" -le "$line" ]];
do
  val1=$(cat $spuser | head -n$s | tail -n1 | awk '{print $1}' )
  val2=$(cat $spuser | head -n$s | tail -n1 | awk '{print $2}')
  echo "<tr><td>$val1</td><td>$val2</td><tr>" >> $email/table1.html
s=`expr $s + 1`
done
echo  "</table>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
line1=$(cat $nopwduser | wc -l)
echo  "<br><center>The user and Host which has no password</center><br>" >> $email/table1.html
if [[ -s $nopwduser ]];
then
echo  "<table border="1" width='200px' cellpadding='0' cellspacing='0' align='center'><th><font color='RED'>User</th><th><font color='RED'>Host</th>" >> $email/table1.html
n=1
while [[ "$n" -le "$line1" ]];
do
  val1=$(cat $nopwduser | head -n$n | tail -n1 | awk '{print $1}' )
  val2=$(cat $nopwduser | head -n$n | tail -n1 | awk '{print $2}')
  echo "<tr><td><font color='RED'>$val1</td><td><font color='RED'>$val2</td><tr>" >> $email/table1.html
n=`expr $n + 1`
done
echo  "</table>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
line2=$(cat $unknwnhost | wc -l )
echo  "<br><center>The user and Host which has unknown host</center><br>" >> $email/table1.html
if [[ -s $unknwnhost ]];
then
echo  "<table border='1' cellpadding='0' cellspacing='0' width='200px' align='center'><th><font color='black'>User</th><th><font color='black'>Host</th>" >> $email/table1.html
u=1
while [[ "$u" -le "$line2" ]];
do
  val1=$(cat $unknwnhost | head -n$u | tail -n1 | awk '{print $1}' )
  val2=$(cat $unknwnhost | head -n$u | tail -n1 | awk '{print $2}')
  echo "<tr><td>$val1</td><td>$val2</td><tr>" >> $email/table1.html
u=`expr $u + 1`
done
echo  "</table>" >> $email/table1.html
echo  "<br>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
fi
echo  "==================================================================================================================================================================" >> $email/table1.html
cl=`expr $cl + 1`
done
echo "</body></html>" >> $email/table1.html
echo "<br><br><br>Regards,<br>Mydbops Monitoring<br>(Alerts)<br>" >> $email/table1.html
cat $email/table1.html | /usr/sbin/sendmail $receiver

