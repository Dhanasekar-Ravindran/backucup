#!/bin/sh
#!/bin/bash

#Version : 3.0
#Purpose : Backup_script
#Author  : Bharath Kumar(MyDBOPS)

set -x
###################################################################################################################
                                                #Config Details
###################################################################################################################
start_back=`date +'%d-%b-%Y %H:%M:%S'`
echo "start at `date +'%d-%b-%Y %H:%M:%S'`"


source /etc/backup.conf

  bdate=`date +'%d-%b-%Y'`
  type=`date +'%A'`
  week=`date +'%Wth-Week'`
  fold_date=`date +'%d-%b-%a'`
  bktime=`date +'%d-%a-%H_%M'`

  mysql_path=$(which mysql)
  xtra_path=$(which innobackupex)

###################################################################################################################
#Check mount drive 

if [[ $mount_drive == no ]];
then
echo "No mounted drive"
do_backup="yes"
else
echo "find available mounted drive"
avb_mnt=$(df -T | grep -o $mount_drive_path | tail -n1)
 if [[ "$mount_drive_path" == "$avb_mnt" ]] ; then
 do_backup="yes"
echo "Mount drive ($mount_drive_path) found"
 else
 do_backup="no"
echo "Mount drive ($mount_drive_path) not found"
 fi 
fi

####################################################################################################################
if [[ $do_backup == yes ]]; then
echo "Proceed Backup"
  
echo "Host : $host_address" >> $list_path/back_details.txt
echo "Client : $client_name" >> $list_path/back_details.txt
echo "SSH_Config: $ssh_config_name" >> $list_path/back_details.txt
echo "Back_Method : Hot" >> $list_path/back_details.txt

if [[ $mount_drive == no ]];
echo "no drive usage"
else
mount_size=$(du -sh  $mount_drive_path | awk '{print $1}')  
echo "drive_usage : $mount_size" >> $list_path/back_details.txt
fi
#Remove old files
rm -r $mail_path/*.txt
rm -r $mail_path/*.html

###################################################################################################################
                                                #Backup of data
###################################################################################################################

#Check for backup type
if [[ $enable_compression == no ]]; then
inno_flags="--no-lock --galera-info --no-timestamp"
else
inno_flags="--no-lock --galera-info --compress --compress-threads=4 --no-timestamp"
fi

#Backup of data
if [[ "$type" == $back_day ]];
then
back_type="Full Backup"
echo "Backup_Type : Full" >> $list_path/back_details.txt
echo "Full backup"

/bin/mkdir $back_path/$week
/bin/mkdir $back_path/$week/incremental

drop=$(ls -lrth $back_path | grep Week | awk '{print $9}' | wc -l)
if [[ $drop -ge 2 ]] ;
then
ls -lrth $back_path/ | grep Week | awk '{print $9}' | head -n1 > $list_path/remove.txt
else
echo "No old files"
fi


# Backup database
$xtra_path --defaults-file=$server_cnf --socket=$server_socket --user=$back_user --password=$back_password $inno_flags --export $back_path/$week/full_backup-$fold_date  1>$log_path/full_xtra.log 2>$log_path/full_xtra.err

if [[ $enable_compression == no ]]; then
cat $back_path/$week/full_backup-$fold_date/xtrabackup_info > $sub_path/xtrabackup_info
else
/bin/qpress -d $back_path/$week/full_backup-$fold_date/xtrabackup_info.qp $sub_path/
fi

echo "$back_path/$week" > $list_path/list.txt
echo "$back_path/$week/incremental" > $list_path/week_path.txt
echo "$back_path/$week/full_backup-$fold_date" > $list_path/week.txt


#Get the status
back_status=$(cat $log_path/full_xtra.err | tail -n1 | grep -o completed)
if [[ $back_status == completed ]]; then
backup_today="Success"
else
backup_today="Failure"
cat $log_path/full_xtra.err | grep -i error > $sub_path/back_error
fi
echo "Backup_Status : $backup_today" >> $list_path/back_details.txt
#Get the backup size
du -sh $back_path/$week/full_backup-$fold_date > $sub_path/file_size.txt
backupsize=$(cat $sub_path/file_size.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $list_path/back_details.txt
#Get the backup file
backup_file=$(cat $sub_path/file_size.txt | awk '{print $2}')
echo "Backup_Path : $backup_file" >> $list_path/back_details.txt
echo "Error_log_path : $log_path/full_xtra.err" >> $list_path/back_details.txt
cat $back_path/$week/full_backup-$fold_date/xtrabackup_info > $list_path/backup.info

#Get binary log details
$mysql_path --user=$back_user --password=$back_password -e  "show global variables like 'log_bin';" -s -N > $mail/binlog.txt

bin_log=$(cat $mail/binlog.txt | awk '{print $2}')
if [[ $bin_log == 'ON' ]];
then
binlog_avb=1
 log_file=$(cat $back_path/$week/full_backup-$fold_date/xtrabackup_binlog_info | awk '{print $1}')
 log_pos=$(cat $back_path/$week/full_backup-$fold_date/xtrabackup_binlog_info | awk '{print $2}')

 echo "Binlog_file : $log_file" >> $list_path/back_details.txt
echo "Binlog_file : $log_pos" >> $list_path/back_details.txt
else
binlog_avb=0
fi

if [[ "$back_status" == completed ]];
then
echo "completed"
else
rm -rf $back_path/$week
fi

#For incremental take lsn number
cat $log_path/full_xtra.err | tail -n10 | grep -w 'Transaction log' | awk '{print $6}' | sed 's/(//' | sed 's/)//' > $sub_path/lsn_no.txt

#To get archived backups
drop=$(ls -lrth $back_path | grep Week | awk '{print $9}' | wc -l)

        if [[ $drop -ge 2 ]] ;
        then
        remove_file=$(cat $list_path/remove.txt)
        du -sh $back_path/$remove_file > $sub_path/old_file.txt
        arch_file=$(cat $sub_path/old_file.txt | awk '{print $2}')
        arch_size=$(cat $sub_path/old_file.txt | awk '{print $1}')
		
				if [[ "$back_status" == completed ]];
				then
				echo "Purge_Backup : $arch_file" >> $list_path/back_details.txt
				rm -rf $back_path/$remove_file
				else
				echo "Backup not completed"
				fi
        else
        echo "No files to be archived"
        fi	
		
else

back_type="Incremental Backup"
echo "Backup_Type : Incremental" >> $list_path/back_details.txt
echo "Incremental backup"


lsn_number=$(cat $sub_path/lsn_no.txt)
bk_path=$(cat $list_path/week_path.txt)


# Backup database
$xtra_path --defaults-file=$server_cnf --socket=$server_socket --user=$back_user --password=$back_password --incremental --incremental-lsn=$lsn_number  $bk_path/inc_backup-$fold_date_$bktime $inno_flags  1>$log_path/inc_xtra.log 2>$log_path/inc_xtra.err

if [[ $enable_compression == no ]]; then
cat $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_info > $sub_path/xtrabackup_info
else
/bin/qpress -d $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_info.qp $sub_path/
fi

#Get the status
back_status=$(cat $log_path/inc_xtra.err | tail -n1 | grep -o completed)
if [[ $back_status == completed ]]; then
backup_today="Success"
else
backup_today="Failure"
cat $log_path/inc_xtra.err | grep -i error > $sub_path/back_error
fi
echo "Backup_Status : $backup_today" >> $list_path/back_details.txt
#Get the backup size
du -sh $bk_path/inc_backup-$fold_date_$bktime > $sub_path/file_size.txt
backupsize=$(cat $sub_path/file_size.txt | awk '{print $1}')
echo "Backup_Size : $backupsize" >> $list_path/back_details.txt
#Get the backup file
backup_file=$(cat $sub_path/file_size.txt | awk '{print $2}')
echo "Backup_Path : $backup_file" >> $list_path/back_details.txt
echo "Error_log_path : $log_path/inc_xtra.err" >> $list_path/back_details.txt
cat $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_info > $list_path/backup.info


#Get binary log details
$mysql_path --user=$back_user --password=$back_password -e "show global variables like 'log_bin';" -s -N > $mail/binlog.txt

bin_log=$(cat $mail/binlog.txt | awk '{print $2}')
if [[ $bin_log == 'ON' ]];
then
binlog_avb=1
 log_file=$(cat $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_binlog_info | awk '{print $1}')
 log_pos=$(cat $bk_path/inc_backup-$fold_date_$bktime/xtrabackup_binlog_info | awk '{print $2}')
 
echo "Binlog_file : $log_file" >> $list_path/back_details.txt
echo "Binlog_size : $log_pos" >> $list_path/back_details.txt
else
binlog_avb=0
fi


if [[ "$back_status" == completed ]];
then
cat $log_path/inc_xtra.err | tail -n10 | grep -w 'Transaction log' | awk '{print $6}' | sed 's/(//' | sed 's/)//' > $sub_path/lsn_no.txt
else
rm -rf $bk_path/inc_backup-$fold_date_$bktime
fi

#To get available backups

#Available backups

du -sh $back_path/*/full* > $mail_path/full_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Full Backup</center></b></td></tr> " > $mail_path/avb_back.txt
cat $mail_path/full_back.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail_path/avb_back.txt

echo "<tr><td nowrap='' colspan="2"><b><center>Incremental Backup</center></b></td></tr>" >> $mail_path/avb_back.txt

for  i in `ls -lth $bk_path/ | grep inc | sort -Mr | awk '{print $9}'`
do
du -sh $bk_path/$i >> $mail_path/back_order.txt
done

cat $mail_path/back_order.txt | awk '{print $2 " - " $1}' | sed 's/.*/<tr><td>&<\/td><\/tr>/' | sed 's/ - /<\/td><td>/' >> $mail_path/avb_back.txt
avb_inc_backup=$(cat $mail_path/avb_back.txt)

fi

###################################################################################################################
                                        #Sending mails
###################################################################################################################


if [[ "$back_status" == completed ]];
then
status="Success"
color="green"
echo  "FROM: '$client_name Backup' <novopay-backup@mydbops.com>" > $mail_path/table.html
echo  "TO: $receiver" >> $mail_path/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($host_server) is $status" >> $mail_path/table.html
echo  "Content-type: text/html" >> $mail_path/table.html
echo  "<html><body>" >> $mail_path/table.html
echo  "Hi Team,<br><br>" >> $mail_path/table.html
echo  "MySQL Backup on $host_server ($host_address) is <b><font color='$color'>$status.</font></b><br>" >> $mail_path/table.html
echo  "<br><center><b>Binary log details</b></center><br>" >> $mail_path/table.html
if [[ $binlog_avb == 1 ]];
then
echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Binlog File</th><th><font color='blue'>Binlog Position</th></tr><tr><td>$log_file</td><td>$log_pos</td></tr></table>" >> $mail_path/table.html
else
echo   "You are not using binary log.<br>" >> $mail_path/table.html
fi
echo  "Backup Type : <b>$back_type</b><br>" >> $mail_path/table.html
        if [[ $back_type == "Full Backup" ]];
        then
                echo  "<br><center><b>Full Backup size for today</b></center><br>" >> $mail_path/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail_path/table.html
                                if [[ $drop -ge 2 ]]; then
                echo  "<br><center><b>Archieved backups</b></center><br>" >> $mail_path/table.html
                echo  "<table border='1' width='400px' align='center'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File name</th><th><font color='blue'>File size</th></tr><tr><td>$arch_file</td><td>$arch_size</td></tr></table><br>" >> $mail_path/table.html
                                fi
        else

                echo  "<br><center><b>Incremental backup size for today</b></center><br>" >> $mail_path/table.html
                echo  "<table border='1' width='400px' align='center' cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>Backup File-Full Path</th><th><font color='blue'>File size</th></tr><tr><td>$backup_file</td><td>$backupsize</td></tr></table><br>" >> $mail_path/table.html

                echo  "<center><b>Available backups</b></center><br>" >> $mail_path/table.html
                echo  "<center><table border='1' width='400px'  cellpadding='0' cellspacing='0'><tr align='center'><th><font color='blue'>File Name</th><th><font color='blue'>File Size</th></tr>$avb_inc_backup</table></center>" >> $mail_path/table.html
        fi

echo  "</body></html>" >> $mail_path/table.html
        if [[ $rem_mail == yes ]]; then
        cat $mail_path/table.html | ssh $mail_user@$mail_host "$sendmail_path -i -t"
        else
        cat $mail_path/table.html | $sendmail_path -i -t
        fi

else
status="Failure"
color="red"
echo  "FROM: '$client_name Backup' <novopay-backup@mydbops.com>" > $mail_path/table.html
echo  "TO: $receiver" >> $mail_path/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($host_server) is $status" >> $mail_path/table.html
echo  "Content-type: text/html" >> $mail_path/table.html
echo  "<html><body>" >> $mail_path/table.html
echo  "Hi Team,<br><br>" >> $mail_path/table.html
echo  "MySQL Backup on $host_server is <b><font color='$color'>$status</font></b><br>" >> $mail_path/table.html
echo  "Please check the error log $error_log" >> $mail_path/table.html
echo  "</body></html>" >> $mail_path/table.html
        if [[ $rem_mail == yes ]]; then
        cat $mail_path/table.html | ssh $mail_user@$mail_host "$sendmail_path -i -t"
        else
        cat $mail_path/table.html | $sendmail_path -i -t
        fi
fi


########################section to update backup status to monitor server########################


host=$(cat $list_path/back_details.txt | grep -w  Host | awk '{print $3}')
client=$(cat $list_path/back_details.txt | grep -w  Client | awk '{print $3}')
config_name=$(cat $list_path/back_details.txt | grep -w  SSH_Config | awk '{print $3}')
back_method=$(cat $list_path/back_details.txt | grep -w  Back_Method | awk '{print $3}')
back_type=$(cat $list_path/back_details.txt | grep -w  Backup_Type | awk '{print $3}')
back_status=$(cat $list_path/back_details.txt | grep -w  Backup_Status | awk '{print $3}')
back_size=$(cat $list_path/back_details.txt | grep -w  Backup_Size | awk '{print $3}')
back_path=$(cat $list_path/back_details.txt | grep -w  Backup_Path | awk '{print $3}')
bin_file=$(cat $list_path/back_details.txt | grep -w  Binlog_file | awk '{print $3}')
bin_pos=$(cat $list_path/back_details.txt | grep -w  Binlog_pos | awk '{print $3}')
purged_back=$(cat $list_path/back_details.txt | grep -w  Purge_Backup | awk '{print $3}')
mnt_usage=$(cat $list_path/back_details.txt | grep -w  drive_usage | awk '{print $3}')
err_path=$(cat $list_path/back_details.txt | grep -w  Error_log_path | awk '{print $3}')


started=$(cat $sub_path/xtrabackup_info | grep -w  start_time | awk '{print $3" "$4}')
ended=$(cat $sub_path/xtrabackup_info | grep -w  end_time | awk '{print $3" "$4}')
back_tool=$(cat $sub_path/xtrabackup_info | grep -w  tool_name | awk '{print $3"}')
frm_lsn=$(cat $sub_path/xtrabackup_info | grep -w  innodb_from_lsn | awk '{print $3"}')
to_lsn=$(cat $sub_path/xtrabackup_info | grep -w  innodb_to_lsn | awk '{print $3"}')
compress=$(cat $sub_path/xtrabackup_info | grep -w  compressed | awk '{print $3"}')
encrypt=$(cat $sub_path/xtrabackup_info | grep -w  encrypted | awk '{print $3"}')
gtid=$(cat $sub_path/xtrabackup_info | grep -w  uuid | awk '{print $3"}')

if [[ "$back_status" == completed ]];
then
back_log="No logs"
else
back_log=$(cat $sub_path/back_error)
fi

mysql --login-path=backup_poll -e "insert into mydbops_monitor.BACKUP_ALERT (Client,Host,Config_Name,Backup_Method,Backup_Type,Backup_Tool,Backup_Status,Backup_path,Backup_Size,Binlog_File,Binlog_Pos,gtid,Start_Time,End_Time,From_lsn,To_lsn,Compressed,moddate,encryption,log_file,Error_log,Purged_Backup,mount_usage) values ('$client','$host','$ssh_config','$back_method','$back_type','$back_tool','$back_status','$back_path','$back_size','$bin_file','$bin_pos','$gtid','$started','$ended','$frm_lsn','$to_lsn','$compress',now(),'$encrypt','$err_path','$back_log','$purged_back','$mnt_usage');"

else
end_back=`date +'%d-%b-%Y %H:%M:%S'`

echo  "FROM: '$client_name Backup' <backup@mydbops.com>" > $mail_path/table.html
echo  "TO: $receiver" >> $mail_path/table.html
echo  "SUBJECT: MySQL Hot Backup on $bdate ($host_server) is Failed" >> $mail_path/table.html
echo  "Content-type: text/html" >> $mail_path/table.html
echo  "<html><body>" >> $mail_path/table.html
echo  "Hi Team,<br><br>" >> $mail_path/table.html
echo  "MySQL Backup on $host_server is <b><font color='red'>Failed</font></b><br>" >> $mail_path/table.html
echo  "Reason for Failure : Backup mount point ($mount_drive_path) not found in the server!<br><br>" >> $mail_path/table.html
echo  "Available drives in server : <br><br>" >> $mail_path/table.html
df -h >> $mail_path/table.html
echo  "<br></body></html>" >> $mail_path/table.html
        if [[ $rem_mail == yes ]]; then
        cat $mail_path/table.html | ssh $mail_user@$mail_host "$sendmail_path -i -t"
        else
        cat $mail_path/table.html | $sendmail_path -i -t
        fi

echo "Backup mount point not found"
mysql --login-path=backup_poll -e "insert into mydbops_monitor.BACKUP_ALERT (Client,Host,Config_Name,Backup_Status,Start_Time,End_Time,moddate,log_file) values ('$client_name','$host_address','$ssh_config_name','Failure','$start_back','$end_back',now(),'Backup mount not found');"
fi
###################################################################################################################

echo "end at `date +'%d-%b-%Y %H:%M:%S'`"

###################################################################################################################