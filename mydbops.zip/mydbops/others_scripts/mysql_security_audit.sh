#!/bin/sh
#!/bin/bash
#Version : 2.0
set -x
time=$(date +'%d-%b-%Y %H:%M:%S')
email="/home/dhanasekar/mysql_security"
receiver="dba-group@mydbops.com"
echo  "FROM: 'Mysql Security Audit' <mysql_security@mydbops.com>" > $email/table1.html
echo  "TO: $receiver" >> $email/table1.html
echo  "SUBJECT: Mysql Secuirty Audit on $time" >> $email/table1.html
echo  "Content-type: text/html" >> $email/table1.html
echo  "<html><body>" >> $email/table1.html
echo  "Hi Team,<br><br>Here are the following mysql user security<br><br>Kindly verify it.<br><br>">>  $email/table1.html
echo  "<center><b><h1><blink>MySQL User Security</blink><h1></b></center>" >> $email/table1.html
temfile="$email/host.txt"
hostfile="$email/hosts.txt"
mysql_path="/usr/local/mysql/bin/mysql"
user="db_metadata"
pwd="xIj2MN77"
$mysql_path -u $user -p$pwd -e "select host from mydbops_monitor.MONTAB where Cname not in ('Rupeex','hyperoffice_brazil') and host not in ('novopay_replica_old') order by host;" > $temfile
cat $temfile | sed -e '1d' > $hostfile
cline=$(less $hostfile | wc -l )
cl=1
while [[ "$cl" -le "$cline" ]];
do
client=$(cat $hostfile | head -n$cl | tail -n1)
if [[ ! -d "$email/$client" ]];
then
mkdir $email/$client
else
path="$email/$client"
spuser="$path/spuser.txt"
nopwduser="$path/nopwduser.txt"
unknwnhost="$path/unknwnhost.txt"
hostname=$(ssh $client "hostname")
ssh $client "mysql --login-path=mydbops -e 'select user,host from mysql.user where super_priv=\"Y\" and host not in (\"122.166.212.214\") and user not in (\"dba\",\"root\",\"mydbops\",\"backup\",\"nagios_user\",\"pt_check\",\"bin_user\");'" > $path/spuser.txt
ssh $client "mysql --login-path=mydbops -e 'select user,host from mysql.user where password=\"\"'" > $path/nopwduser.txt
ssh $client "mysql --login-path=mydbops -e 'select user,host from mysql.user where host=\"%\" and user not in (\"haproxy\",\"dba\",\"pt_check\",\"mydbops\",\"nagios_user\",\"bin_user\",\"backup\");'" > $path/unknwnhost.txt
cat $path/spuser.txt | sed -e '1d' > $path/spuser_.txt
line=$(cat $path/spuser_.txt | wc -l)
echo  "<br><center><h2><b>$client</b></h2></center>" >> $email/table1.html
echo  "<br><center>The user and Host with Super Privilges</center><br>" >> $email/table1.html
if [[ -s $spuser ]];
then
echo  "<table border='1' cellpadding='0' cellspacing='0' width='200px' align='center'><th><font color='black'>User</th><th><font color='black'>Host</th>" >> $email/table1.html
s=1
while [[ "$s" -le "$line" ]];
do
  val1=$(cat $path/spuser_.txt | head -n$s | tail -n1 | awk '{print $1}' )
  val2=$(cat $path/spuser_.txt | head -n$s | tail -n1 | awk '{print $2}')
  echo "<tr><td>$val1</td><td>$val2</td><tr>" >> $email/table1.html
s=`expr $s + 1`
done
echo  "</table>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
cat $path/nopwduser.txt | sed -e '1d' > $path/nopwduser_.txt
line1=$(cat $path/nopwduser_.txt | wc -l)
echo  "<br><center>The user and Host which has no password</center><br>" >> $email/table1.html
if [[ -s $nopwduser ]];
then
echo  "<table border="1" width='200px' cellpadding='0' cellspacing='0' align='center'><th><font color='RED'>User</th><th><font color='RED'>Host</th>" >> $email/table1.html
n=1
while [[ "$n" -le "$line1" ]];
do
  val1=$(cat $path/nopwduser_.txt | head -n$n | tail -n1 | awk '{print $1}' )
  val2=$(cat $path/nopwduser_.txt | head -n$n | tail -n1 | awk '{print $2}')
  echo "<tr><td><font color='RED'>$val1</td><td><font color='RED'>$val2</td><tr>" >> $email/table1.html
n=`expr $n + 1`
done
echo  "</table>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
cat $path/unknwnhost.txt | sed -e '1d' > $path/unknwnhost_.txt
line2=$(cat $path/unknwnhost_.txt | wc -l )
echo  "<br><center>The user and Host which has unknown host</center><br>" >> $email/table1.html
if [[ -s $unknwnhost ]];
then
echo  "<table border='1' cellpadding='0' cellspacing='0' width='200px' align='center'><th><font color='black'>User</th><th><font color='black'>Host</th>" >> $email/table1.html
u=1
while [[ "$u" -le "$line2" ]];
do
  val1=$(cat $path/unknwnhost_.txt | head -n$u | tail -n1 | awk '{print $1}' )
  val2=$(cat $path/unknwnhost_.txt | head -n$u | tail -n1 | awk '{print $2}')
  echo "<tr><td>$val1</td><td>$val2</td><tr>" >> $email/table1.html
u=`expr $u + 1`
done
echo  "</table>" >> $email/table1.html
echo  "<br>" >> $email/table1.html
else
echo  "<br><center>--Nil--</center>" >> $email/table1.html
fi
echo  "==================================================================================================================================================================" >> $email/table1.html
cl=`expr $cl + 1`
fi
done
echo "</body></html>" >> $email/table1.html
echo "<br><br><br>Regards,<br>Mydbops Monitoring<br>(Alerts)<br>" >> $email/table1.html
cat $email/table1.html | /usr/sbin/sendmail $receiver
