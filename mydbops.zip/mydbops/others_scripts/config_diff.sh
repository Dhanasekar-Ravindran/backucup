#!/bin/sh
#!/bin/bash
#Version : 2.1
set -x
last=$(date +'%d-%b-%Y %H:%M:%S')
sub_path="/home/mymon/monitor/scripts/config_diff/sub"
receiver="dba-group@mydbops.com"
echo  "FROM: 'Config Diff Alert ' <config-diff-alert@mydbops.com>" > $sub_path/table1.html
echo  "TO: $receiver" >> $sub_path/table1.html
echo  "SUBJECT: Config Diff check at $last has difference" >> $sub_path/table1.html
echo  "Content-type: text/html" >> $sub_path/table1.html
echo  "<html><body>" >> $sub_path/table1.html
echo  "Hi Team,<br><br>Configuration File has a Difference.<br><br>Kindly verify it.<br><br>">>  $sub_path/table1.html
echo  "<table border='1' width='800px' align='center' cellpadding='0' cellspacing='0' height='200'><tr><td colspan="3"><center><b>Configuration File Differences</b></center></td><tr>" >> $sub_path/table1.html
mysql_path="/usr/local/mysql/bin/mysql"
user="db_metadata"
pwd="xIj2MN77"
$mysql_path -u $user -p$pwd -e "select host from mydbops_monitor.MONTAB where Cname not in ('Rupeex','hyperoffice_brazil','Novopay_Ctrls') and host not in ('novopay_replica_old') and polling='Y' order by host" > $sub_path/host.txt
cat $sub_path/host.txt | sed -e '1d' > $sub_path/hosts.txt
cline=$(less $sub_path/hosts.txt | wc -l )
cl=1
while [[ "$cl" -le "$cline" ]];
do
client=$(cat $sub_path/hosts.txt | head -n$cl | tail -n1)
if [[ ! -d "$sub_path/$client" ]];
then
mkdir $sub_path/$client
else
path="$sub_path/$client"
tz="TZ=Asia/Kolkata"
fil="$path/cnfdiff_.txt"
glb="$path/glbdiff.txt"
file="$path/config.txt"
hostname=$(ssh $client "hostname")
echo  "$client" >> $sub_path/list.txt
ssh $client "mysql --login-path=mydbops -e 'show global variables like \"basedir\";'" -N > $path/basedir.txt
basedir=$(cat $path/basedir.txt | awk '{print $2}')
cnf1=$(ssh $client "cat /etc/my.cnf" > $path/cnf1.txt)
cnf2=$(ssh $client "cat /etc/mysql/my.cnf" > $path/cnf2.txt)
cnf3=$(ssh $client "cat $basedir/my.cnf" > $path/cnf3.txt)

if [[ -s $path/cnf1.txt ]];
then
cnf="$path/cnf1.txt"
cnf_file="/etc/my.cnf"
elif [[ -s $path/cnf2.txt ]];
then
cnf="$path/cnf2.txt"
cnf_file="/etc/mysql/my.cnf"
#elif [[ -s $path/cnf3.txt ]];
#then
#cnf="$path/cnf3.txt"
#cnf_file="$basedir/my.cnf"
fi

cp -r $cnf $path/my_new.cnf
grep -Fxvf $path/my_old.cnf $path/my_new.cnf > $path/cnf_diff.txt
pt-config-diff --no-version-check $path/my_old.cnf $path/my_new.cnf > $path/cnfdiff.txt
ssh $client "mysql --login-path=mydbops -e 'show global variables'" > $path/glb.txt
cp -r $path/glb.txt $path/glb_new.txt
grep -Fxvf $path/glb_old.txt $path/glb_new.txt > $path/glb_diff.txt
pt-config-diff --no-version-check --ignore-variables="wsrep_sst_auth,log_slow_verbosity,sql_mode,optimizer_switch" $path/glb_old.txt $path/glb_new.txt > $path/glbdiff.txt
edit=$(ssh $client "$tz ls --full-time $cnf_file | awk '{print \$6,\$7}' | cut -c1-19")
pt-config-diff --no-version-check --ignore-variables="wsrep_sst_auth,log_slow_verbosity,sql_mode,optimizer_switch" $cnf $path/glb.txt > $path/config.txt
cat $path/config.txt | sed -e '3d' > $path/config_.txt
line=$(cat $path/config_.txt | wc -l)
cat $path/cnfdiff.txt | sed -e '3d' > $path/cnfdiff_.txt
line1=$(cat $path/cnfdiff_.txt | wc -l)
if [[ -s $file ]] || [[ -s $fil ]] || [[ -s $glb ]];
then 
echo  "<tr><th><center>Client Name</th><td colspan="2"><b>$client ($hostname)</b></center></td></tr>" >> $sub_path/table1.html
echo  "<tr><td colspan="3">The cnf (/etc/my.cnf) file has modified at $edit</td></tr>" >> $sub_path/table1.html
else
echo  "Nothing"
fi
if [[ -s $fil ]];
then
file2="Values in old cnf"
host2="Values in current cnf"
echo  "<tr><td colspan="3"><center>Difference in between cnf files</center></td></tr>" >> $sub_path/table1.html
echo  "<tr align='center'><th><font color='black'>Variables</th><th><font color='violet'>$file2</th><th><font color='violet'>$host2</th></tr>" >> $sub_path/table1.html
a=3
while [[ "$a" -le "$line1" ]];
do
  val1=$(cat $path/cnfdiff_.txt | head -n$a | tail -n1 | awk '{print $1}' )
  val2=$(cat $path/cnfdiff_.txt | head -n$a | tail -n1 | awk '{print $2}')
  val3=$(cat $path/cnfdiff_.txt | head -n$a | tail -n1 | awk '{print $3}')
  echo "<tr><td>$val1</td><td>$val2</td><td>$val3</td></tr>" >> $sub_path/table1.html
  a=`expr $a + 1`
  echo "detect" > $sub_path/check.txt
done
else
echo  "<br>No difference between the old and new cnf files<br>"
fi
cat $path/glbdiff.txt | sed -e '3d' > $path/glbdiff_.txt
line2=$(cat $path/glbdiff_.txt | wc -l )
if [[ -s $glb ]];
then
file3="Values in old Global variables"
host3="Values in current Global variables"
echo  "<tr><td colspan="3"><center>Difference in between global Variables</center></td></tr>" >> $sub_path/table1.html
echo  "<tr algin='center'><th><font color='black'>Variables</th><th><font color='violet'>$file3</th><th><font color='violet'>$host3</th></tr>" >> $sub_path/table1.html
c=3
while [[ "$c" -le "$line2" ]];
do
  val1=$(cat $path/glbdiff_.txt | head -n$c | tail -n1 | awk '{print $1}' )
  val2=$(cat $path/glbdiff_.txt | head -n$c | tail -n1 | awk '{print $2}')
  val3=$(cat $path/glbdiff_.txt | head -n$c | tail -n1 | awk '{print $3}')
  echo "<tr><td>$val1</td><td>$val2</td><td>$val3</td></tr>" >> $sub_path/table1.html
  c=`expr $c + 1`
  echo "detect" > $sub_path/check.txt
done
else
echo "No difference in global variables"
fi
if [[ -s $file ]];
then
echo  "<tr><td colspan="3"><center>Differences in cnf file and global variables</center></td></tr>" >> $sub_path/table1.html
echo  "<tr align='center'><th><font color='black'>Variables</th><th><font color='violet'>Values in cnf</th><th><font color='violet'>Values in current Global variables</th></tr>" >> $sub_path/table1.html
b=3
while [[ "$b" -le "$line" ]];
do
  val1=$(cat $path/config_.txt | head -n$b | tail -n1 | awk '{print $1}' )
  val2=$(cat $path/config_.txt | head -n$b | tail -n1 | awk '{print $2}')
  val3=$(cat $path/config_.txt | head -n$b | tail -n1 | awk '{print $3}')
  echo "<tr><td>$val1</td><td>$val2</td><td>$val3</td></tr>" >> $sub_path/table1.html
  b=`expr $b + 1`
  echo "detect" > $sub_path/check.txt
done
else
echo "No difference in cnf and global variables"
fi
fi
rm -rf $path/my_old.cnf
mv $path/my_new.cnf $path/my_old.cnf
rm -rf $path/glb_old.txt
mv $path/glb_new.txt $path/glb_old.txt
cl=`expr $cl + 1`
done
echo "</table></body></html>" >> $sub_path/table1.html
echo "<br><br><br>Regards,<br>Mydbops Monitoring<br>(Alerts)<br>" >> $sub_path/table1.html
check=$(cat $sub_path/check.txt | head -n1 | tail -n1)
if [[ -s $sub_path/check.txt ]] ;
then
cat $sub_path/table1.html | /usr/sbin/sendmail $receiver
rm -rf $sub_path/check.txt
else
echo  "FROM: 'Config Diff Alert ' <config-diff-alert@mydbops.com>" > $sub_path/table_nodiff.html
echo  "TO: $receiver" >> $sub_path/table_nodiff.html
echo  "SUBJECT: Config Diff check at $last has no difference" >> $sub_path/table_nodiff.html
echo  "Content-type: text/html" >> $sub_path/table_nodiff.html
echo  "<html><body>" >> $sub_path/table_nodiff.html
echo  "Hi Team,<br><br>Configuration File has no Difference.<br><br>">>  $sub_path/table_nodiff.html
echo  "<b>List of hosts checked: </b><br><br>" >> $sub_path/table_nodiff.html
list=$(cat $sub_path/list.txt | wc -l)
li=1
while [[ "$li" -le "$list" ]];
do
  val1=$(cat $sub_path/list.txt | head -n$li | tail -n1 | awk '{print $1}' )
  echo "$val1<br>" >> $sub_path/table_nodiff.html
  li=`expr $li + 1`
done
echo  "<br><br><br>Regards,<br>Mydbops Monitoring<br>(Alerts)<br>" >> $sub_path/table_nodiff.html
cat $sub_path/table_nodiff.html | /usr/sbin/sendmail $receiver
fi
> $sub_path/list.txt

