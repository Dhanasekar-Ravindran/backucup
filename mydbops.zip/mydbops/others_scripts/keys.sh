+#! /bin/bash
+
+# purpose :  script for collect the tables not using primary/unique key
+
+set -x
+
+path=/home/mydbops
+  
+/usr/bin/mysql --log-bin=mydbops -e "SELECT table_catalog, table_schema, table_name, engine FROM information_schema.tables WHERE (table_catalog, table_schema, table_name) NOT IN (SELECT table_catalog, table_schema, table_name FROM information_schema.table_constraints WHERE constraint_type NOT IN ('PRIMARY KEY', 'UNIQUE')) AND table_schema NOT IN ('information_schema', 'pg_catalog');" | awk '{print $2, $3}'     -s -N > /path/key.txt
+
+
+Regards
+MyDBOPS Monitoring
+
+(Alerts)" >> /path/key.txt
+mail -s "Status for primary/unique keys" "dba-group@mydbops.com" < /path/key.txt
+echo "Hi Team, collecting the Tables which not using primary/unique keys was completed sucessfully"
+
+Regards
+MyDBOPS Monitoring
+
+(Alerts)" >> /path/key.err
+mail -s "Status for primary/unique keys" "dba-group@mydbops.com" < /path/key.err
+echo "Hi Team, Some errors are occured while taking the primary/unique keys"
+
+ 
