#!/bin/sh
set -x
sourc='/home/suresh/mydumper_backup/db.txt'
user='test';
password='test123';
host='localhost';
backup_root='/home/suresh/mydumper_backup/';
db='world sadf test mysql';
date=$(date +"%Y-%m-%d %H:%M:%S");
backup_dir=$backup_root$(date +"%Y-%m-%d_%H:%M:%S");
path='/home/suresh/mydumper-0.9.1';
subpath='/home/suresh/mydumper_backup';
#ip=$(ip a | head -n8 | tail -n1 | awk '{print $2}' | cut -c1-11)
ip=$(ip addr | grep 'state UP' -A2 | tail -n1 | awk '{print $2}' | cut -f1  -d'/')
hostname=$(hostname)
b=1
#echo $db > /tmp/dbs.txt
result=$(less $sourc | wc -l)
while [[ $b -le $result  ]]
do
cat $sourc | head -n$b | tail -n1  >> /tmp/dba.txt
b=`expr $b + 1`
done
line=$(less /tmp/dba.txt | wc -l )
### Executed Backup ####

start=$(date +%s)
a=1
while [[ $a -le $line ]];
do 
data=$(cat /tmp/dba.txt | head -n$a | tail -n1)

$path/mydumper -u $user -p $password -h $host -v 3 -o $backup_dir -B $data 1>$subpath/backup.log 2>$subpath/backup.err
size=$(du -sh $backup_dir | awk '{print $1}') 
a=`expr $a + 1`
done
end=$(date +%s)
time=$(echo $((end-start)) | awk '{print int($1/60)" minutes : "int($1%60)"seconds"}')
status=$(cat /home/suresh/mydumper_backup/backup.err | tail -n2 | head -n1 | cut -c13-20)
if [[ "$status" == Finished ]]
then
stat="Success"
echo  "FROM: 'Backup-alert ' <-alert@mydbops.com>" > /tmp/data.html
echo  "TO: ponsuresh@mydbops.com" >> /tmp/data.html
echo  "SUBJECT: mydumper backup  $hostname server at ($ip) $date" >> /tmp/data.html
echo  "Content-type: text/html" >> /tmp/data.html
echo  "<html><body>" >> /tmp/data.html
echo  "Hi Team,<br><br>mydumper backup in $hostname ($ip) is <font color='green'>$stat </font>.<br><br>Kindly verify it.<br><br><br>">>  /tmp/data.html
echo  "<table border='1' width='750px' align='center' cellpadding='1' cellspacing='1'><tr align='center'><th><font color='black'>path</th><th><font color='black'>size</th></tr>" >> /tmp/data.html
echo  "<tr><td>$backup_dir</td><td>$size</td></tr></table>" >> /tmp/data.html
echo  "Time taken $time" >> /tmp/data.html
echo  "</body></html>" >> /tmp/data.html
cat /tmp/data.html | sendmail ponsuresh@mydbops.com
else
stat="Failure"
echo  "FROM: 'Backup-alert ' <-alert@mydbops.com>" > /tmp/data.html
echo  "TO: ponsuresh@mydbops.com" >> /tmp/data.html
echo  "SUBJECT: mydumper backup  $hostname server at ($ip) $date" >> /tmp/data.html
echo  "Content-type: text/html" >> /tmp/data.html
echo  "<html><body>" >> /tmp/data.html
echo  "Hi Team,<br><br>mydumper backup in $hostname ($ip) is <font color='red'>$stat </font>.<br><br>Kindly verify it.<br><br><br>">>  /tmp/data.html
echo  "Please check it.!<br><br>" >> /tmp/data.html
echo  "</body></html>" >> /tmp/data.html 

cat /tmp/data.html | sendmail ponsuresh@mydbops.com 

fi
> /tmp/dba.txt
> /tmp/dbs.txt

